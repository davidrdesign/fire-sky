<?php
/*
 * Template Name: Skyfire Landing Page
 * Template Post Type: page
 *
 * Installation:
 *   1. Copy this file into your active theme folder (or child theme folder).
 *   2. In WordPress Admin → Pages → Add New (or edit an existing page).
 *   3. In the Page Attributes panel, set Template to "Skyfire Landing Page".
 *   4. Publish or update the page.
 *
 * The page renders as a fully standalone full-screen experience —
 * it does not load your theme's header or footer.
 */
if ( ! defined( 'ABSPATH' ) ) exit;
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>Skyfire: The Agent Trust Stack</title>
<meta name="description" content="Skyfire gives AI agents verified identity and payment credentials that work across the open internet. No 403 errors. No blocked checkouts. Just authenticated access and real transactions, everywhere." />
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Geist:wght@100..900&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" rel="stylesheet">

<style>
/* =========================================================
   SKYFIRE — Faithful to skyfire.xyz design system
   Geist (display) + Inter (body)
   Ink #28171B / #29171B · Brand red #C93C09 · Teal #1B7A69 · Orange #EE7843
   Pill buttons (radius 10.667–13.333px), Inter 500
   ========================================================= */

:root {
  /* Surfaces */
  --paper: #FFFFFF;
  --paper-2: #F7F7F7;          /* tabination bg */
  --paper-3: #F7F7FF;           /* hairline borders, light fills */
  --ink: #28171B;               /* primary text */
  --ink-2: #29171B;             /* slight variant used in CTAs */
  --ink-soft: rgba(40,23,27,0.78);
  --ink-soft-2: rgba(40,23,27,0.6);
  --line: rgba(40,23,27,0.10);
  --line-2: rgba(40,23,27,0.18);

  /* Brand */
  --red: #C93C09;               /* eyebrow pills, accents */
  --teal: #1B7A69;              /* secondary CTA, success */
  --teal-tint: rgba(89,173,158,0.10);
  --teal-2: #59AD9E;
  --orange: #EE7843;            /* hover accent on dark, badges */

  /* Type */
  --display: 'Geist', 'Inter', system-ui, sans-serif;
  --sans: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
  --mono: 'JetBrains Mono', ui-monospace, Menlo, monospace;
}

*, *::before, *::after { box-sizing: border-box; }
html { -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale; scroll-behavior: smooth; }
html, body { margin: 0; padding: 0; }
body {
  font-family: var(--sans);
  background: var(--paper);
  color: var(--ink);
  font-size: 16px;
  line-height: 1.75;
  font-weight: 400;
  overflow-x: hidden;
}
img, svg { display: block; max-width: 100%; }
a { color: var(--ink); text-decoration: none; transition: color .3s ease-out; }
button { font: inherit; cursor: pointer; border: none; background: none; color: inherit; }
::selection { background: var(--teal); color: #fff; }

/* ============== LAYOUT ============== */
.wrap { width: 100%; max-width: 1280px; margin: 0 auto; padding: 0 24px; }
@media (max-width: 720px) { .wrap { padding: 0 20px; } }

/* ============== TYPOGRAPHY ============== */
h1, h2, h3, h4, h5, h6 {
  font-family: var(--display);
  font-weight: 400;
  margin: 0 0 14px;
  line-height: 1.3;
  color: var(--ink);
}
h1 { font-size: clamp(39px, 5vw, 48px); }
h2 { font-size: clamp(33px, 5vw, 39px); }
h3 { font-size: clamp(27px, 5vw, 31px); }
h4 { font-size: clamp(23px, 5vw, 25px); }
h5 { font-size: 20px; }
h6 { font-size: 16px; }
p { margin: 0 0 19px; }

/* The skyfire eyebrow style — red pill, uppercase Inter */
.eyebrow {
  display: inline-block;
  padding: 4px 8px;
  border-radius: 4px;
  background-color: var(--red);
  color: #fff;
  font-family: var(--sans);
  font-size: 12px;
  font-weight: 500;
  line-height: 16px;
  letter-spacing: 0.6px;
  text-transform: uppercase;
  margin-bottom: 16px;
}
.eyebrow.on-dark { /* same red pill on dark backgrounds */ }

/* ============== BUTTONS (matching skyfire.xyz) ============== */
.btn {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  font-family: var(--sans);
  font-size: 16px;
  font-weight: 500;
  line-height: 26.667px;
  text-align: center;
  text-decoration: none;
  user-select: none;
  vertical-align: top;
  padding: 8px 21.333px;
  cursor: pointer;
  transition: background-color 0.3s ease-out, border-color 0.3s ease-out, color 0.3s ease-out;
  white-space: nowrap;
}

/* Primary (light bg) — outlined ink */
.btn--primary {
  border-radius: 13.333px;
  border: 1.5px solid var(--ink-2);
  color: var(--ink-2);
  background-color: transparent;
  box-shadow: 0px 0px 0px 1.333px rgba(33, 33, 38, 0.05), 0px 1.333px 1.333px 0px rgba(0, 0, 0, 0.05);
}
.btn--primary:hover, .btn--primary:focus {
  background-color: var(--ink-2);
  border-color: var(--ink-2);
  color: #fff;
}

/* Primary on dark bg — outlined white */
.btn--primary-on-dark {
  border-radius: 13.333px;
  border: 1.5px solid #fff;
  color: #fff;
  background-color: transparent;
  box-shadow: 0px 0px 0px 1.333px rgba(33, 33, 38, 0.05), 0px 1.333px 1.333px 0px rgba(0, 0, 0, 0.05);
}
.btn--primary-on-dark:hover, .btn--primary-on-dark:focus {
  background-color: var(--orange);
  border-color: var(--orange);
  color: #fff;
}

/* Secondary — solid teal */
.btn--secondary {
  border-radius: 10.667px;
  background: var(--teal);
  color: #fff;
  border: none;
  box-shadow: 0px 0px 8px 0px #FFF inset, 0px 0px 0px 1.333px rgba(33, 33, 38, 0.05), 0px 1.333px 1.333px 0px rgba(0, 0, 0, 0.05);
}
.btn--secondary:hover, .btn--secondary:focus {
  background-color: var(--ink-2);
  color: #fff;
}

/* Header CTA — solid ink pill */
.btn--header {
  background: var(--ink-2);
  color: #fff;
  border-radius: 10.667px;
  border: none;
}
.btn--header:hover { background-color: var(--orange); color: #fff; }

.btn .arr { display: inline-block; transition: transform .2s ease; }
.btn:hover .arr { transform: translateX(3px); }

/* ============== HEADER / NAV ============== */
.nav {
  position: sticky; top: 0; z-index: 50;
  background: rgba(255,255,255,0.94);
  backdrop-filter: saturate(140%) blur(18px);
  -webkit-backdrop-filter: saturate(140%) blur(18px);
  border-bottom: 1px solid var(--paper-3);
  box-shadow: 0 1px 26px 0 rgba(0,0,0,0.04);
}
.nav-inner {
  display: flex; align-items: center; justify-content: space-between;
  height: 100px;
}
.logo {
  display: inline-flex; align-items: center;
  text-decoration: none;
}
.logo-img {
  display: block;
  height: 32px;
  width: auto;
  max-width: min(128px, 46vw);
  object-fit: contain;
}
.foot-brand .logo-img {
  filter: brightness(0) invert(1);
  opacity: 0.96;
}
.nav-links {
  display: flex; gap: 20px; align-items: center;
  margin-left: 30px;
  margin-right: auto;
  font-size: 16px;
  font-weight: 400;
}
.nav-links a:not(.btn) { color: var(--ink); text-decoration: none; padding: 2px 0; border-bottom: 2px solid transparent; transition: border-color .3s ease-out; }
.nav-links a:not(.btn):hover { border-bottom-color: var(--ink); }
@media (max-width: 900px) {
  .nav-links a:not(.btn) { display: none; }
}

/* ============== HERO ============== */
.hero {
  background: var(--ink-2);
  color: #fff;
  padding: 96px 0 88px;
  position: relative;
  overflow: hidden;
}
.hero::before {
  content: ""; position: absolute; inset: 0;
  background:
    radial-gradient(ellipse 60% 40% at 90% 20%, rgba(89,173,158,0.10), transparent 60%),
    radial-gradient(ellipse 50% 60% at 5% 90%, rgba(238,120,67,0.08), transparent 60%);
  pointer-events: none;
}
.hero-grid {
  position: relative;
  max-width: 1200px;
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 64px;
  align-items: center;
}
.hero-diagram {
  display: flex;
  align-items: center;
  justify-content: flex-end;
}
.hero-svg { width: 100%; max-width: 580px; height: auto; }
@media (max-width: 960px) {
  .hero-grid { grid-template-columns: 1fr; max-width: 760px; }
  .hero-diagram { display: none; }
}
@keyframes kya-flow {
  from { stroke-dashoffset: 20; }
  to { stroke-dashoffset: 0; }
}
.kf { stroke-dasharray: 5 5; animation: kya-flow 1.4s linear infinite; }
.kf2 { stroke-dasharray: 5 5; animation: kya-flow 1.4s linear infinite 0.3s; }
.kf3 { stroke-dasharray: 5 5; animation: kya-flow 1.4s linear infinite 0.55s; }
.kf4 { stroke-dasharray: 5 5; animation: kya-flow 1.4s linear infinite 0.8s; }
.kf5 { stroke-dasharray: 5 5; animation: kya-flow 1.4s linear infinite 0.15s; }
@keyframes node-pulse {
  0%,100% { opacity:1; } 50% { opacity:0.75; }
}
.skyfire-node { animation: node-pulse 3s ease-in-out infinite; }

/* Destination node ring pulse */
@keyframes dest-pulse {
  0%, 90%, 100% { stroke-opacity: 0.28; stroke-width: 1.5; }
  10%, 30% { stroke-opacity: 0.85; stroke-width: 2.2; }
}
.dest-node { animation: dest-pulse 4.2s ease-in-out infinite; transform-box: fill-box; transform-origin: center; }

/* Security partner logos: white silhouette + scroll reel */
.logo-reel image {
  filter: brightness(0) invert(1);
  opacity: 0.85;
}
/* Skyfire wordmark inside the teal box — render white */
.sf-logo-mark {
  filter: brightness(0) invert(1);
}
/* Material Symbols glyphs used inline in the diagrams */
.msym {
  font-family: 'Material Symbols Outlined', sans-serif;
  font-weight: 400;
  font-feature-settings: 'liga';
  -webkit-font-feature-settings: 'liga';
}

.hero h1 {
  font-family: var(--display);
  font-weight: 400;
  font-size: clamp(54px, 7vw, 105px);
  line-height: 1.0;
  letter-spacing: -3.84px;
  margin: 0 0 28px;
  color: #fff;
}
.hero h1 .stack {
  display: block;
  background: linear-gradient(96deg, #EE7843 0%, #D9A36A 30%, #B8C58E 60%, #59AD9E 100%);
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
}
.hero-sub {
  font-family: var(--display);
  font-size: clamp(18px, 1.6vw, 24px);
  line-height: 1.4;
  letter-spacing: -0.4px;
  color: rgba(255,255,255,0.85);
  margin: 0 0 36px;
  max-width: 580px;
  font-weight: 400;
}
.hero-sub strong { color: #fff; font-weight: 500; }
.hero-ctas { display: flex; gap: 16px; flex-wrap: wrap; }

/* ============== SECTION DEFAULTS ============== */
.section { padding: 100px 0; }
@media only screen and (min-width: 1024px) { .section { padding: 120px 0; } }

.section-head { max-width: 720px; margin-bottom: 56px; }
.section-head.center { margin-left: auto; margin-right: auto; text-align: center; }

.section h2 {
  font-family: var(--display);
  font-weight: 400;
  font-size: clamp(32px, 5vw, 64px);
  line-height: 1.05;
  letter-spacing: -2.88px;
  margin: 0 0 20px;
}
.section .lede {
  font-family: var(--sans);
  font-size: 16px;
  line-height: 24px;
  letter-spacing: -0.32px;
  color: var(--ink);
  max-width: 560px;
  margin: 0;
}
.section-head.center .lede { margin-left: auto; margin-right: auto; }

/* ============== TWO CARDS (Access & Login / Checkout & Payments) ============== */
.cards-section { padding-bottom: 40px; }
.two-cards {
  display: grid; grid-template-columns: 1fr 1fr;
  gap: 18px;
  margin-bottom: 40px;
}
@media (max-width: 880px) { .two-cards { grid-template-columns: 1fr; } }

.card {
  position: relative;
  border-radius: 22px;
  padding: 36px 34px 30px;
  min-height: 380px;
  min-width: 0;
  display: grid;
  grid-template-rows: auto auto 1fr auto auto;
  overflow: hidden;
}
.card-rust {
  background:
    radial-gradient(ellipse at 100% 0%, rgba(255,180,140,0.18), transparent 60%),
    linear-gradient(155deg, #C93C09 0%, #8C2A06 100%);
}
.card-forest {
  background:
    radial-gradient(ellipse at 100% 0%, rgba(140,200,170,0.18), transparent 60%),
    linear-gradient(155deg, #1B7A69 0%, #0F4A3F 100%);
}
.card-tag {
  font-family: var(--sans);
  font-size: 12px;
  font-weight: 600;
  line-height: 16px;
  letter-spacing: 0.6px;
  text-transform: uppercase;
  color: rgba(255,255,255,0.85);
  margin-bottom: 16px;
}
.card-icon {
  position: absolute; top: 30px; right: 30px;
  width: 38px; height: 38px; border-radius: 10px;
  background: rgba(255,255,255,0.14);
  display: grid; place-items: center;
  color: rgba(255,255,255,0.95);
}
.card h3 {
  font-family: var(--display);
  font-size: 32px;
  font-weight: 400;
  letter-spacing: -1px;
  line-height: 1.1;
  margin: 0 0 14px;
  color: #fff;
}
.card p {
  font-family: var(--sans);
  font-size: 15px;
  line-height: 22px;
  letter-spacing: -0.18px;
  color: rgba(255,255,255,0.88);
  margin: 0 0 24px;
  max-width: 42ch;
}
.chips { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: auto; }
.chips.chips--single-line {
  display: flex;
  flex-direction: row;
  flex-wrap: nowrap !important;
  align-items: center;
  width: 100%;
  max-width: 100%;
  min-width: 0;
  overflow-x: auto;
  overflow-y: hidden;
  scrollbar-width: thin;
  scrollbar-color: rgba(255,255,255,0.35) transparent;
  -webkit-overflow-scrolling: touch;
}
.chips.chips--single-line::-webkit-scrollbar { height: 4px; }
.chips.chips--single-line::-webkit-scrollbar-thumb {
  background: rgba(255,255,255,0.3);
  border-radius: 999px;
}
.chip {
  padding: 5px 11px;
  border-radius: 999px;
  font-family: var(--sans);
  font-size: 12px;
  font-weight: 500;
  background: rgba(255,255,255,0.16);
  color: rgba(255,255,255,0.96);
  border: 1px solid rgba(255,255,255,0.14);
  white-space: nowrap;
  flex-shrink: 0;
}
a.chip.chip--more {
  text-decoration: none;
  cursor: pointer;
  border-color: rgba(255,255,255,0.22);
}
a.chip.chip--more:hover {
  background: rgba(255,255,255,0.24);
  color: #fff;
}
.card-link {
  margin-top: 28px;
  display: inline-flex; align-items: center; gap: 6px;
  font-family: var(--sans);
  font-size: 14px;
  font-weight: 500;
  color: #fff;
  align-self: flex-start;
  transition: gap .2s ease;
}
.card-link:hover { gap: 10px; color: #fff; }

.cards-cta { display: flex; justify-content: center; }

/* ============== COVERAGE BAND ============== */
.coverage {
  background: var(--paper-2);
  padding: 100px 0;
  border-top: 1px solid var(--line);
  border-bottom: 1px solid var(--line);
  text-align: center;
}
.coverage h2 {
  font-family: var(--display);
  font-weight: 400;
  font-size: clamp(36px, 5.6vw, 76px);
  line-height: 1.05;
  letter-spacing: -3.84px;
  margin: 0;
  color: var(--ink);
}
.coverage h2 .pct { color: var(--orange); }
.coverage h2 .count { display: block; margin-top: 4px; color: var(--teal); }
.coverage .sub {
  font-family: var(--display);
  font-weight: 400;
  font-size: clamp(20px, 2.4vw, 32px);
  line-height: 1.2;
  letter-spacing: -1px;
  color: var(--ink);
  margin: 20px auto 36px;
  max-width: 720px;
}
.coverage-logos {
  display: grid;
  grid-template-columns: repeat(12, 1fr);
  gap: 36px 0;
  margin: 8px auto 44px;
  max-width: 1080px;
  justify-items: center;
  align-items: center;
}
.cov-logo { grid-column: span 2; }
.cov-logo:nth-child(7) { grid-column-start: 2; }
.cov-logo {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  color: #000;
}
.cov-logo svg { display: block; width: auto; height: 26px; }
.cov-logo[data-h="18"] svg { height: 18px; }
.cov-logo[data-h="20"] svg { height: 20px; }
.cov-logo[data-h="22"] svg { height: 22px; }
.cov-logo[data-h="24"] svg { height: 24px; }
.cov-logo[data-h="26"] svg { height: 26px; }
.cov-logo[data-h="28"] svg { height: 28px; }
.cov-logo[data-h="30"] svg { height: 30px; }
.cov-logo[data-h="32"] svg { height: 32px; }
.cov-logo--img img {
  display: block;
  height: 26px;
  width: auto;
  filter: brightness(0);
}
.cov-logo--img[data-h="18"] img { height: 18px; }
.cov-logo--img[data-h="20"] img { height: 20px; }
.cov-logo--img[data-h="22"] img { height: 22px; }
.cov-logo--img[data-h="24"] img { height: 24px; }
.cov-logo--img[data-h="26"] img { height: 26px; }
.cov-logo--img[data-h="28"] img { height: 28px; }
.cov-logo--img[data-h="30"] img { height: 30px; }
.cov-logo--img[data-h="32"] img { height: 32px; }
.cov-logo.cov-logo--wordmark {
  font-family: var(--display);
  font-size: 16px;
  font-weight: 500;
  letter-spacing: -0.04em;
  color: #000;
  white-space: nowrap;
}
.coverage-cta { display: flex; justify-content: center; }

/* ============== THREE PRODUCTS ============== */
.products { padding: 110px 0 100px; }
.products-head {
  margin-bottom: 56px;
}
.products h2 {
  font-family: var(--display);
  font-weight: 400;
  font-size: clamp(32px, 5vw, 64px);
  line-height: 1.05;
  letter-spacing: -2.88px;
  margin: 0 0 20px;
}

.product-rows { border-top: 1px solid var(--line); }
.product-row {
  display: grid; grid-template-columns: 80px 1.05fr 2fr auto;
  gap: 32px; align-items: center;
  padding: 36px 0;
  border-bottom: 1px solid var(--line);
  transition: padding .3s ease, background .3s ease;
}
.product-row:hover {
  padding-left: 12px;
  padding-right: 12px;
  background: rgba(89,173,158,0.05);
}
@media (max-width: 880px) {
  .product-row { grid-template-columns: 1fr; gap: 14px; padding: 28px 0; }
}
.pr-num {
  font-family: var(--mono);
  font-size: 12px;
  color: var(--ink-soft-2);
  letter-spacing: 0.12em;
  font-weight: 500;
}
.pr-name {
  font-family: var(--display);
  font-weight: 400;
  font-size: clamp(28px, 3vw, 40px);
  line-height: 1.05;
  letter-spacing: -1.5px;
  color: var(--ink);
}
.pr-name .a { color: var(--red); }
.pr-name .t { color: var(--teal); }
.pr-name .o { color: var(--orange); }
.pr-desc {
  font-family: var(--sans);
  font-size: 16px;
  line-height: 24px;
  letter-spacing: -0.18px;
  color: var(--ink);
  max-width: 56ch;
}

/* ============== ACCESS HERO CARD (the dark moment) ============== */
.access-section { padding: 60px 0 100px; }
.access-card {
  position: relative;
  border-radius: 24px;
  padding: 56px;
  background: var(--ink-2);
  overflow: hidden;
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 48px;
  align-items: center;
}
.access-diagram {
  display: flex;
  align-items: center;
  justify-content: center;
}
.access-svg { width: 100%; max-width: 540px; height: auto; }
@media (max-width: 880px) {
  .access-card { grid-template-columns: 1fr; gap: 32px; }
  .access-diagram { display: none; }
}
@media (max-width: 880px) { .access-card { padding: 40px 28px; } }

.access-card::before {
  content: ""; position: absolute; inset: 0;
  background:
    radial-gradient(ellipse 80% 50% at 100% 100%, rgba(238,120,67,0.20), transparent 65%);
  pointer-events: none;
}
.access-card > * { position: relative; }
.access-card .eyebrow { background: var(--red); margin-bottom: 24px; }
.access-card h3 {
  font-family: var(--display);
  font-weight: 400;
  font-size: clamp(32px, 4vw, 48px);
  line-height: 1.1;
  letter-spacing: -2.4px;
  margin: 0 0 20px;
  color: #fff;
}
.access-card p {
  font-family: var(--sans);
  font-size: 16px;
  line-height: 24px;
  letter-spacing: -0.32px;
  color: rgba(255,255,255,0.85);
  margin: 0 0 28px;
  max-width: 50ch;
}

/* ============== LIVE CHECKOUT DEMO ============== */
.demo-section { padding: 110px 0; background: var(--paper); }
.demo-head { text-align: center; max-width: 960px; margin: 0 auto 56px; }
.demo-head h2 {
  font-family: var(--display);
  font-weight: 400;
  font-size: clamp(26px, 5.2vw, 60px);
  line-height: 1.1;
  letter-spacing: -2.4px;
  margin: 0 0 20px;
  white-space: nowrap;
}
.demo-head .lede {
  font-family: var(--sans);
  font-size: 16px;
  line-height: 24px;
  letter-spacing: -0.32px;
  color: var(--ink);
  margin: 0 auto;
}

.demo-frame {
  border-radius: 20px;
  background: #fff;
  border: 1px solid var(--line);
  overflow: hidden;
  box-shadow: 0 30px 80px -30px rgba(40,23,27,0.16);
  margin-bottom: 40px;
}
.demo-bar {
  display: flex; align-items: center; gap: 10px;
  padding: 14px 18px;
  border-bottom: 1px solid var(--line);
  background: var(--paper-2);
}
.demo-dots { display: flex; gap: 6px; }
.demo-dots span { width: 9px; height: 9px; border-radius: 50%; background: var(--line-2); }
.demo-url {
  flex: 1;
  font-family: var(--mono);
  font-size: 12px;
  color: var(--ink-soft);
  text-align: center;
  letter-spacing: 0.01em;
}
.demo-body {
  padding: 28px;
  display: grid; grid-template-columns: 1.1fr 1fr;
  gap: 24px;
}
@media (max-width: 880px) { .demo-body { grid-template-columns: 1fr; } }

.steps { display: flex; flex-direction: column; gap: 8px; }
.step {
  position: relative;
  padding: 18px 110px 18px 56px;
  border: 1px solid var(--line);
  border-radius: 12px;
  background: var(--paper-2);
  transition: all .3s ease;
}
.step .num {
  position: absolute; left: 18px; top: 50%; transform: translateY(-50%);
  width: 26px; height: 26px; border-radius: 50%;
  background: #fff;
  border: 1px solid var(--line-2);
  display: grid; place-items: center;
  font-family: var(--mono); font-size: 12px; font-weight: 500;
  color: var(--ink-soft-2);
  transition: all .3s ease;
}
.step .title {
  font-family: var(--sans);
  font-size: 14.5px;
  font-weight: 500;
  color: var(--ink);
}
.step .desc {
  font-family: var(--sans);
  font-size: 13px;
  line-height: 1.45;
  color: var(--ink-soft);
  margin-top: 3px;
}
.step .badge {
  position: absolute; right: 18px; top: 50%; transform: translateY(-50%);
  font-family: var(--mono); font-size: 10px;
  letter-spacing: 0.14em; text-transform: uppercase;
  color: var(--ink-soft-2);
  padding: 4px 9px; border-radius: 4px;
  border: 1px solid var(--line);
  transition: all .3s ease;
}
.step.active {
  border-color: rgba(27,122,105,0.45);
  background: var(--teal-tint);
}
.step.active .num {
  background: var(--teal);
  border-color: var(--teal);
  color: #fff;
  box-shadow: 0 0 0 5px rgba(27,122,105,0.16);
}
.step.active .badge { color: var(--teal); border-color: rgba(27,122,105,0.4); background: rgba(27,122,105,0.06); }
.step.done .num {
  background: rgba(27,122,105,0.18);
  border-color: rgba(27,122,105,0.4);
  color: var(--teal);
}

.demo-side {
  background: var(--paper-2);
  border: 1px solid var(--line);
  border-radius: 14px;
  padding: 24px;
  display: flex; flex-direction: column;
}
.demo-side .head {
  font-family: var(--mono);
  font-size: 11px;
  letter-spacing: 0.14em;
  text-transform: uppercase;
  color: var(--ink-soft);
  padding-bottom: 14px;
  border-bottom: 1px solid var(--line);
  margin-bottom: 8px;
  display: flex; align-items: center; justify-content: space-between;
}
.live-pulse {
  display: inline-flex; align-items: center; gap: 7px;
  font-size: 10.5px; color: var(--teal);
  text-transform: uppercase; letter-spacing: 0.14em;
}
.live-pulse::before {
  content: ""; width: 7px; height: 7px; border-radius: 50%;
  background: var(--teal);
  box-shadow: 0 0 0 4px rgba(27,122,105,0.18);
  animation: pulse 1.6s ease-in-out infinite;
}
@keyframes pulse {
  0%, 100% { opacity: 1; box-shadow: 0 0 0 4px rgba(27,122,105,0.18); }
  50% { opacity: .6; box-shadow: 0 0 0 8px rgba(27,122,105,0); }
}
.tx {
  display: flex; align-items: center; justify-content: space-between;
  padding: 14px 0; border-bottom: 1px dashed var(--line);
  border-radius: 10px; margin: 0 -6px; padding-left: 10px; padding-right: 10px;
  transition: opacity .35s ease, border-color .35s ease, background .35s ease, box-shadow .35s ease;
}
.tx:last-child { border-bottom: none; }
.tx.tx--wait {
  opacity: 0.38;
}
.tx.tx--live {
  opacity: 1;
  background: rgba(238,120,67,0.08);
  border: 1px solid rgba(238,120,67,0.35);
  box-shadow: 0 0 0 1px rgba(238,120,67,0.12);
}
.tx.tx--settled {
  opacity: 1;
  background: transparent;
  border: 1px solid transparent;
  box-shadow: none;
}
.tx-l { display: flex; flex-direction: column; gap: 2px; }
.tx-merchant {
  font-family: var(--sans);
  font-size: 13.5px; font-weight: 500;
  color: var(--ink);
}
.tx-item {
  font-family: var(--sans);
  font-size: 12.5px;
  color: var(--ink-soft);
}
.tx-r {
  font-family: var(--mono); font-size: 11px;
  letter-spacing: 0.04em;
  display: inline-flex; align-items: center; gap: 5px;
  transition: color .35s ease;
}
.tx-r.tx-r--await { color: var(--ink-soft-2); }
.tx-r.tx-r--await::before { display: none; }
.tx-r.tx-r--live {
  color: var(--orange);
  font-weight: 600;
}
.tx-r.tx-r--live::before {
  content: ""; width: 6px; height: 6px; border-radius: 50%;
  background: var(--orange);
  box-shadow: 0 0 0 3px rgba(238,120,67,0.25);
  animation: pulse 1.2s ease-in-out infinite;
}
.tx-r.tx-r--ok {
  color: var(--teal);
}
.tx-r.tx-r--ok::before {
  content: ""; width: 5px; height: 5px; border-radius: 50%; background: var(--teal);
  animation: none;
  box-shadow: none;
}
.demo-cta { display: flex; justify-content: center; }

/* ============== FOOTER ============== */
footer {
  background: var(--ink-2);
  color: #fff;
  padding: 64px 0 32px;
}
.foot-grid {
  display: grid; grid-template-columns: 1.5fr 1fr 1fr 1fr;
  gap: 40px;
  padding-bottom: 48px;
  border-bottom: 1px solid rgba(255,255,255,0.10);
}
@media (max-width: 880px) { .foot-grid { grid-template-columns: 1fr 1fr; gap: 32px; } }
.foot-brand h4 {
  font-family: var(--display);
  font-weight: 400;
  font-size: 24px;
  letter-spacing: -0.5px;
  color: #fff;
  margin: 18px 0 10px;
}
.foot-brand p {
  font-family: var(--sans);
  font-size: 14px; line-height: 22px;
  color: rgba(255,255,255,0.72);
  max-width: 32ch;
  margin: 0;
}
.foot-col h5 {
  font-family: var(--sans);
  font-size: 12px;
  font-weight: 600;
  letter-spacing: 0.12em;
  text-transform: uppercase;
  color: rgba(255,255,255,0.55);
  margin: 0 0 16px;
}
.foot-col ul { list-style: none; padding: 0; margin: 0; display: flex; flex-direction: column; gap: 10px; }
.foot-col a {
  font-family: var(--sans);
  font-size: 14px;
  color: rgba(255,255,255,0.85);
  transition: color .2s ease;
}
.foot-col a:hover { color: #fff; }
.foot-base {
  display: flex; align-items: center; justify-content: space-between;
  padding-top: 22px;
  font-family: var(--sans);
  font-size: 13px;
  color: rgba(255,255,255,0.5);
  letter-spacing: -0.12px;
}

/* ============== CHIPS TICKER ============== */
.chips-ticker {
  position: relative;
  overflow: hidden;
  width: 100%;
  margin-bottom: auto;
  -webkit-mask-image: linear-gradient(to right, transparent, black 4%, black 96%, transparent);
  mask-image: linear-gradient(to right, transparent, black 4%, black 96%, transparent);
}
.chips-track {
  display: flex;
  gap: 6px;
  width: max-content;
  animation: chips-ticker 60s linear infinite;
}
.chips-ticker:hover .chips-track { animation-play-state: paused; }
@keyframes chips-ticker {
  from { transform: translateX(0); }
  to { transform: translateX(-50%); }
}

/* ============== Reveal-on-scroll ============== */
.reveal { opacity: 0; transform: translateY(18px); transition: opacity .8s cubic-bezier(.2,.8,.2,1), transform .8s cubic-bezier(.2,.8,.2,1); }
.reveal.in { opacity: 1; transform: none; }

</style>
</head>
<body>

<!-- ============ NAV ============ -->
<nav class="nav">
  <div class="wrap nav-inner">
    <a href="#" class="logo" aria-label="Skyfire home">
      <img class="logo-img" src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTA4IiBoZWlnaHQ9IjI3IiB2aWV3Qm94PSIwIDAgMTA4IDI3IiBmaWxsPSJub25lIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgo8cGF0aCBkPSJNNzcuMjg5MyAyLjUyMTI0SDc0LjI5OTVDNzIuNzggMi41MjEyNCA3MS42NTU4IDIuODg2OTkgNzAuOTM5IDMuNjEzNThDNzAuMjIyMiA0LjM0MDE2IDY5Ljg2MTQgNS4zNzM1OSA2OS44NjE0IDYuNzEzODVWMjAuMDI4MUM2OS44NjE0IDIwLjM5MTQgNzAuMTUzNSAyMC42ODEgNzAuNTE0MyAyMC42ODFINzIuOTY5QzczLjMzMjMgMjAuNjgxIDczLjYyMiAyMC4zODg5IDczLjYyMiAyMC4wMjgxVjExLjU1Mkg3Ni42MjlDNzYuOTkyMiAxMS41NTIgNzcuMjgxOSAxMS4yNTk5IDc3LjI4MTkgMTAuODk5MVY5LjE4ODE3Qzc3LjI4MTkgOC44MjQ4OCA3Ni45ODk4IDguNTM1MjMgNzYuNjI5IDguNTM1MjNINzMuNjIyVjcuMTEzOTZDNzMuNjIyIDYuNTk2MDIgNzMuNzM5OCA2LjIxMzA5IDczLjk3MDUgNS45NTI4OUM3NC4yMDYyIDUuNjkwMjQgNzQuNTg0MiA1LjU2MjYgNzUuMTAyMSA1LjU2MjZINzYuNzIyMkM3Ny4wMDQ1IDUuNTYyNiA3Ny4yNTQ5IDUuMzgwOTUgNzcuMzQzMyA1LjExMzM5TDc3LjkxMjggMy4zODI4NEM3OC4wNTAyIDIuOTYwNjMgNzcuNzM4NSAyLjUyMzY5IDc3LjI5MTcgMi41MjM2OUw3Ny4yODkzIDIuNTIxMjRaTTczLjk4MDMgNS45NDA2MkM3My45ODAzIDUuOTQwNjIgNzMuOTc1NCA1Ljk0Nzk4IDczLjk3MyA1Ljk1MDQ0TDczLjk4MDMgNS45NDA2MlpNNjcuOTYxNSA3LjI0NjUxSDY1LjU1NTlDNjUuMjc4NSA3LjI0NjUxIDY1LjAzNTUgNy40MjA4IDY0LjkzOTcgNy42ODA5OUw2MS41MDA3IDE3LjIzOTVMNTcuOTkzIDcuNjgzNDVDNTcuODk3MiA3LjQyNTcxIDU3LjY1NDIgNy4yNTM4OCA1Ny4zNzkzIDcuMjUzODhINTAuNzMyQzUwLjUwMzcgNy4yNTM4OCA1MC4yOTAyIDcuMzc0MTYgNTAuMTcyMyA3LjU3MDUzTDQ2LjM0NzkgMTMuOTA4NUw1MC4xNzIzIDIwLjI0NjVDNTAuMjkwMiAyMC40NDI5IDUwLjUwMTMgMjAuNTYzMiA1MC43MzIgMjAuNTYzMkg1My40OTExQzU0LjAwMTYgMjAuNTYzMiA1NC4zMTU4IDIwLjAwNiA1NC4wNTA3IDE5LjU3MTVMNTAuNjM2MyAxMy45MDg1TDUzLjU1IDkuMDg1MDhDNTMuODM0NyA4LjYxMzc4IDU0LjUzNDMgOC42ODI1MSA1NC43MjMzIDkuMTk3OTlMNTguNzcxMSAyMC4yMTQ2QzU4Ljg0NzIgMjAuNDIwOCA1OS4wNDM2IDIwLjU1ODMgNTkuMjYyIDIwLjU1ODNINTkuNTc2MkM1OS45MzQ2IDIwLjU1ODMgNjAuMTkyNCAyMC45MTQyIDYwLjA3MjEgMjEuMjUwNUM1OS43Mjg0IDIyLjIxNzcgNTguODA1NSAyMi44NjgyIDU3Ljc4NjggMjIuODY4Mkg1NC44NDYxQzU0LjQ4MjggMjIuODY4MiA1NC4xOTMxIDIzLjE2MDMgNTQuMTkzMSAyMy41MjExVjI1Ljc4NjhDNTQuMTkzMSAyNi4xNTAxIDU0LjQ4NTIgMjYuNDM5NyA1NC44NDYxIDI2LjQzOTdINTcuNzg2OEM2MC4zMDUzIDI2LjQzOTcgNjIuNTYxMSAyNC44NDQyIDYzLjQyMDMgMjIuNDYwN0w2OC41NzUxIDguMTIwMzhDNjguNzI3MyA3LjY5MzI3IDY4LjQxMzEgNy4yNDY1MSA2Ny45NTkgNy4yNDY1MUg2Ny45NjE1Wk00NC43ODY3IDIuOTIzODFINDIuMzg4NUM0Mi4wMjUyIDIuOTIzODEgNDEuNzM1NiAzLjIxNTkyIDQxLjczNTYgMy41NzY3NlYxOS44OTA2QzQxLjczNTYgMjAuMjUzOSA0Mi4wMjc3IDIwLjU0MzYgNDIuMzg4NSAyMC41NDM2SDQ0Ljc4NjdDNDUuMTUgMjAuNTQzNiA0NS40Mzk3IDIwLjI1MTUgNDUuNDM5NyAxOS44OTA2VjMuNTc2NzZDNDUuNDM5NyAzLjIxMzQ2IDQ1LjE0NzYgMi45MjM4MSA0NC43ODY3IDIuOTIzODFaTTM3LjA2NDMgMTEuNDQ4OVYxMS40MzE4QzM2LjEyMTcgMTAuOTIxMiAzNC44MzA1IDEwLjUwMzkgMzMuMTkzMyAxMC4xNzVDMzIuMjQwOCA5Ljk3NjEzIDMxLjUwMiA5Ljc2NTAzIDMwLjk4MTYgOS41NTE0N0MzMC40NjEyIDkuMzM3OTEgMzAuMDkzIDkuMDg1MDggMjkuODcyMSA4Ljc5NTQyQzI5LjY0MzggOC41MTA2OCAyOS41NDMxIDguMTQ3MzkgMjkuNTQzMSA3LjcxMjkxQzI5LjU0MzEgNy4xMDY2IDI5Ljc4ODYgNi42MDA5MyAzMC4yNzQ2IDYuMjMwMjdDMzAuNzYwNyA1Ljg0MjQzIDMxLjQzMDggNS42NTU4OCAzMi4yODk5IDUuNjU1ODhDMzIuOTY1IDUuNjU1ODggMzMuNTQ2NyA1Ljc3NjE2IDM0LjAyMjkgNi4wMjY1NEMzNC40OTQyIDYuMjc2OTEgMzQuODgyMSA2LjYyNTQ4IDM1LjE1NDYgNy4wODQ1MUMzNS4zNDg1IDcuMzkzOCAzNS40ODM1IDcuNzQ0ODIgMzUuNTY2OSA4LjEzMjY2QzM1LjYzMzIgOC40NDY4NiAzNS45MjA0IDguNjY1MzIgMzYuMjM5NSA4LjY0ODE0TDM4LjY5NDIgOC41MTgwNEMzOS4wOTY4IDguNDk4NDEgMzkuMzc5MSA4LjEyMjg0IDM5LjMwMDUgNy43MzAwOUMzOS4xMzExIDYuODcwOTUgMzguODI5MiA2LjA5NTI3IDM4LjM4OTggNS40MDMwNEMzNy44MTU0IDQuNTAyMTcgMzcuMDI3NSAzLjgwNzUgMzYuMDI4NCAzLjI5NjkyQzM1LjAyOTQgMi43ODM4OSAzMy44MDQ1IDIuNTMxMDYgMzIuMzQ2NCAyLjUzMTA2QzMwLjk3NjcgMi41MzEwNiAyOS43OTYgMi43NDk1MyAyOC43OTY5IDMuMjA4NTVDMjcuODE1IDMuNjUwNCAyNy4wNDkyIDQuMjczODkgMjYuNTQxMSA1LjA3NDEyQzI2LjAyMDcgNS44NjIwNyAyNS43NjA1IDYuNzkyNCAyNS43NjA1IDcuODUyODJDMjUuNzYwNSA4Ljg0NDUyIDI1Ljk2NjcgOS42NjkyOSAyNi4zODQgMTAuMzI0N0MyNi43OTE0IDEwLjk3NzYgMjcuNDYxNiAxMS41MjUgMjguMzcyMiAxMS45NDk3QzI5LjI4MjkgMTIuMzc2OCAzMC40ODgyIDEyLjc2NDcgMzEuOTkwNSAxMy4xMjA2QzMzLjA3NTQgMTMuMzcxIDMzLjkwMDIgMTMuNjE2NCAzNC40NjIzIDEzLjg3NjZDMzUuMDE5NSAxNC4xMjcgMzUuNCAxNC40MTQyIDM1LjU5MzkgMTQuNzIxQzM1Ljc5MjggMTUuMDI3OSAzNS44OTEgMTUuMzgzOCAzNS44OTEgMTUuODAzNkMzNS44OTEgMTYuMjQ3OSAzNS43NzA3IDE2LjYyMzQgMzUuNTQ0OCAxNi45MzI3QzM1LjMxNjYgMTcuMjM5NSAzNC45ODAzIDE3LjQ3MDMgMzQuNTQ1OCAxNy42MTc2QzM0LjExMTMgMTcuNzY0OSAzMy41NzYyIDE3Ljg0NTkgMzIuOTU1MiAxNy44NDU5QzMyLjIwMTYgMTcuODQ1OSAzMS41NjMzIDE3LjcyNTYgMzEuMDQ1NCAxNy40NzUyQzMwLjUyNSAxNy4yMjQ4IDMwLjExNzUgMTYuODU5MSAyOS44MTA3IDE2LjM3MDZDMjkuNTgyNCAxNi4wMDczIDI5LjQxMDYgMTUuNTg3NSAyOS4yOTc3IDE1LjExMTNDMjkuMjI2NSAxNC44MDk0IDI4Ljk0NDIgMTQuNjA1NyAyOC42MzQ5IDE0LjYyMDRMMjYuMTE2NCAxNC43MzU4QzI1LjczMSAxNC43NTU0IDI1LjQzODkgMTUuMDk5MSAyNS40OTc4IDE1LjQ3OTVDMjUuNjUgMTYuNDM5MyAyNS45NjkxIDE3LjI5MzYgMjYuNDU1MSAxOC4wNDIyQzI3LjA2MTQgMTguOTY1MiAyNy45MTA4IDE5LjY5MTggMjguOTk4MiAyMC4xOTVDMzAuMDgzMiAyMC43MDggMzEuMzc5MiAyMC45NjA5IDMyLjkwMTEgMjAuOTYwOUMzNC4yODggMjAuOTYwOSAzNS40ODEgMjAuNzQ3MyAzNi40OTQ4IDIwLjMyMjZDMzcuNTExMSAxOS44OTU1IDM4LjI4OTIgMTkuMjgxOSAzOC44NDY0IDE4LjQ3NDNDMzkuMzk2MyAxNy42NjkxIDM5LjY3MzYgMTYuNzI0MSAzOS42NzM2IDE1LjYzNDJDMzkuNjczNiAxNC43MzMzIDM5LjQ3NDggMTMuOTQ3OCAzOS4wNzcxIDEzLjI1MzFDMzguNjg0NCAxMi41NTg1IDM4LjAwOTQgMTEuOTU5NSAzNy4wNjE4IDExLjQ1NjNMMzcuMDY0MyAxMS40NDg5Wk05My45MDc1IDcuMjA3MjRIOTIuOTAxMUM5MS45MzE1IDcuMjA3MjQgOTEuMTgwMyA3LjUxNDA4IDkwLjYyOCA4LjExNTQ3TDkwLjYxODIgOC4xMDU2NkM5MC4yMjU1IDguNTM3NjggODkuOTI2IDkuMTYzNjMgODkuNjk3NyA5Ljk3ODU4TDg5LjYzMTQgNy44MzMxOUM4OS42MTkyIDcuNDc5NzEgODkuMzMyIDcuMTk5ODggODguOTc4NSA3LjE5OTg4SDg2LjcxMjhDODYuMzQ5NSA3LjE5OTg4IDg2LjA1OTkgNy40OTE5OCA4Ni4wNTk5IDcuODUyODJWMjAuMDIzMkM4Ni4wNTk5IDIwLjM4NjUgODYuMzUyIDIwLjY3NjEgODYuNzEyOCAyMC42NzYxSDg5LjE2NzVDODkuNTMwOCAyMC42NzYxIDg5LjgyMDQgMjAuMzg0IDg5LjgyMDQgMjAuMDIzMlYxMy4xMTA4Qzg5LjgyMDQgMTIuNDI1OSA4OS45NDA3IDExLjg3ODUgOTAuMTU5MiAxMS40NzU5QzkwLjM3NzcgMTEuMDczNCA5MC43MjM4IDEwLjc4MTMgOTEuMTc1NCAxMC41OTk2QzkxLjYyOTYgMTAuNDE4IDkyLjE5NjYgMTAuMzIyMiA5Mi45MDg0IDEwLjMyMjJIOTMuOTE0OUM5NC4yNzgyIDEwLjMyMjIgOTQuNTY3OCAxMC4wMzAxIDk0LjU2NzggOS42NjkyOVY3Ljg2MDE5Qzk0LjU2NzggNy40OTY4OSA5NC4yNzU3IDcuMjA3MjQgOTMuOTE0OSA3LjIwNzI0TDkzLjkxIDcuMjAyMzNMOTMuOTA3NSA3LjIwNzI0Wk04Mi45NTIyIDIuNTMxMDZIODAuMzgyMkM4MC4wMTg5IDIuNTMxMDYgNzkuNzI5MiAyLjgyMzE3IDc5LjcyOTIgMy4xODQwMVY0Ljg5MDAxQzc5LjcyOTIgNS4yNTMzMSA4MC4wMjEzIDUuNTQyOTYgODAuMzgyMiA1LjU0Mjk2SDgyLjk1MjJDODMuMzE1NSA1LjU0Mjk2IDgzLjYwNTIgNS4yNTA4NSA4My42MDUyIDQuODkwMDFWMy4xODQwMUM4My42MDUyIDIuODIwNzEgODMuMzEzMSAyLjUzMTA2IDgyLjk1MjIgMi41MzEwNlpNODIuOTE1NCA3LjIwMjMzSDgwLjQ2MDdDODAuMDk3NCA3LjIwMjMzIDc5LjgwNzggNy40OTQ0NCA3OS44MDc4IDcuODU1MjhWMjAuMDI1NkM3OS44MDc4IDIwLjM4ODkgODAuMDk5OSAyMC42Nzg2IDgwLjQ2MDcgMjAuNjc4Nkg4Mi45MTU0QzgzLjI3ODcgMjAuNjc4NiA4My41Njg0IDIwLjM4NjUgODMuNTY4NCAyMC4wMjU2VjcuODU1MjhDODMuNTY4NCA3LjQ5MTk4IDgzLjI3NjIgNy4yMDIzMyA4Mi45MTU0IDcuMjAyMzNaTTEwNy4yIDEwLjI5NTJDMTA2LjY1NSA5LjIxMjcyIDEwNS44ODYgOC4zNjgzMSAxMDQuOTAyIDcuNzg2NTVDMTAzLjkyIDcuMjAyMzMgMTAyLjc5MyA2LjkxMDIyIDEwMS40MjYgNi45MTAyMkMxMDAuMDU5IDYuOTEwMjIgOTguODY4NCA3LjIwMjMzIDk3Ljg2OTQgNy43ODY1NUM5Ni44NzAzIDguMzcwNzYgOTYuMDgyNCA5LjE5MDYzIDk1LjUyNTEgMTAuMjMxNEM5NC45Njc5IDExLjI3MjIgOTQuNjgzMiAxMi41MTQzIDk0LjY4MzIgMTMuOTQwNEM5NC42ODMyIDE1LjM2NjYgOTQuOTYwNiAxNi42MDg3IDk1LjUyNTEgMTcuNjY0MkM5Ni4wODI0IDE4LjcyMjIgOTYuODcwMyAxOS41MzIyIDk3Ljg3NjcgMjAuMTA5MUM5OC44ODMyIDIwLjY4MzUgMTAwLjA3MSAyMC45NzU2IDEwMS40NTEgMjAuOTc1NkMxMDUuMjQ4IDIwLjk3NTYgMTA2Ljg4MyAxOC43MjQ2IDEwNy41MTQgMTcuNDA0QzEwNy43MjIgMTYuOTY5NSAxMDcuNDAzIDE2LjQ2ODggMTA2LjkyMiAxNi40Njg4SDEwNC40NjVDMTA0LjIxMiAxNi40Njg4IDEwMy45ODYgMTYuNjIxIDEwMy44NzEgMTYuODQ2OEMxMDMuNjg1IDE3LjIxMjUgMTAzLjQyOSAxNy40OTczIDEwMy4xMSAxNy43MDFDMTAyLjY4NSAxNy45Njg2IDEwMi4xNTMgMTguMTAzNiAxMDEuNTE5IDE4LjEwMzZDMTAwLjY0NiAxOC4xMDM2IDk5Ljk1NTggMTcuODQzNCA5OS40MjU2IDE3LjMyMDZDOTguOTA1MiAxNi44MDAyIDk4LjYxNTYgMTYuMDAyNCA5OC41NjE2IDE0LjkyNzJIMTA4LjAwMlYxNC4xNzEyTDEwOC4wMSAxNC4xODg0QzEwOC4wMSAxMi42ODM2IDEwNy43MzIgMTEuMzkyNSAxMDcuMiAxMC4yOTI4SDEwNy4xOTVMMTA3LjIgMTAuMjk1MlpNOTguNTczOSAxMi42NDE5Qzk4LjY3NyAxMS43MDE4IDk4Ljk4MTMgMTAuOTc1MiA5OS40OTQ0IDEwLjQ2NDZDMTAwLjAwNyA5Ljk1MTU4IDEwMC42NTEgOS42OTg3NSAxMDEuNDM2IDkuNjk4NzVDMTAyLjIyMiA5LjY5ODc1IDEwMi44NiA5Ljk0NDIyIDEwMy4zNTYgMTAuNDM1MkMxMDMuODUxIDEwLjkyNjEgMTA0LjExOSAxMS42NTc2IDEwNC4xNjYgMTIuNjQ0NEg5OC41NjlMOTguNTczOSAxMi42NDE5WiIgZmlsbD0iIzI4MTcxQiIvPgo8cGF0aCBkPSJNNi4zOTIxNyAxNC45NjkySDkuMjAyNzlDMTEuMDQzOCAxNC45NjkyIDEyLjUzNjMgMTMuNDc2NyAxMi41MzYzIDExLjYzNTdWOC44MzczN0MxMi41MzYzIDcuNDE4NTYgMTQuMjUyMSA2LjcwOTE1IDE1LjI1MzYgNy43MTA2NkwxNy42MTAxIDEwLjA2NzJDMTcuOTA5NiAxMC4zNjY2IDE4LjA3NjUgMTAuNzcxNyAxOC4wNzY1IDExLjE5MzlWMTguOTE2M0MxOC4wNzY1IDE5Ljc5NTEgMTcuMzY0NiAyMC41MDk0IDE2LjQ4MzQgMjAuNTA5NEg4Ljc1ODQ5QzguMzM2MjkgMjAuNTA5NCA3LjkzMzcyIDIwLjM0MjUgNy42MzQyNSAyMC4wNDU1TDUuMjY3OTMgMTcuNjg5QzQuMjYxNSAxNi42ODc1IDQuOTcwOTEgMTQuOTY5MiA2LjM5MjE3IDE0Ljk2OTJaIiBmaWxsPSIjMjgxNzFCIi8+CjxwYXRoIGQ9Ik0xMi4wMTczIDYuMTAyNzRIOS4yMDY3MUM3LjM2NTY5IDYuMTAyNzQgNS44NzMyNCA3LjU5NTE5IDUuODczMjQgOS40MzYyMVYxMi4yMzQ2QzUuODczMjQgMTMuNjUzNCA0LjE1NzQxIDE0LjM2MjggMy4xNTU5IDEzLjM2MTNMMC43OTkzOTkgMTAuOTk5OEMwLjQ5OTkyNyAxMC43MDA0IDAuMzMzMDA4IDEwLjI5NTMgMC4zMzMwMDggOS44NzMxNFYyLjE1MzE1QzAuMzMzMDA4IDEuMjcxOTIgMS4wNDQ4NyAwLjU2MDA1OSAxLjkyNjEgMC41NjAwNTlIOS42NTFDMTAuMDczMiAwLjU2MDA1OSAxMC40NzU4IDAuNzI2OTc3IDEwLjc3NTMgMS4wMjM5OUwxMy4xNDE2IDMuMzgwNDlDMTQuMTQ4IDQuMzgyMDEgMTMuNDM4NiA2LjEwMDI5IDEyLjAxNzMgNi4xMDAyOVY2LjEwMjc0WiIgZmlsbD0iIzI4MTcxQiIvPgo8L3N2Zz4K" alt="" width="108" height="27" decoding="async" />
    </a>
    <div class="nav-links">
      <a href="#products">Product</a>
      <a href="#">About</a>
      <a href="#">Use Case</a>
      <a href="#">Blog</a>
      <a href="https://docs.skyfire.xyz/" target="_blank" rel="noopener">Docs</a>
      <a href="#">Contact</a>
    </div>
    <a class="btn btn--header" href="https://app.skyfire.xyz/">Launch Skyfire</a>
  </div>
</nav>

<!-- ============ HERO ============ -->
<header class="hero">
  <div class="wrap hero-grid">
    <div class="hero-content">
      <h1 class="reveal">
        <span>Access.</span><br>
        <span>Identity.</span><br>
        <span>Checkout.</span><br>
        <span class="stack">The Agent Trust Stack.</span>
      </h1>
      <p class="hero-sub reveal">
        Skyfire gives agents <strong>verified identity and payment credentials</strong> that work across the open internet. No 403 errors, captchas or blocked checkouts. Authenticated access and payment capability, everywhere your agents need to be.
      </p>
      <div class="hero-ctas reveal">
        <a class="btn btn--secondary" href="https://skyfire.xyz/use-case/">
          See Use Cases <span class="arr">→</span>
        </a>
      </div>
    </div>

    <div class="hero-diagram reveal">
      <svg class="hero-svg" viewBox="0 0 480 520" fill="none" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <marker id="ah" markerWidth="7" markerHeight="7" refX="5" refY="3.5" orient="auto">
            <path d="M0,0.5 L0,6.5 L6,3.5 z" fill="rgba(255,255,255,0.6)"/>
          </marker>
          <marker id="ah-teal" markerWidth="7" markerHeight="7" refX="5" refY="3.5" orient="auto">
            <path d="M0,0.5 L0,6.5 L6,3.5 z" fill="#59AD9E"/>
          </marker>
          <filter id="skyfire-glow" x="-60%" y="-60%" width="220%" height="220%">
            <feGaussianBlur in="SourceGraphic" stdDeviation="10"/>
          </filter>
          <linearGradient id="bar-grad" x1="0" x2="1" y1="0" y2="0">
            <stop offset="0%"  stop-color="rgba(255,255,255,0.10)"/>
            <stop offset="50%" stop-color="rgba(89,173,158,0.14)"/>
            <stop offset="100%" stop-color="rgba(255,255,255,0.10)"/>
          </linearGradient>
          <radialGradient id="dest-grad" cx="50%" cy="40%" r="70%">
            <stop offset="0%"  stop-color="rgba(255,255,255,0.14)"/>
            <stop offset="100%" stop-color="rgba(255,255,255,0.04)"/>
          </radialGradient>
          <clipPath id="bar-clip">
            <rect x="40" y="258" width="400" height="76" rx="14"/>
          </clipPath>
        </defs>

        <!-- Skyfire teal glow halo (top) -->
        <rect x="156" y="8" width="168" height="112" rx="24" fill="#1B7A69" opacity="0.42" filter="url(#skyfire-glow)"/>

        <!-- Skyfire box (top, center) -->
        <rect class="skyfire-node" x="180" y="24" width="120" height="80" rx="16" fill="#1B7A69" stroke="rgba(89,173,158,0.7)" stroke-width="2"/>
        <image class="sf-logo-mark" href="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTA4IiBoZWlnaHQ9IjI3IiB2aWV3Qm94PSIwIDAgMTA4IDI3IiBmaWxsPSJub25lIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgo8cGF0aCBkPSJNNzcuMjg5MyAyLjUyMTI0SDc0LjI5OTVDNzIuNzggMi41MjEyNCA3MS42NTU4IDIuODg2OTkgNzAuOTM5IDMuNjEzNThDNzAuMjIyMiA0LjM0MDE2IDY5Ljg2MTQgNS4zNzM1OSA2OS44NjE0IDYuNzEzODVWMjAuMDI4MUM2OS44NjE0IDIwLjM5MTQgNzAuMTUzNSAyMC42ODEgNzAuNTE0MyAyMC42ODFINzIuOTY5QzczLjMzMjMgMjAuNjgxIDczLjYyMiAyMC4zODg5IDczLjYyMiAyMC4wMjgxVjExLjU1Mkg3Ni42MjlDNzYuOTkyMiAxMS41NTIgNzcuMjgxOSAxMS4yNTk5IDc3LjI4MTkgMTAuODk5MVY5LjE4ODE3Qzc3LjI4MTkgOC44MjQ4OCA3Ni45ODk4IDguNTM1MjMgNzYuNjI5IDguNTM1MjNINzMuNjIyVjcuMTEzOTZDNzMuNjIyIDYuNTk2MDIgNzMuNzM5OCA2LjIxMzA5IDczLjk3MDUgNS45NTI4OUM3NC4yMDYyIDUuNjkwMjQgNzQuNTg0MiA1LjU2MjYgNzUuMTAyMSA1LjU2MjZINzYuNzIyMkM3Ny4wMDQ1IDUuNTYyNiA3Ny4yNTQ5IDUuMzgwOTUgNzcuMzQzMyA1LjExMzM5TDc3LjkxMjggMy4zODI4NEM3OC4wNTAyIDIuOTYwNjMgNzcuNzM4NSAyLjUyMzY5IDc3LjI5MTcgMi41MjM2OUw3Ny4yODkzIDIuNTIxMjRaTTczLjk4MDMgNS45NDA2MkM3My45ODAzIDUuOTQwNjIgNzMuOTc1NCA1Ljk0Nzk4IDczLjk3MyA1Ljk1MDQ0TDczLjk4MDMgNS45NDA2MlpNNjcuOTYxNSA3LjI0NjUxSDY1LjU1NTlDNjUuMjc4NSA3LjI0NjUxIDY1LjAzNTUgNy40MjA4IDY0LjkzOTcgNy42ODA5OUw2MS41MDA3IDE3LjIzOTVMNTcuOTkzIDcuNjgzNDVDNTcuODk3MiA3LjQyNTcxIDU3LjY1NDIgNy4yNTM4OCA1Ny4zNzkzIDcuMjUzODhINTAuNzMyQzUwLjUwMzcgNy4yNTM4OCA1MC4yOTAyIDcuMzc0MTYgNTAuMTcyMyA3LjU3MDUzTDQ2LjM0NzkgMTMuOTA4NUw1MC4xNzIzIDIwLjI0NjVDNTAuMjkwMiAyMC40NDI5IDUwLjUwMTMgMjAuNTYzMiA1MC43MzIgMjAuNTYzMkg1My40OTExQzU0LjAwMTYgMjAuNTYzMiA1NC4zMTU4IDIwLjAwNiA1NC4wNTA3IDE5LjU3MTVMNTAuNjM2MyAxMy45MDg1TDUzLjU1IDkuMDg1MDhDNTMuODM0NyA4LjYxMzc4IDU0LjUzNDMgOC42ODI1MSA1NC43MjMzIDkuMTk3OTlMNTguNzcxMSAyMC4yMTQ2QzU4Ljg0NzIgMjAuNDIwOCA1OS4wNDM2IDIwLjU1ODMgNTkuMjYyIDIwLjU1ODNINTkuNTc2MkM1OS45MzQ2IDIwLjU1ODMgNjAuMTkyNCAyMC45MTQyIDYwLjA3MjEgMjEuMjUwNUM1OS43Mjg0IDIyLjIxNzcgNTguODA1NSAyMi44NjgyIDU3Ljc4NjggMjIuODY4Mkg1NC44NDYxQzU0LjQ4MjggMjIuODY4MiA1NC4xOTMxIDIzLjE2MDMgNTQuMTkzMSAyMy41MjExVjI1Ljc4NjhDNTQuMTkzMSAyNi4xNTAxIDU0LjQ4NTIgMjYuNDM5NyA1NC44NDYxIDI2LjQzOTdINTcuNzg2OEM2MC4zMDUzIDI2LjQzOTcgNjIuNTYxMSAyNC44NDQyIDYzLjQyMDMgMjIuNDYwN0w2OC41NzUxIDguMTIwMzhDNjguNzI3MyA3LjY5MzI3IDY4LjQxMzEgNy4yNDY1MSA2Ny45NTkgNy4yNDY1MUg2Ny45NjE1Wk00NC43ODY3IDIuOTIzODFINDIuMzg4NUM0Mi4wMjUyIDIuOTIzODEgNDEuNzM1NiAzLjIxNTkyIDQxLjczNTYgMy41NzY3NlYxOS44OTA2QzQxLjczNTYgMjAuMjUzOSA0Mi4wMjc3IDIwLjU0MzYgNDIuMzg4NSAyMC41NDM2SDQ0Ljc4NjdDNDUuMTUgMjAuNTQzNiA0NS40Mzk3IDIwLjI1MTUgNDUuNDM5NyAxOS44OTA2VjMuNTc2NzZDNDUuNDM5NyAzLjIxMzQ2IDQ1LjE0NzYgMi45MjM4MSA0NC43ODY3IDIuOTIzODFaTTM3LjA2NDMgMTEuNDQ4OVYxMS40MzE4QzM2LjEyMTcgMTAuOTIxMiAzNC44MzA1IDEwLjUwMzkgMzMuMTkzMyAxMC4xNzVDMzIuMjQwOCA5Ljk3NjEzIDMxLjUwMiA5Ljc2NTAzIDMwLjk4MTYgOS41NTE0N0MzMC40NjEyIDkuMzM3OTEgMzAuMDkzIDkuMDg1MDggMjkuODcyMSA4Ljc5NTQyQzI5LjY0MzggOC41MTA2OCAyOS41NDMxIDguMTQ3MzkgMjkuNTQzMSA3LjcxMjkxQzI5LjU0MzEgNy4xMDY2IDI5Ljc4ODYgNi42MDA5MyAzMC4yNzQ2IDYuMjMwMjdDMzAuNzYwNyA1Ljg0MjQzIDMxLjQzMDggNS42NTU4OCAzMi4yODk5IDUuNjU1ODhDMzIuOTY1IDUuNjU1ODggMzMuNTQ2NyA1Ljc3NjE2IDM0LjAyMjkgNi4wMjY1NEMzNC40OTQyIDYuMjc2OTEgMzQuODgyMSA2LjYyNTQ4IDM1LjE1NDYgNy4wODQ1MUMzNS4zNDg1IDcuMzkzOCAzNS40ODM1IDcuNzQ0ODIgMzUuNTY2OSA4LjEzMjY2QzM1LjYzMzIgOC40NDY4NiAzNS45MjA0IDguNjY1MzIgMzYuMjM5NSA4LjY0ODE0TDM4LjY5NDIgOC41MTgwNEMzOS4wOTY4IDguNDk4NDEgMzkuMzc5MSA4LjEyMjg0IDM5LjMwMDUgNy43MzAwOUMzOS4xMzExIDYuODcwOTUgMzguODI5MiA2LjA5NTI3IDM4LjM4OTggNS40MDMwNEMzNy44MTU0IDQuNTAyMTcgMzcuMDI3NSAzLjgwNzUgMzYuMDI4NCAzLjI5NjkyQzM1LjAyOTQgMi43ODM4OSAzMy44MDQ1IDIuNTMxMDYgMzIuMzQ2NCAyLjUzMTA2QzMwLjk3NjcgMi41MzEwNiAyOS43OTYgMi43NDk1MyAyOC43OTY5IDMuMjA4NTVDMjcuODE1IDMuNjUwNCAyNy4wNDkyIDQuMjczODkgMjYuNTQxMSA1LjA3NDEyQzI2LjAyMDcgNS44NjIwNyAyNS43NjA1IDYuNzkyNCAyNS43NjA1IDcuODUyODJDMjUuNzYwNSA4Ljg0NDUyIDI1Ljk2NjcgOS42NjkyOSAyNi4zODQgMTAuMzI0N0MyNi43OTE0IDEwLjk3NzYgMjcuNDYxNiAxMS41MjUgMjguMzcyMiAxMS45NDk3QzI5LjI4MjkgMTIuMzc2OCAzMC40ODgyIDEyLjc2NDcgMzEuOTkwNSAxMy4xMjA2QzMzLjA3NTQgMTMuMzcxIDMzLjkwMDIgMTMuNjE2NCAzNC40NjIzIDEzLjg3NjZDMzUuMDE5NSAxNC4xMjcgMzUuNCAxNC40MTQyIDM1LjU5MzkgMTQuNzIxQzM1Ljc5MjggMTUuMDI3OSAzNS44OTEgMTUuMzgzOCAzNS44OTEgMTUuODAzNkMzNS44OTEgMTYuMjQ3OSAzNS43NzA3IDE2LjYyMzQgMzUuNTQ0OCAxNi45MzI3QzM1LjMxNjYgMTcuMjM5NSAzNC45ODAzIDE3LjQ3MDMgMzQuNTQ1OCAxNy42MTc2QzM0LjExMTMgMTcuNzY0OSAzMy41NzYyIDE3Ljg0NTkgMzIuOTU1MiAxNy44NDU5QzMyLjIwMTYgMTcuODQ1OSAzMS41NjMzIDE3LjcyNTYgMzEuMDQ1NCAxNy40NzUyQzMwLjUyNSAxNy4yMjQ4IDMwLjExNzUgMTYuODU5MSAyOS44MTA3IDE2LjM3MDZDMjkuNTgyNCAxNi4wMDczIDI5LjQxMDYgMTUuNTg3NSAyOS4yOTc3IDE1LjExMTNDMjkuMjI2NSAxNC44MDk0IDI4Ljk0NDIgMTQuNjA1NyAyOC42MzQ5IDE0LjYyMDRMMjYuMTE2NCAxNC43MzU4QzI1LjczMSAxNC43NTU0IDI1LjQzODkgMTUuMDk5MSAyNS40OTc4IDE1LjQ3OTVDMjUuNjUgMTYuNDM5MyAyNS45NjkxIDE3LjI5MzYgMjYuNDU1MSAxOC4wNDIyQzI3LjA2MTQgMTguOTY1MiAyNy45MTA4IDE5LjY5MTggMjguOTk4MiAyMC4xOTVDMzAuMDgzMiAyMC43MDggMzEuMzc5MiAyMC45NjA5IDMyLjkwMTEgMjAuOTYwOUMzNC4yODggMjAuOTYwOSAzNS40ODEgMjAuNzQ3MyAzNi40OTQ4IDIwLjMyMjZDMzcuNTExMSAxOS44OTU1IDM4LjI4OTIgMTkuMjgxOSAzOC44NDY0IDE4LjQ3NDNDMzkuMzk2MyAxNy42NjkxIDM5LjY3MzYgMTYuNzI0MSAzOS42NzM2IDE1LjYzNDJDMzkuNjczNiAxNC43MzMzIDM5LjQ3NDggMTMuOTQ3OCAzOS4wNzcxIDEzLjI1MzFDMzguNjg0NCAxMi41NTg1IDM4LjAwOTQgMTEuOTU5NSAzNy4wNjE4IDExLjQ1NjNMMzcuMDY0MyAxMS40NDg5Wk05My45MDc1IDcuMjA3MjRIOTIuOTAxMUM5MS45MzE1IDcuMjA3MjQgOTEuMTgwMyA3LjUxNDA4IDkwLjYyOCA4LjExNTQ3TDkwLjYxODIgOC4xMDU2NkM5MC4yMjU1IDguNTM3NjggODkuOTI2IDkuMTYzNjMgODkuNjk3NyA5Ljk3ODU4TDg5LjYzMTQgNy44MzMxOUM4OS42MTkyIDcuNDc5NzEgODkuMzMyIDcuMTk5ODggODguOTc4NSA3LjE5OTg4SDg2LjcxMjhDODYuMzQ5NSA3LjE5OTg4IDg2LjA1OTkgNy40OTE5OCA4Ni4wNTk5IDcuODUyODJWMjAuMDIzMkM4Ni4wNTk5IDIwLjM4NjUgODYuMzUyIDIwLjY3NjEgODYuNzEyOCAyMC42NzYxSDg5LjE2NzVDODkuNTMwOCAyMC42NzYxIDg5LjgyMDQgMjAuMzg0IDg5LjgyMDQgMjAuMDIzMlYxMy4xMTA4Qzg5LjgyMDQgMTIuNDI1OSA4OS45NDA3IDExLjg3ODUgOTAuMTU5MiAxMS40NzU5QzkwLjM3NzcgMTEuMDczNCA5MC43MjM4IDEwLjc4MTMgOTEuMTc1NCAxMC41OTk2QzkxLjYyOTYgMTAuNDE4IDkyLjE5NjYgMTAuMzIyMiA5Mi45MDg0IDEwLjMyMjJIOTMuOTE0OUM5NC4yNzgyIDEwLjMyMjIgOTQuNTY3OCAxMC4wMzAxIDk0LjU2NzggOS42NjkyOVY3Ljg2MDE5Qzk0LjU2NzggNy40OTY4OSA5NC4yNzU3IDcuMjA3MjQgOTMuOTE0OSA3LjIwNzI0TDkzLjkxIDcuMjAyMzNMOTMuOTA3NSA3LjIwNzI0Wk04Mi45NTIyIDIuNTMxMDZIODAuMzgyMkM4MC4wMTg5IDIuNTMxMDYgNzkuNzI5MiAyLjgyMzE3IDc5LjcyOTIgMy4xODQwMVY0Ljg5MDAxQzc5LjcyOTIgNS4yNTMzMSA4MC4wMjEzIDUuNTQyOTYgODAuMzgyMiA1LjU0Mjk2SDgyLjk1MjJDODMuMzE1NSA1LjU0Mjk2IDgzLjYwNTIgNS4yNTA4NSA4My42MDUyIDQuODkwMDFWMy4xODQwMUM4My42MDUyIDIuODIwNzEgODMuMzEzMSAyLjUzMTA2IDgyLjk1MjIgMi41MzEwNlpNODIuOTE1NCA3LjIwMjMzSDgwLjQ2MDdDODAuMDk3NCA3LjIwMjMzIDc5LjgwNzggNy40OTQ0NCA3OS44MDc4IDcuODU1MjhWMjAuMDI1NkM3OS44MDc4IDIwLjM4ODkgODAuMDk5OSAyMC42Nzg2IDgwLjQ2MDcgMjAuNjc4Nkg4Mi45MTU0QzgzLjI3ODcgMjAuNjc4NiA4My41Njg0IDIwLjM4NjUgODMuNTY4NCAyMC4wMjU2VjcuODU1MjhDODMuNTY4NCA3LjQ5MTk4IDgzLjI3NjIgNy4yMDIzMyA4Mi45MTU0IDcuMjAyMzNaTTEwNy4yIDEwLjI5NTJDMTA2LjY1NSA5LjIxMjcyIDEwNS44ODYgOC4zNjgzMSAxMDQuOTAyIDcuNzg2NTVDMTAzLjkyIDcuMjAyMzMgMTAyLjc5MyA2LjkxMDIyIDEwMS40MjYgNi45MTAyMkMxMDAuMDU5IDYuOTEwMjIgOTguODY4NCA3LjIwMjMzIDk3Ljg2OTQgNy43ODY1NUM5Ni44NzAzIDguMzcwNzYgOTYuMDgyNCA5LjE5MDYzIDk1LjUyNTEgMTAuMjMxNEM5NC45Njc5IDExLjI3MjIgOTQuNjgzMiAxMi41MTQzIDk0LjY4MzIgMTMuOTQwNEM5NC42ODMyIDE1LjM2NjYgOTQuOTYwNiAxNi42MDg3IDk1LjUyNTEgMTcuNjY0MkM5Ni4wODI0IDE4LjcyMjIgOTYuODcwMyAxOS41MzIyIDk3Ljg3NjcgMjAuMTA5MUM5OC44ODMyIDIwLjY4MzUgMTAwLjA3MSAyMC45NzU2IDEwMS40NTEgMjAuOTc1NkMxMDUuMjQ4IDIwLjk3NTYgMTA2Ljg4MyAxOC43MjQ2IDEwNy41MTQgMTcuNDA0QzEwNy43MjIgMTYuOTY5NSAxMDcuNDAzIDE2LjQ2ODggMTA2LjkyMiAxNi40Njg4SDEwNC40NjVDMTA0LjIxMiAxNi40Njg4IDEwMy45ODYgMTYuNjIxIDEwMy44NzEgMTYuODQ2OEMxMDMuNjg1IDE3LjIxMjUgMTAzLjQyOSAxNy40OTczIDEwMy4xMSAxNy43MDFDMTAyLjY4NSAxNy45Njg2IDEwMi4xNTMgMTguMTAzNiAxMDEuNTE5IDE4LjEwMzZDMTAwLjY0NiAxOC4xMDM2IDk5Ljk1NTggMTcuODQzNCA5OS40MjU2IDE3LjMyMDZDOTguOTA1MiAxNi44MDAyIDk4LjYxNTYgMTYuMDAyNCA5OC41NjE2IDE0LjkyNzJIMTA4LjAwMlYxNC4xNzEyTDEwOC4wMSAxNC4xODg0QzEwOC4wMSAxMi42ODM2IDEwNy43MzIgMTEuMzkyNSAxMDcuMiAxMC4yOTI4SDEwNy4xOTVMMTA3LjIgMTAuMjk1MlpNOTguNTczOSAxMi42NDE5Qzk4LjY3NyAxMS43MDE4IDk4Ljk4MTMgMTAuOTc1MiA5OS40OTQ0IDEwLjQ2NDZDMTAwLjAwNyA5Ljk1MTU4IDEwMC42NTEgOS42OTg3NSAxMDEuNDM2IDkuNjk4NzVDMTAyLjIyMiA5LjY5ODc1IDEwMi44NiA5Ljk0NDIyIDEwMy4zNTYgMTAuNDM1MkMxMDMuODUxIDEwLjkyNjEgMTA0LjExOSAxMS42NTc2IDEwNC4xNjYgMTIuNjQ0NEg5OC41NjlMOTguNTczOSAxMi42NDE5WiIgZmlsbD0iIzI4MTcxQiIvPgo8cGF0aCBkPSJNNi4zOTIxNyAxNC45NjkySDkuMjAyNzlDMTEuMDQzOCAxNC45NjkyIDEyLjUzNjMgMTMuNDc2NyAxMi41MzYzIDExLjYzNTdWOC44MzczN0MxMi41MzYzIDcuNDE4NTYgMTQuMjUyMSA2LjcwOTE1IDE1LjI1MzYgNy43MTA2NkwxNy42MTAxIDEwLjA2NzJDMTcuOTA5NiAxMC4zNjY2IDE4LjA3NjUgMTAuNzcxNyAxOC4wNzY1IDExLjE5MzlWMTguOTE2M0MxOC4wNzY1IDE5Ljc5NTEgMTcuMzY0NiAyMC41MDk0IDE2LjQ4MzQgMjAuNTA5NEg4Ljc1ODQ5QzguMzM2MjkgMjAuNTA5NCA3LjkzMzcyIDIwLjM0MjUgNy42MzQyNSAyMC4wNDU1TDUuMjY3OTMgMTcuNjg5QzQuMjYxNSAxNi42ODc1IDQuOTcwOTEgMTQuOTY5MiA2LjM5MjE3IDE0Ljk2OTJaIiBmaWxsPSIjMjgxNzFCIi8+CjxwYXRoIGQ9Ik0xMi4wMTczIDYuMTAyNzRIOS4yMDY3MUM3LjM2NTY5IDYuMTAyNzQgNS44NzMyNCA3LjU5NTE5IDUuODczMjQgOS40MzYyMVYxMi4yMzQ2QzUuODczMjQgMTMuNjUzNCA0LjE1NzQxIDE0LjM2MjggMy4xNTU5IDEzLjM2MTNMMC43OTkzOTkgMTAuOTk5OEMwLjQ5OTkyNyAxMC43MDA0IDAuMzMzMDA4IDEwLjI5NTMgMC4zMzMwMDggOS44NzMxNFYyLjE1MzE1QzAuMzMzMDA4IDEuMjcxOTIgMS4wNDQ4NyAwLjU2MDA1OSAxLjkyNjEgMC41NjAwNTlIOS42NTFDMTAuMDczMiAwLjU2MDA1OSAxMC40NzU4IDAuNzI2OTc3IDEwLjc3NTMgMS4wMjM5OUwxMy4xNDE2IDMuMzgwNDlDMTQuMTQ4IDQuMzgyMDEgMTMuNDM4NiA2LjEwMDI5IDEyLjAxNzMgNi4xMDAyOVY2LjEwMjc0WiIgZmlsbD0iIzI4MTcxQiIvPgo8L3N2Zz4K" x="198" y="42" width="84" height="22"/>
        <text x="240" y="84" text-anchor="middle" fill="rgba(255,255,255,0.9)" font-size="11" font-family="Inter,sans-serif" font-weight="400" letter-spacing="0.3">Agent Wallet</text>

        <!-- Skyfire → Agent arrow (vertical) -->
        <line class="kf" x1="240" y1="104" x2="240" y2="148" stroke="rgba(89,173,158,0.75)" stroke-width="1.8" marker-end="url(#ah-teal)"/>
        <rect x="220" y="117" width="40" height="18" rx="9" fill="rgba(201,60,9,0.95)"/>
        <text x="240" y="130" text-anchor="middle" fill="white" font-size="10" font-family="Inter,sans-serif" font-weight="600" letter-spacing="0.8">KYA</text>

        <!-- Agent box -->
        <rect x="200" y="150" width="80" height="60" rx="14" fill="rgba(255,255,255,0.07)" stroke="rgba(255,255,255,0.34)" stroke-width="2"/>
        <g transform="translate(229.000 184.000) scale(0.02292)"><path d="M280-80 240-200l-120-40 120-40 40-120 40 120 120 40-120 40-40 120Zm480 0-40-120-120-40 120-40 40-120 40 120 120 40-120 40-40 120ZM480-280l-60-180-180-60 180-60 60-180 60 180 180 60-180 60-60 180Z" fill="rgba(255,255,255,0.9)"/></g>
        <text x="240" y="200" text-anchor="middle" fill="white" font-size="14" font-family="Geist,Inter,sans-serif" font-weight="500" letter-spacing="-0.3">Agent</text>

        <!-- Agent → Security arrow (vertical) — KYA restored -->
        <line class="kf5" x1="240" y1="210" x2="240" y2="252" stroke="rgba(255,255,255,0.55)" stroke-width="1.8" marker-end="url(#ah)"/>
        <rect x="220" y="221" width="40" height="18" rx="9" fill="rgba(201,60,9,0.95)"/>
        <text x="240" y="234" text-anchor="middle" fill="white" font-size="10" font-family="Inter,sans-serif" font-weight="600" letter-spacing="0.8">KYA</text>

        <!-- Security bar (horizontal) -->
        <rect x="40" y="258" width="400" height="76" rx="14" fill="url(#bar-grad)" stroke="rgba(255,255,255,0.24)" stroke-width="1.2"/>
        <text x="56" y="250" fill="rgba(255,255,255,0.5)" font-size="9" font-family="Inter,sans-serif" font-weight="600" letter-spacing="1.8">SECURITY</text>

        <!-- Cycling brand logos inside the security bar (horizontal scroll) -->
        <g clip-path="url(#bar-clip)">
          <g class="logo-reel">
            <image href="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+CjwhLS0gQ3JlYXRlZCB3aXRoIElua3NjYXBlIChodHRwOi8vd3d3Lmlua3NjYXBlLm9yZy8pIC0tPgoKPHN2ZwogICB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iCiAgIHhtbG5zOmNjPSJodHRwOi8vY3JlYXRpdmVjb21tb25zLm9yZy9ucyMiCiAgIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyIKICAgeG1sbnM6c3ZnPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIKICAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogICB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIKICAgeG1sbnM6c29kaXBvZGk9Imh0dHA6Ly9zb2RpcG9kaS5zb3VyY2Vmb3JnZS5uZXQvRFREL3NvZGlwb2RpLTAuZHRkIgogICB4bWxuczppbmtzY2FwZT0iaHR0cDovL3d3dy5pbmtzY2FwZS5vcmcvbmFtZXNwYWNlcy9pbmtzY2FwZSIKICAgdmVyc2lvbj0iMS4xIgogICBpZD0ic3ZnODM0IgogICB4bWw6c3BhY2U9InByZXNlcnZlIgogICB3aWR0aD0iNDA5LjMzMjkyIgogICBoZWlnaHQ9IjE2Ni43NTA1OCIKICAgdmlld0JveD0iMCAwIDQwOS4zMzI5MiAxNjYuNzUwNTgiCiAgIHNvZGlwb2RpOmRvY25hbWU9IlBoYXNlZFJlbGVhc2UtQ1Muc3ZnIgogICBpbmtzY2FwZTp2ZXJzaW9uPSIwLjkyLjIgNWMzZTgwZCwgMjAxNy0wOC0wNiI+PG1ldGFkYXRhCiAgICAgaWQ9Im1ldGFkYXRhODQwIj48cmRmOlJERj48Y2M6V29yawogICAgICAgICByZGY6YWJvdXQ9IiI+PGRjOmZvcm1hdD5pbWFnZS9zdmcreG1sPC9kYzpmb3JtYXQ+PGRjOnR5cGUKICAgICAgICAgICByZGY6cmVzb3VyY2U9Imh0dHA6Ly9wdXJsLm9yZy9kYy9kY21pdHlwZS9TdGlsbEltYWdlIiAvPjxkYzp0aXRsZT48L2RjOnRpdGxlPjwvY2M6V29yaz48L3JkZjpSREY+PC9tZXRhZGF0YT48ZGVmcwogICAgIGlkPSJkZWZzODM4Ij48Y2xpcFBhdGgKICAgICAgIGNsaXBQYXRoVW5pdHM9InVzZXJTcGFjZU9uVXNlIgogICAgICAgaWQ9ImNsaXBQYXRoODUyIj48cGF0aAogICAgICAgICBkPSJNIDAsMCBIIDYxMiBWIDc5MiBIIDAgWiIKICAgICAgICAgaWQ9InBhdGg4NTAiCiAgICAgICAgIGlua3NjYXBlOmNvbm5lY3Rvci1jdXJ2YXR1cmU9IjAiIC8+PC9jbGlwUGF0aD48Y2xpcFBhdGgKICAgICAgIGNsaXBQYXRoVW5pdHM9InVzZXJTcGFjZU9uVXNlIgogICAgICAgaWQ9ImNsaXBQYXRoODYwIj48cGF0aAogICAgICAgICBkPSJtIC03NDkuMzY5LC00NS40MzkzIGggMiB2IC01OC43ODQ3IGggLTIgeiIKICAgICAgICAgaWQ9InBhdGg4NTgiCiAgICAgICAgIGlua3NjYXBlOmNvbm5lY3Rvci1jdXJ2YXR1cmU9IjAiIC8+PC9jbGlwUGF0aD48Y2xpcFBhdGgKICAgICAgIGNsaXBQYXRoVW5pdHM9InVzZXJTcGFjZU9uVXNlIgogICAgICAgaWQ9ImNsaXBQYXRoMTI1NiI+PHBhdGgKICAgICAgICAgZD0iTSAzNiwzOTEuNTIgSCAzMDQuMjI5IFYgMjcxLjQ3NSBIIDM2IFoiCiAgICAgICAgIGlkPSJwYXRoMTI1NCIKICAgICAgICAgaW5rc2NhcGU6Y29ubmVjdG9yLWN1cnZhdHVyZT0iMCIgLz48L2NsaXBQYXRoPjxjbGlwUGF0aAogICAgICAgY2xpcFBhdGhVbml0cz0idXNlclNwYWNlT25Vc2UiCiAgICAgICBpZD0iY2xpcFBhdGgxMzY4Ij48cGF0aAogICAgICAgICBkPSJNIDAsMCBIIDYxMiBWIDc5MiBIIDAgWiIKICAgICAgICAgaWQ9InBhdGgxMzY2IgogICAgICAgICBpbmtzY2FwZTpjb25uZWN0b3ItY3VydmF0dXJlPSIwIiAvPjwvY2xpcFBhdGg+PGNsaXBQYXRoCiAgICAgICBjbGlwUGF0aFVuaXRzPSJ1c2VyU3BhY2VPblVzZSIKICAgICAgIGlkPSJjbGlwUGF0aDEzOTYiPjxwYXRoCiAgICAgICAgIGQ9Ik0gMCwwIEggNjEyIFYgNzkyIEggMCBaIgogICAgICAgICBpZD0icGF0aDEzOTQiCiAgICAgICAgIGlua3NjYXBlOmNvbm5lY3Rvci1jdXJ2YXR1cmU9IjAiIC8+PC9jbGlwUGF0aD48Y2xpcFBhdGgKICAgICAgIGNsaXBQYXRoVW5pdHM9InVzZXJTcGFjZU9uVXNlIgogICAgICAgaWQ9ImNsaXBQYXRoMTQzMiI+PHBhdGgKICAgICAgICAgZD0iTSAwLDAgSCA2MTIgViA3OTIgSCAwIFoiCiAgICAgICAgIGlkPSJwYXRoMTQzMCIKICAgICAgICAgaW5rc2NhcGU6Y29ubmVjdG9yLWN1cnZhdHVyZT0iMCIgLz48L2NsaXBQYXRoPjwvZGVmcz48c29kaXBvZGk6bmFtZWR2aWV3CiAgICAgcGFnZWNvbG9yPSIjZmZmZmZmIgogICAgIGJvcmRlcmNvbG9yPSIjNjY2NjY2IgogICAgIGJvcmRlcm9wYWNpdHk9IjEiCiAgICAgb2JqZWN0dG9sZXJhbmNlPSIxMCIKICAgICBncmlkdG9sZXJhbmNlPSIxMCIKICAgICBndWlkZXRvbGVyYW5jZT0iMTAiCiAgICAgaW5rc2NhcGU6cGFnZW9wYWNpdHk9IjAiCiAgICAgaW5rc2NhcGU6cGFnZXNoYWRvdz0iMiIKICAgICBpbmtzY2FwZTp3aW5kb3ctd2lkdGg9IjEzODIiCiAgICAgaW5rc2NhcGU6d2luZG93LWhlaWdodD0iOTQ1IgogICAgIGlkPSJuYW1lZHZpZXc4MzYiCiAgICAgc2hvd2dyaWQ9ImZhbHNlIgogICAgIGZpdC1tYXJnaW4tdG9wPSIwIgogICAgIGZpdC1tYXJnaW4tbGVmdD0iMCIKICAgICBmaXQtbWFyZ2luLXJpZ2h0PSIwIgogICAgIGZpdC1tYXJnaW4tYm90dG9tPSIwIgogICAgIGlua3NjYXBlOnpvb209IjEiCiAgICAgaW5rc2NhcGU6Y3g9IjIyNC4xNzAxIgogICAgIGlua3NjYXBlOmN5PSIxNzEuNzEwOTciCiAgICAgaW5rc2NhcGU6d2luZG93LXg9IjE2OCIKICAgICBpbmtzY2FwZTp3aW5kb3cteT0iMjAiCiAgICAgaW5rc2NhcGU6d2luZG93LW1heGltaXplZD0iMCIKICAgICBpbmtzY2FwZTpjdXJyZW50LWxheWVyPSJnMTUxOCIgLz48ZwogICAgIGlkPSJnODQyIgogICAgIGlua3NjYXBlOmdyb3VwbW9kZT0ibGF5ZXIiCiAgICAgaW5rc2NhcGU6bGFiZWw9IlBoYXNlZFJlbGVhc2UtQ1MiCiAgICAgdHJhbnNmb3JtPSJtYXRyaXgoMS4zMzMzMzMzLDAsMCwtMS4zMzMzMzMzLC0yMzcuMDk1OTcsMTAwMi40MzQzKSI+PGcKICAgICAgIGlkPSJnMTUxOCIKICAgICAgIHRyYW5zZm9ybT0ibWF0cml4KDQuMjA1NDkyNywwLDAsNC4yMDU0OTI3LC0xOTM3Ljg0NDksLTI0MTkuMTAyNykiPjxnCiAgICAgICAgIGlkPSJnMTM5MiIKICAgICAgICAgY2xpcC1wYXRoPSJ1cmwoI2NsaXBQYXRoMTM5NikiCiAgICAgICAgIHN0eWxlPSJmaWxsOndoaXRlIiAvPjxnCiAgICAgICAgIGlkPSJnMTU1NyI+PGcKICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZTtmaWxsLW9wYWNpdHk6MSIKICAgICAgICAgICB0cmFuc2Zvcm09InRyYW5zbGF0ZSg1MTguMTc2Myw3MjQuOTE4OSkiCiAgICAgICAgICAgaWQ9ImcxNDAyIj48cGF0aAogICAgICAgICAgICAgaW5rc2NhcGU6Y29ubmVjdG9yLWN1cnZhdHVyZT0iMCIKICAgICAgICAgICAgIGlkPSJwYXRoMTQwNCIKICAgICAgICAgICAgIHN0eWxlPSJmaWxsOndoaXRlO2ZpbGwtb3BhY2l0eToxO2ZpbGwtcnVsZTpub256ZXJvO3N0cm9rZTpub25lIgogICAgICAgICAgICAgZD0ibSAwLDAgYyAtNi4xMjcsMS44NjIgLTEwLjU4LDcuNTE3IC0xMC41OCwxNC4yMDkgMCw2Ljc2MyA0LjU0OCwxMi40NjUgMTAuNzY4LDE0LjI3OSAwLjYzNywwLjE4OSAwLjQ3MiwwLjU5IC0wLjMwNiwwLjU5IC04LjI3MSwwIC0xNC45ODYsLTYuNjY5IC0xNC45ODYsLTE0Ljg2OSAwLC04LjIgNi43MTUsLTE0Ljg2OSAxNC45ODYsLTE0Ljg2OSBDIDAuNjYsLTAuNjYgMC43MDcsLTAuMjEyIDAsMCIgLz48L2c+PGcKICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZSIKICAgICAgICAgICB0cmFuc2Zvcm09InRyYW5zbGF0ZSg1MTAuNDQ3NCw3MzUuNjYzOSkiCiAgICAgICAgICAgaWQ9ImcxNDA2Ij48cGF0aAogICAgICAgICAgICAgaW5rc2NhcGU6Y29ubmVjdG9yLWN1cnZhdHVyZT0iMCIKICAgICAgICAgICAgIGlkPSJwYXRoMTQwOCIKICAgICAgICAgICAgIHN0eWxlPSJmaWxsOndoaXRlO2ZpbGwtb3BhY2l0eToxO2ZpbGwtcnVsZTpub256ZXJvO3N0cm9rZTpub25lIgogICAgICAgICAgICAgZD0ibSAwLDAgYyAtMC4wNDcsMC40MDEgLTAuMDcxLDAuODAxIC0wLjA3MSwxLjIwMiAwLDYuNTI3IDUuMjc5LDExLjgwNSAxMS44MDYsMTEuODA1IDYuMTczLDAgOC4wMTEsLTIuNzU3IDguMjQ3LC0yLjU2OCAwLjI1OSwwLjE4OCAtMi4yMzksNS42NTUgLTkuNDczLDUuNjU1IC02LjUyNywwIC0xMS44MDUsLTUuMjc4IC0xMS44MDUsLTExLjgwNSAwLC0xLjUwOCAwLjI4MywtMi45NDYgMC44MDEsLTQuMjY1IEMgLTAuMjgzLC0wLjU0MiAwLjA0NywtMC41NDIgMCwwIiAvPjwvZz48ZwogICAgICAgICAgIHN0eWxlPSJmaWxsOndoaXRlO2ZpbGwtb3BhY2l0eToxIgogICAgICAgICAgIHRyYW5zZm9ybT0idHJhbnNsYXRlKDUxNS4zOTU4LDc0NC4xNzA0KSIKICAgICAgICAgICBpZD0iZzE0MTAiPjxwYXRoCiAgICAgICAgICAgICBpbmtzY2FwZTpjb25uZWN0b3ItY3VydmF0dXJlPSIwIgogICAgICAgICAgICAgaWQ9InBhdGgxNDEyIgogICAgICAgICAgICAgc3R5bGU9ImZpbGw6d2hpdGU7ZmlsbC1vcGFjaXR5OjE7ZmlsbC1ydWxlOm5vbnplcm87c3Ryb2tlOm5vbmUiCiAgICAgICAgICAgICBkPSJtIDAsMCBjIDMuMDYzLDEuMzQzIDYuOTI4LDEuMzkgMTAuNzIxLDAuMDQ3IDIuNTQ1LC0wLjg5NSA0LjAzLC0yLjE2OCA0LjE0OCwtMi4wOTcgMC4yMTIsMC4wOTQgLTEuNDg1LDIuNzU3IC00LjUyNSwzLjkxMiBDIDYuNjY4LDMuMjUyIDIuNzEsMi41MjEgLTAuMTY1LDAuMjU5IC0wLjQ5NSwwIC0wLjM3NywtMC4xNjUgMCwwIiAvPjwvZz48ZwogICAgICAgICAgIHN0eWxlPSJmaWxsOndoaXRlO2ZpbGwtb3BhY2l0eToxIgogICAgICAgICAgIHRyYW5zZm9ybT0idHJhbnNsYXRlKDU3Ni4wNzIsNzM4LjYwOTQpIgogICAgICAgICAgIGlkPSJnMTQxNCI+PHBhdGgKICAgICAgICAgICAgIGlua3NjYXBlOmNvbm5lY3Rvci1jdXJ2YXR1cmU9IjAiCiAgICAgICAgICAgICBpZD0icGF0aDE0MTYiCiAgICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZTtmaWxsLW9wYWNpdHk6MTtmaWxsLXJ1bGU6bm9uemVybztzdHJva2U6bm9uZSIKICAgICAgICAgICAgIGQ9Im0gMCwwIGMgMCwtMC44NDggLTAuNzA3LC0xLjU1NSAtMS41NTUsLTEuNTU1IC0wLjg0OSwwIC0xLjU1NSwwLjY4MyAtMS41NTUsMS41NTUgMCwwLjg0OCAwLjY4MywxLjU1NSAxLjU1NSwxLjU1NSBDIC0wLjY4MywxLjU1NSAwLDAuODcyIDAsMCIgLz48L2c+PHBhdGgKICAgICAgICAgICBpbmtzY2FwZTpjb25uZWN0b3ItY3VydmF0dXJlPSIwIgogICAgICAgICAgIGlkPSJwYXRoMTQyMCIKICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZTtmaWxsLW9wYWNpdHk6MTtmaWxsLXJ1bGU6bm9uemVybztzdHJva2U6bm9uZSIKICAgICAgICAgICBkPSJtIDUyNS40NTc0LDcyOS45MTQ0IDAuMTg4LC0yLjA3NCBoIDMuMjc2IGwgLTEuMTA4LDEyLjA0MSBoIC00Ljg3NyBsIC02LjE3NCwtMTIuMDQxIGggMy4zNDYgbCAxLjAzNywyLjA3NCB6IG0gLTAuMTY1LDIuMzMzIGggLTIuOTkzIGwgMi41NjksNS4yMDcgaCAwLjAyMyB6IiAvPjxwYXRoCiAgICAgICAgICAgaW5rc2NhcGU6Y29ubmVjdG9yLWN1cnZhdHVyZT0iMCIKICAgICAgICAgICBpZD0icGF0aDE0MjQiCiAgICAgICAgICAgc3R5bGU9ImZpbGw6d2hpdGU7ZmlsbC1vcGFjaXR5OjE7ZmlsbC1ydWxlOm5vbnplcm87c3Ryb2tlOm5vbmUiCiAgICAgICAgICAgZD0ibSA1MzMuNDY5LDczMy4wOTU2IGggMC40OTUgbCAyLjMzMywzLjE4MSBoIDMuMDM5IGwgLTMuMjI4LC00LjA1MyAxLjk4LC00LjM4MyBoIC0zLjIyOSBsIC0xLjI5NiwzLjQxNyBoIC0wLjQ3MSBsIC0wLjczLC0zLjQxNyBoIC0yLjc1NyBsIDIuNTQ0LDEyLjA0MSBoIDIuNzU3IHoiIC8+PGcKICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZTtmaWxsLW9wYWNpdHk6MSIKICAgICAgICAgICBjbGlwLXBhdGg9InVybCgjY2xpcFBhdGgxNDMyKSIKICAgICAgICAgICBpZD0iZzE0MjgiPjxnCiAgICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZTtmaWxsLW9wYWNpdHk6MSIKICAgICAgICAgICAgIHRyYW5zZm9ybT0idHJhbnNsYXRlKDU0My42NDg1LDcyNy44NDA4KSIKICAgICAgICAgICAgIGlkPSJnMTQzNCI+PHBhdGgKICAgICAgICAgICAgICAgaW5rc2NhcGU6Y29ubmVjdG9yLWN1cnZhdHVyZT0iMCIKICAgICAgICAgICAgICAgaWQ9InBhdGgxNDM2IgogICAgICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZTtmaWxsLW9wYWNpdHk6MTtmaWxsLXJ1bGU6bm9uemVybztzdHJva2U6bm9uZSIKICAgICAgICAgICAgICAgZD0iTSAwLDAgSCAyLjc1NyBMIDMuODY0LDUuMjU1IEMgNC40NzcsOC4xNTMgMy4zNyw4LjUwNiAwLjU0Miw4LjUwNiBjIC0xLjk3OSwwIC0zLjg4OCwwLjAyNCAtNC40MywtMi41OTEgaCAyLjc1NyBjIDAuMTY1LDAuNzU0IDAuNjM2LDAuOTE4IDEuMzIsMC45MTggMS4yMDEsMCAxLjE1NCwtMC40OTQgMC45ODksLTEuMjcyIEwgMC44OTUsNC4yMTggSCAwLjc3OCBDIDAuNjgzLDUuMTg0IC0wLjU0Miw1LjE2IC0xLjMyLDUuMTYgYyAtMi4wMDIsMCAtMy4xODEsLTAuNjM2IC0zLjYwNSwtMi42NjIgLTAuNDQ3LC0yLjE0NCAwLjU2NiwtMi42MTYgMi40OTgsLTIuNjE2IDAuOTY2LDAgMi4yNjIsMC4xODkgMi43MSwxLjM0MyBIIDAuMzc3IFogTSAtMC43NzgsMy40ODcgQyAwLjExOCwzLjQ4NyAwLjcwNywzLjQxNyAwLjU2NSwyLjcxIDAuMzc3LDEuODM4IDAsMS42NzMgLTEuMTU1LDEuNjczIGMgLTAuNDI0LDAgLTEuMjAxLDAgLTEuMDEzLDAuOTE5IDAuMTY1LDAuNzc4IDAuNzA3LDAuODk1IDEuMzksMC44OTUiIC8+PC9nPjxnCiAgICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZTtmaWxsLW9wYWNpdHk6MSIKICAgICAgICAgICAgIHRyYW5zZm9ybT0idHJhbnNsYXRlKDU1MS45OSw3MzYuMjc2NikiCiAgICAgICAgICAgICBpZD0iZzE0MzgiPjxwYXRoCiAgICAgICAgICAgICAgIGlua3NjYXBlOmNvbm5lY3Rvci1jdXJ2YXR1cmU9IjAiCiAgICAgICAgICAgICAgIGlkPSJwYXRoMTQ0MCIKICAgICAgICAgICAgICAgc3R5bGU9ImZpbGw6d2hpdGU7ZmlsbC1vcGFjaXR5OjE7ZmlsbC1ydWxlOm5vbnplcm87c3Ryb2tlOm5vbmUiCiAgICAgICAgICAgICAgIGQ9Im0gMCwwIC0wLjI1OSwtMS4xNzggaCAwLjExOCBjIDAuNTQyLDAuOTkgMS42NDksMS4yNzIgMi41OTIsMS4yNzIgMS4xNzgsMCAyLjM1NiwtMC4yMTIgMi4xOTEsLTEuNjQ5IEggNC43NiBjIDAuNCwxLjIwMiAxLjYyNiwxLjY0OSAyLjY4NiwxLjY0OSAxLjk1NiwwIDIuNzgxLC0wLjgwMSAyLjM1NiwtMi43NTcgTCA4LjU3NywtOC40MzYgSCA1LjgyIGwgMS4wMzcsNC44NzggYyAwLjE0MSwwLjg3MiAwLjI4MywxLjUzMiAtMC43NzgsMS41MzIgLTEuMDg0LDAgLTEuNDM3LC0wLjcwNyAtMS42MjYsLTEuNjI2IEwgMy40NCwtOC40MzYgSCAwLjY4MyBsIDEuMDg0LDUuMTE0IGMgMC4xNDIsMC43NzcgMC4xODksMS4yOTYgLTAuNzc3LDEuMjk2IC0xLjEzMSwwIC0xLjQ4NSwtMC42MTMgLTEuNjk3LC0xLjYyNiBMIC0xLjcyLC04LjQzNiBIIC00LjQ3NyBMIC0yLjY4NiwwIFoiIC8+PC9nPjxnCiAgICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZTtmaWxsLW9wYWNpdHk6MSIKICAgICAgICAgICAgIHRyYW5zZm9ybT0idHJhbnNsYXRlKDU2Ni45MDU4LDcyNy44NDA4KSIKICAgICAgICAgICAgIGlkPSJnMTQ0MiI+PHBhdGgKICAgICAgICAgICAgICAgaW5rc2NhcGU6Y29ubmVjdG9yLWN1cnZhdHVyZT0iMCIKICAgICAgICAgICAgICAgaWQ9InBhdGgxNDQ0IgogICAgICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZTtmaWxsLW9wYWNpdHk6MTtmaWxsLXJ1bGU6bm9uemVybztzdHJva2U6bm9uZSIKICAgICAgICAgICAgICAgZD0ibSAwLDAgaCAyLjc1NyBsIDEuMTMxLDUuMjU1IGMgMC42MTMsMi44OTggLTAuNDk1LDMuMjUxIC0zLjMyMiwzLjI1MSAtMS45OCwwIC0zLjg4OSwwLjAyNCAtNC40MywtMi41OTEgaCAyLjc1NyBjIDAuMTY0LDAuNzU0IDAuNjM2LDAuOTE4IDEuMzE5LDAuOTE4IDEuMjAyLDAgMS4xNTUsLTAuNDk0IDAuOTksLTEuMjcyIEwgMC45MTksNC4yMTggSCAwLjgwMSBDIDAuNzA3LDUuMTg0IC0wLjUxOCw1LjE2IC0xLjI5Niw1LjE2IGMgLTIuMDAzLDAgLTMuMTgxLC0wLjYzNiAtMy42MDUsLTIuNjYyIC0wLjQ0OCwtMi4xNDQgMC41NjUsLTIuNjE2IDIuNDk3LC0yLjYxNiAwLjk2NywwIDIuMjYzLDAuMTg5IDIuNzEsMS4zNDMgSCAwLjQwMSBaIE0gLTAuNzU0LDMuNDg3IEMgMC4xNDEsMy40ODcgMC43MywzLjQxNyAwLjU4OSwyLjcxIDAuNDAxLDEuODM4IDAuMDI0LDEuNjczIC0xLjEzMSwxLjY3MyBjIC0wLjQyNCwwIC0xLjIwMiwwIC0xLjAxMywwLjkxOSAwLjE2NSwwLjc3OCAwLjcwNywwLjg5NSAxLjM5LDAuODk1IiAvPjwvZz48L2c+PHBhdGgKICAgICAgICAgICBpbmtzY2FwZTpjb25uZWN0b3ItY3VydmF0dXJlPSIwIgogICAgICAgICAgIGlkPSJwYXRoMTQ0OCIKICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZTtmaWxsLW9wYWNpdHk6MTtmaWxsLXJ1bGU6bm9uemVybztzdHJva2U6bm9uZSIKICAgICAgICAgICBkPSJtIDU3My42Njg1LDcyNy44NDA4IGggLTIuNzU3IGwgMS43NjcsOC40MzYgaCAyLjc4MSB6IiAvPjwvZz48L2c+PC9nPjwvc3ZnPg=="              x="55"  y="282" width="76" height="31"/>
            <image href="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDA5NiIgaGVpZ2h0PSI1MjgiIHZpZXdCb3g9IjAgMCA0MDk2IDUyOCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGcgY2xpcC1wYXRoPSJ1cmwoI2NsaXAwXzNfNjcpIj4KPHBhdGggZD0iTTI5MzQuMTEgMTI0LjY0M0MyODIxLjcyIDEyNC42NDMgMjc0My4yMiAyMDcuNTU3IDI3NDMuMjIgMzI2LjMwM0MyNzQzLjIyIDQ0NS4wNDggMjgyMS43MiA1MjcuOTYyIDI5MzQuMTEgNTI3Ljk2MkMyOTg4LjM1IDUyNy45NjIgMzAzNy4xNyA1MDcuNDk4IDMwNzEuNjEgNDcwLjMxOUMzMTA1LjU3IDQzMy42NTEgMzEyNC4yOCAzODIuMjM0IDMxMjQuMjggMzI1LjUzOEMzMTI0LjI4IDIwNy4yMyAzMDQ2LjA3IDEyNC42MDcgMjkzNC4xMSAxMjQuNjA3VjEyNC42NDNaTTI5MzQuMTEgNDQ2LjkwNUMyODczLjg4IDQ0Ni45MDUgMjgzMS44MiAzOTcuMzEgMjgzMS44MiAzMjYuMzM5QzI4MzEuODIgMjU1LjM2OSAyODczLjg4IDIwNS43NzMgMjkzNC4xMSAyMDUuNzczQzI5OTQuMzQgMjA1Ljc3MyAzMDM1LjY4IDI1NS4wNDEgMzAzNS42OCAzMjUuNjExQzMwMzUuNjggMzk2LjE4MSAyOTkzLjkxIDQ0Ni45NDIgMjkzNC4xMSA0NDYuOTQyVjQ0Ni45MDVaIiBmaWxsPSJ3aGl0ZSIvPgo8cGF0aCBkPSJNMTc3MS44MiAzMy43NTM4SDE2ODIuNDlWMTM2LjY1OUgxNjExLjg0VjIxNy43NTNIMTY4Mi40OVY1MTYuNzFIMTc3MS44MlYyMTcuNzUzSDE4NDMuMTZWMTM2LjY1OUgxNzcxLjgyVjMzLjc1MzhaIiBmaWxsPSJ3aGl0ZSIvPgo8cGF0aCBkPSJNNDA0OS44MiAxNzcuNjI2QzQwMTkuMDIgMTQyLjk2IDM5NzQuMDggMTI0LjY0NCAzOTE5Ljg4IDEyNC42NDRDMzgxMC41NCAxMjQuNjQ0IDM3MzQuMTUgMjA3Ljg4NSAzNzM0LjE1IDMyNy4wNjhDMzczNC4xNSA0NDYuMjUgMzgxMC41NCA1MjcuOTk5IDM5MTkuODggNTI3Ljk5OUMzOTk2LjMxIDUyNy45OTkgNDA1Ni4xNCA0OTAuNjc1IDQwODguMzYgNDIyLjg3Mkw0MDg5LjYzIDQyMC4xNzhMNDAwOS4wNiAzOTMuNzA1TDQwMDguMDUgMzk1LjU2MkMzOTg5LjIzIDQyOS42NDUgMzk1OS4yMiA0NDcuNjM0IDM5MjEuMzMgNDQ3LjYzNEMzODY5Ljc5IDQ0Ny42MzQgMzgzMC45MiA0MTAuODkyIDM4MjEuNjYgMzUzLjcyM0g0MDk0LjMyTDQwOTQuNzIgMzQ3Ljg5NkM0MDk1LjM3IDMzOC4yMSA0MDk1Ljk5IDMyOS4wMzQgNDA5NS45OSAzMTguODM4QzQwOTUuOTkgMjYwLjQ2NyA0MDgwLjAxIDIxMS42MzYgNDA0OS44MiAxNzcuNjYyVjE3Ny42MjZaTTM4MjQuOTYgMjgzLjE1M0MzODM4LjY2IDIzMy42NjYgMzg3My45MyAyMDQuMjQ0IDM5MTkuODUgMjA0LjI0NEMzOTY4LjA5IDIwNC4yNDQgMzk5OS45NCAyMzIuMjQ2IDQwMDkuNzkgMjgzLjE1M0gzODI0Ljk2WiIgZmlsbD0id2hpdGUiLz4KPHBhdGggZD0iTTU1NC41NDggNDQ5LjI3NEM1OTIuMTEgNDA2LjQ1MSA2MTEuMTgxIDM0Mi4zMjYgNjExLjE4MSAyNTguNjQ3VjI1OC4wMjhDNjExLjE4MSAxNzQuMzUgNTkyLjExIDExMC4xODggNTU0LjU0OCA2Ny40MDIzQzUxNi4yMjQgMjMuNzA1NyA0NzkuOTcxIDAuMDM2NzQzMiAzOTguMTI4IDAuMDM2NzQzMkgyMjIuMDkxQzIzMS41MzYgOS43OTU2NCAyNTMuNDQgMzIuNDgxNCAyNjAuNzQyIDM5Ljk4MjdDMjY0LjE5MyA0My41MTQ4IDI2Ni45OSA0Ni4yNDU4IDI2OS4xMzMgNDguMzIxNEwyNjkuNDI0IDQ4LjYxMjdDMjcwLjYyMyA0OS43NzggMjcxLjYwMyA1MC43MjQ3IDI3Mi4yOTQgNTEuNDg5NEMyNzMuMDU3IDUyLjI1NDEgMjczLjU2NSA1Mi44MDAzIDI3My44OTIgNTMuMDkxNkMyODguNDIzIDY3LjY5MzYgMzA1LjM1MSA3My41OTI2IDMzMi40NSA3My41OTI2QzMzMy40NjcgNzMuNTkyNiAzMzUuNDY1IDczLjU5MjYgMzM4LjIyNiA3My41OTI2QzM0NC43MjggNzMuNTU2MiAzNTcuNzMzIDczLjU5MjYgMzcxLjc1NSA3My41OTI2QzM4MC42NTUgNzMuNTkyNiAzODkuOTkxIDczLjU5MjYgMzk4LjM0NiA3My41OTI2QzQ3MC45MjUgNzMuNTkyNiA0OTIuNjEyIDExNi4zNDIgNDk2LjM1NCAxMjUuMjI3QzQ5OS45ODYgMTMwLjMyNSA1MDMuMDAyIDEzNi4wNzkgNTA1LjMyNiAxNDIuMzQyQzUxOC40NCAxNzcuMzcyIDUyNS4xNjEgMjE3LjUzNiA1MjQuNzk3IDI1OC40MjlDNTI1LjE2MSAyOTguNTkzIDUxOC40NCAzMzguNjg1IDUwNS4zMjYgMzc0LjI2MUM0ODIuNDc3IDQzNi4zMSA0MjQuNDY0IDQ0My4wMTEgNDAwLjU2MiA0NDMuMDExSDMzMi40NUMzMDYuMzMxIDQ0My4wMTEgMjgwLjg2NyA0NTQuOTU0IDI2MC43NDIgNDc2LjYyQzI1MS4xMTUgNDg2Ljk5OCAyMzEuNjgxIDUwNy40NjMgMjIzLjAzNSA1MTYuNTY2SDM5OC4wMTlDNDc5LjkzNCA1MTYuNTY2IDUxNi4yMjQgNDkyLjg5NyA1NTQuNTQ4IDQ0OS4yMzdWNDQ5LjI3NFoiIGZpbGw9IndoaXRlIi8+CjxwYXRoIGQ9Ik0zMzkuMTA1IDI1OC4zOTlDMzM5LjEwNSAyNTguMzk5IDMzOS4xMDUgMjU4LjM5OSAzMzkuMTA1IDI1OC4zNjJDMzM5LjEwNSAyNTguMzYyIDMzOS4xMDUgMjU4LjM2MiAzMzkuMTA1IDI1OC4zMjZDMzM5LjEwNSAyNTguMzI2IDMzOS4xMDUgMjU4LjMyNiAzMzkuMTA1IDI1OC4yODlDMzM5Ljc1OSAyMjAuMjM3IDMzMi40NTggMTg2LjcgMzI2LjYwOSAxNjguMzExQzMxOS40MTcgMTQ1LjYyNSAzMTIuMjk3IDEzNy4wNjggMzEwLjA0NCAxMzQuMTkxQzI3NS4yMDggODkuMTEwOSAyMzQuODg1IDEwOC41NTYgMjAwLjM3NSA4NC45OTYxQzE2NS45MDIgNjEuNDcyOCAxNjAuMTI2IDQzLjYzMDEgMTQ3Ljg0OCAzMS4xNDAxQzE0NS43NDEgMjguOTkxNyAxNDEuMDkxIDI0LjI1NzkgMTMzLjg5OCAxOS4zMDU2QzEzMy44OTggMTkuMzA1NiAxMjIuNjM3IDExLjU0OTUgMTA2Ljk4MSA2LjY3MDA1QzkwLjAxNjQgMS4zMTcyMyAzOC44NjkxIC0wLjA2NjQ5NzIgMCAwLjA0Mjc0NDFWNzguMjIzMkgxMTUuOTE3QzEyOS43OTQgNzcuOTMxOCAxNjMuNTQxIDc5LjI0MjcgMTkzLjI5MiAxMDIuNzNDMjA4LjgzOSAxMTUuMDAxIDIxNy4wNDkgMTI4LjM2NSAyMjIuMDk5IDEzNi43MDRDMjQ2LjAwMSAxNzYuMzk1IDI0Ni43MjggMjI0LjY0MyAyNDcuMiAyNTguMjE3VjI1OC4zOTlDMjQ2LjcyOCAyOTEuOTcyIDI0Ni4wMDEgMzQwLjIyIDIyMi4wOTkgMzc5LjkxMUMyMTcuMDg2IDM4OC4yNSAyMDguODM5IDQwMS42NSAxOTMuMjkyIDQxMy44ODZDMTYzLjUwNCA0MzcuMzcyIDEyOS43OTQgNDM4LjY4MyAxMTUuOTE3IDQzOC4zOTJIMFY1MTYuNTcyQzM4Ljg2OTEgNTE2LjcxOCA5MC4wMTY0IDUxNS4yOTggMTA2Ljk4MSA1MDkuOTgxQzEyMi42MzcgNTA1LjA2NiAxMzMuODk4IDQ5Ny4zNDYgMTMzLjg5OCA0OTcuMzQ2QzE0MS4wOTEgNDkyLjM5NCAxNDUuNzQxIDQ4Ny42NiAxNDcuODQ4IDQ4NS41MTFDMTYwLjEyNiA0NzMuMDIxIDE2NS45MDIgNDU1LjIxNSAyMDAuMzc1IDQzMS42NTVDMjM0Ljg0OSA0MDguMTMyIDI3NS4yMDggNDI3LjU3NyAzMTAuMDQ0IDM4Mi40NkMzMTIuMjk3IDM3OS41ODQgMzE5LjQxNyAzNzEuMDI2IDMyNi42MDkgMzQ4LjM0MUMzMzIuNDIxIDMyOS45NTIgMzM5Ljc1OSAyOTYuNDE1IDMzOS4xMDUgMjU4LjM2MlYyNTguMzk5WiIgZmlsbD0id2hpdGUiLz4KPHBhdGggZD0iTTI3MTUuMzkgMjU4LjM5MkMyNzEzLjQ3IDk4Ljc1NDIgMjY1Mi44OCAwIDI0NjQuNzQgMEgyMzEyLjA2SDIzMTIuMUwyMjg0LjE2IDAuMDM2NDEzOFYyNTguMzkyVjUxNi43NDhIMjMxMi4xSDIzMTIuMDZMMjQ2NC43NCA1MTYuNzg0QzI2NTIuODggNTE2Ljc4NCAyNzEzLjQ3IDQxOC4wMyAyNzE1LjM5IDI1OC4zOTJaTTI0NjUuNDcgNDMxLjE3NkgyMzc3Ljg5VjI1OC4zOTJWODUuNjA4OEgyNDY1LjQ3QzI0OTEuNTUgODUuOTM2NSAyNTQ1Ljg5IDg1LjQyNjggMjU3Ny41MyAxMTkuNzI5QzI2MDQuNjMgMTQ5LjA3OCAyNjEzLjQzIDIwNS43NzQgMjYxNC41OSAyNTguMzkyQzI2MTQuNTkgMzE4LjAwMiAyNjA0LjYgMzY3LjcwNiAyNTc3LjUzIDM5Ny4wNTZDMjU0NS44OSA0MzEuMzU4IDI0OTEuNTUgNDMwLjg0OCAyNDY1LjQ3IDQzMS4xNzZaIiBmaWxsPSJ3aGl0ZSIvPgo8cGF0aCBkPSJNMTE3Mi4xOCAyNTguMzkyQzExNzAuMjEgOTguNzU0MiAxMTA5LjY2IDAgOTIxLjQ4OCAwSDc2OC44MDlINzY4Ljg0NUw3NDAuOTEgMC4wMzY0MTM4VjI1OC4zOTJWNTE2Ljc0OEg3NjguODQ1SDc2OC44MDlMOTIxLjQ4OCA1MTYuNzg0QzExMDkuNjIgNTE2Ljc4NCAxMTcwLjIxIDQxOC4wMyAxMTcyLjE0IDI1OC4zOTJIMTE3Mi4xOFpNOTIyLjI1MSA0MzEuMTc2SDgzNC42NjhWMjU4LjM5MlY4NS42MDg4SDkyMi4yNTFDOTQ4LjMzMyA4NS45MzY1IDEwMDIuNjggODUuNDI2OCAxMDM0LjMyIDExOS43MjlDMTA2MS40MiAxNDkuMDc4IDEwNzAuMjEgMjA1Ljc3NCAxMDcxLjM3IDI1OC4zOTJDMTA3MS4zNyAzMTguMDAyIDEwNjEuMzggMzY3LjcwNiAxMDM0LjMyIDM5Ny4wNTZDMTAwMi42OCA0MzEuMzU4IDk0OC4zMzMgNDMwLjg0OCA5MjIuMjUxIDQzMS4xNzZaIiBmaWxsPSJ3aGl0ZSIvPgo8cGF0aCBkPSJNMzU3Ny42NSAxMjYuNjQ4QzM1MjguMjEgMTI2LjY0OCAzNDg3LjIgMTUwLjc5IDM0NjIuMjEgMTk0LjYzM0MzNDYxLjA4IDE5Ni41OTkgMzQ1Ny44NSAxOTYuMzA4IDM0NTcuMDUgMTk0LjE5NkMzNDQwLjc0IDE1MC42NDUgMzQwMy45MSAxMjYuNjg0IDMzNTMuMyAxMjYuNjg0QzMzMDguOTkgMTI2LjY4NCAzMjcyLjg0IDE0Ny42OTUgMzI0OC43NiAxODcuNDk1QzMyNDcuNzggMTg5LjA5OCAzMjQ1Ljg5IDE4OS44MjYgMzI0NC4xNCAxODkuMjQzQzMyNDIuNTQgMTg4LjY5NyAzMjQxLjQ1IDE4Ny4yMDQgMzI0MS40NSAxODUuNTI5VjEzNS43NTFIMzE1My40NFY1MTguNjc5SDMyNDIuOTRWMjk2Ljg0NkMzMjQyLjk0IDI0NC4xNTUgMzI3My43NSAyMDcuMzc3IDMzMTcuODkgMjA3LjM3N0MzMzYyLjAyIDIwNy4zNzcgMzM4Ni4wNyAyNDAuMjU5IDMzODYuMDcgMjk1LjM1M1Y1MTguNjc5SDM0NzQuODVWMjgyLjM1M0MzNDc0Ljg1IDI0MS41MzMgMzUwNy4yNSAyMDcuODg3IDM1NDcuMDcgMjA3LjM3N0MzNTY2LjU0IDIwNy4wODYgMzU4Mi41MiAyMTIuODc2IDM1OTQuMjYgMjI0LjQ5MkMzNjA5LjI5IDIzOS4zNDkgMzYxNy4yMSAyNjMuODU1IDM2MTcuMjEgMjk1LjM1M1Y1MTguNjc5SDM3MDYuNzJWMjgwLjI0MUMzNzA2LjcyIDE4MS4yMzIgMzY2MC44OCAxMjYuNjg0IDM1NzcuNjUgMTI2LjY4NFYxMjYuNjQ4WiIgZmlsbD0id2hpdGUiLz4KPHBhdGggZD0iTTE0OTAuMTQgMTM2LjA3OFYxMzcuOTM1QzE0OTAuMTQgMTQ4Ljg5NiAxNDkwLjE0IDE1Ni44MzQgMTQ5MC4xNCAxNjQuNzM2VjE4NS45MjlDMTQ5MC4xNCAxODcuODk1IDE0ODguNjUgMTg5LjUzNCAxNDg2LjcyIDE4OS42MDdDMTQ4NS40MiAxODkuNjQzIDE0ODQuMjkgMTg5LjAyNCAxNDgzLjYgMTg3Ljk2OEMxNDU3LjIzIDE0Ny40NzYgMTQyMC4xNyAxMjcuODEyIDEzNzAuMzMgMTI3LjgxMkMxMjcxLjA5IDEyNy44MTIgMTIwMS43NCAyMDkuNTYxIDEyMDEuNzQgMzI2LjU5NUMxMjAxLjc0IDQ0My42MjkgMTI3MS4wOSA1MjUuMzc4IDEzNzAuMzMgNTI1LjM3OEMxNDIwLjE0IDUyNS4zNzggMTQ1Ny4xOSA1MDUuNzE1IDE0ODMuNiA0NjUuMjIzQzE0ODQuMjkgNDY0LjE2NyAxNDg1LjQyIDQ2My41MTEgMTQ4Ni43MiA0NjMuNTg0QzE0ODguNjUgNDYzLjY1NyAxNDkwLjE3IDQ2NS4yOTUgMTQ5MC4xNCA0NjcuMjYyVjQ4OC40NTVDMTQ5MC4xIDQ5Ni4zNTYgMTQ5MC4wNyA1MDQuMjk1IDE0OTAuMDcgNTE1LjI1NVY1MTcuMTEySDE1NzYuN1YzMjYuNjMyVjEzNi4xMTVIMTQ5MC4wN0wxNDkwLjE0IDEzNi4wNzhaTTE0OTEuNjMgMzI2LjU5NUMxNDkxLjYzIDMyNi44NSAxNDkxLjYzIDMyNy4wNjkgMTQ5MS42MyAzMjcuMzI0QzE0OTEuNjMgMzk4LjAwMyAxNDUwLjM2IDQ0NS40ODYgMTM4OC45MyA0NDUuNDg2QzEzMjcuNTEgNDQ1LjQ4NiAxMjg5LjIyIDM5Ni41ODMgMTI4OS4yMiAzMjYuNTk1QzEyODkuMjIgMjU2LjYwOCAxMzMwLjIzIDIwNy43MDQgMTM4OC45MyAyMDcuNzA0QzE0NDcuNjQgMjA3LjcwNCAxNDkxLjYzIDI1NS4xODggMTQ5MS42MyAzMjUuODY3QzE0OTEuNjMgMzI2LjEyMiAxNDkxLjYzIDMyNi4zNCAxNDkxLjYzIDMyNi41OTVaIiBmaWxsPSJ3aGl0ZSIvPgo8cGF0aCBkPSJNMjE0NC44OCAxMzYuMDc4VjEzNy45MzVDMjE0NC44OCAxNDguODk2IDIxNDQuODggMTU2LjgzNCAyMTQ0Ljg4IDE2NC43MzZWMTg1LjkyOUMyMTQ0Ljg4IDE4Ny44OTUgMjE0My4zOSAxODkuNTM0IDIxNDEuNDcgMTg5LjYwN0MyMTQwLjE2IDE4OS42NDMgMjEzOS4wMyAxODkuMDI0IDIxMzguMzQgMTg3Ljk2OEMyMTExLjk3IDE0Ny40NzYgMjA3NC45MiAxMjcuODEyIDIwMjUuMDggMTI3LjgxMkMxOTI1LjgzIDEyNy44MTIgMTg1Ni40OSAyMDkuNTYxIDE4NTYuNDkgMzI2LjU5NUMxODU2LjQ5IDQ0My42MjkgMTkyNS44MyA1MjUuMzc4IDIwMjUuMDggNTI1LjM3OEMyMDc0Ljg4IDUyNS4zNzggMjExMS45MyA1MDUuNzE1IDIxMzguMzQgNDY1LjIyM0MyMTM5LjAzIDQ2NC4xNjcgMjE0MC4xNiA0NjMuNTExIDIxNDEuNDcgNDYzLjU4NEMyMTQzLjM5IDQ2My42NTcgMjE0NC45MiA0NjUuMjk1IDIxNDQuODggNDY3LjI2MlY0ODguNDU1QzIxNDQuODUgNDk2LjM1NiAyMTQ0LjgxIDUwNC4yOTUgMjE0NC44MSA1MTUuMjU1VjUxNy4xMTJIMjIzMS40NVYzMjYuNjMyVjEzNi4xMTVIMjE0NC44MUwyMTQ0Ljg4IDEzNi4wNzhaTTIxNDYuMzQgMzI2LjU5NUMyMTQ2LjM0IDMyNi44NSAyMTQ2LjM0IDMyNy4wNjkgMjE0Ni4zNCAzMjcuMzI0QzIxNDYuMzQgMzk4LjAwMyAyMTA1LjA3IDQ0NS40ODYgMjA0My42NCA0NDUuNDg2QzE5ODIuMjEgNDQ1LjQ4NiAxOTQzLjkzIDM5Ni41ODMgMTk0My45MyAzMjYuNTk1QzE5NDMuOTMgMjU2LjYwOCAxOTg0Ljk0IDIwNy43MDQgMjA0My42NCAyMDcuNzA0QzIxMDIuMzQgMjA3LjcwNCAyMTQ2LjM0IDI1NS4xODggMjE0Ni4zNCAzMjUuODY3QzIxNDYuMzQgMzI2LjEyMiAyMTQ2LjM0IDMyNi4zNCAyMTQ2LjM0IDMyNi41OTVaIiBmaWxsPSJ3aGl0ZSIvPgo8L2c+CjxkZWZzPgo8Y2xpcFBhdGggaWQ9ImNsaXAwXzNfNjciPgo8cmVjdCB3aWR0aD0iNDA5NiIgaGVpZ2h0PSI1MjgiIGZpbGw9IndoaXRlIi8+CjwvY2xpcFBhdGg+CjwvZGVmcz4KPC9zdmc+Cg==" x="150" y="291" width="80" height="10"/>
            <image href="data:image/svg+xml;base64,PHN2ZyB2ZXJzaW9uPSIxLjEiIGlkPSJMYXllcl8xIiB4bWxuczp4PSJuc19leHRlbmQ7IiB4bWxuczppPSJuc19haTsiIHhtbG5zOmdyYXBoPSJuc19ncmFwaHM7IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB4PSIwcHgiIHk9IjBweCIgdmlld0JveD0iMCAwIDMyNiA4OCIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzI2IDg4OyIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSI+CiA8c3R5bGU+CiAgLnN0MHtmaWxsOndoaXRlO30KIDwvc3R5bGU+CiA8bWV0YWRhdGE+CiAgPHNmdyB4bWxucz0ibnNfc2Z3OyI+CiAgIDxzbGljZXM+CiAgIDwvc2xpY2VzPgogICA8c2xpY2VTb3VyY2VCb3VuZHMgYm90dG9tTGVmdE9yaWdpbj0idHJ1ZSIgaGVpZ2h0PSI4OCIgd2lkdGg9IjMyNiIgeD0iLTE3Ny44IiB5PSIwIj4KICAgPC9zbGljZVNvdXJjZUJvdW5kcz4KICA8L3Nmdz4KIDwvbWV0YWRhdGE+CiA8Zz4KICA8cGF0aCBjbGFzcz0ic3QwIiBkPSJNMTMuNCwwSDYuN0gwdjEzLjVoMTMuNFYweiBNMzI1LjksNzQuNWgtNi43aC02LjdWODhoMTMuNFY3NC41eiI+CiAgPC9wYXRoPgogIDxwYXRoIGNsYXNzPSJzdDAiIGQ9Ik0xMy40LDY4LjJIMFYxOS44aDYuN2g2LjdWNjguMnogTTc1LDE4LjhjOS45LDAsMTUuOCw2LjksMTUuOCwxNy45djMxLjVINzcuNVYzOS40YzAtNS4yLTIuMy04LjYtNi45LTguNgoJCWMtMy41LDAtNi42LDIuMi03LjQsNi4zdjMxLjJINDkuN1YzOS40YzAtNS4yLTIuMi04LjYtNi44LTguNmMtMy41LDAtNi43LDIuMi03LjUsNi4zdjMxLjJIMjIuMVYxOS44aDEzLjR2NAoJCWMyLjQtMyw2LjgtNS4xLDEyLjEtNS4xYzUuNywwLDEwLjMsMi42LDEyLjksNi4yQzYzLjYsMjEuNCw2OC4yLDE4LjgsNzUsMTguOHogTTExMi44LDg4SDk5LjRWMTkuOGgxMy40djRjMi4yLTIuNiw2LjktNS4xLDEyLTUuMQoJCWMxNCwwLDIxLjksMTEuNywyMS45LDI1LjNzLTgsMjUuMi0yMS45LDI1LjJjLTUuMiwwLTkuOS0yLjUtMTItNS4xVjg4eiBNMTEyLjgsNTJjMS42LDMuMyw1LjIsNS42LDksNS42YzcuMiwwLDExLjUtNS45LDExLjUtMTMuNQoJCWMwLTcuOC00LjMtMTMuNi0xMS41LTEzLjZjLTQsMC03LjQsMi40LTksNS42VjUyeiBNMTY0LjYsNDcuMWMxLDcuOSw2LjgsMTEuMiwxMy44LDExLjJjNS4zLDAsOS0xLjIsMTMuNy00LjN2MTEuMQoJCWMtNCwyLjktOS4zLDQuMy0xNS44LDQuM2MtMTQuNiwwLTI0LjctOS42LTI0LjctMjQuOWMwLTE1LjIsOS41LTI1LjcsMjIuNi0yNS43YzE0LDAsMjEuMiw5LjgsMjEuMiwyNC4xdjQuNEwxNjQuNiw0Ny4xCgkJTDE2NC42LDQ3LjF6IE0xNjUuMSwzOC40aDE4LjJjLTAuMy01LjItMy4yLTguOS04LjUtOC45QzE3MC40LDI5LjUsMTY2LjYsMzIuMywxNjUuMSwzOC40eiBNMjMxLjksMzMuMWMtMS44LTEtNC4yLTEuNi02LjctMS42CgkJYy00LjUsMC04LjIsMi40LTkuMSw2Ljh2MjkuOWgtMTMuNFYxOS44aDEzLjR2NC43YzIuMS0zLjUsNi01LjksMTAuNy01LjljMi4zLDAsNC4zLDAuNSw1LjEsMC45VjMzLjF6IE0yNTIuNyw2OC4ybC0xOC4yLTQ4LjQKCQloMTMuOWwxMS4xLDMyLjFsMTAuOC0zMi4xaDEzLjVsLTE4LjMsNDguNEgyNTIuN3ogTTMxMi43LDM4YzAtNC42LTQtNy42LTEwLjctNy42Yy00LjgsMC05LjMsMS40LTEzLjEsMy45VjIyLjcKCQljMy41LTIuMiw5LjctNCwxNi00YzEzLjMsMCwyMS4yLDYuOCwyMS4yLDE4Ljd2MzAuOGgtMTMuNHYtMi42Yy0xLjYsMS42LTYuMywzLjUtMTEuNiwzLjVjLTkuNywwLTE3LjgtNS42LTE3LjgtMTUuNwoJCWMwLTkuMiw4LjEtMTUuNCwxOC42LTE1LjRjNC4yLDAsOC44LDEuNCwxMC43LDIuOFYzOHogTTMxMi43LDUxLjVjLTEuMi0yLjYtNC43LTQuMy04LjUtNC4zYy00LjIsMC04LjUsMS44LTguNSw2CgkJYzAsNC4zLDQuMyw2LDguNSw2YzMuOCwwLDcuMy0xLjYsOC41LTQuM1Y1MS41eiI+CiAgPC9wYXRoPgogPC9nPgo8L3N2Zz4="     x="245" y="286" width="76" height="20"/>
            <image href="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAxMDkuMjEgMzYiPgogICAgICAgICAgPHBhdGggZD0iTTk4Ljk3LDIzLjY3Yy0zLjA1LDAtNS4yLTIuMzgtNS4yLTUuNTFzMi4xNS01LjUxLDUuMi01LjUxLDUuMTQsMi4zOCw1LjE0LDUuNTEtMi4xMiw1LjUxLTUuMTQsNS41MVptLS40OSwzLjI4YzIuNDYsMCw0LjU1LS45Niw1Ljg3LTIuOTcsLjI1LDEuOTUsMS42NiwyLjY2LDMuNDQsMi42NmgxLjQydi0zLjA5aC0uNjFjLTEuMDEsMC0xLjI2LS40OS0xLjI2LTEuNjRWOS42OWgtMy4yNnYyLjUxYy0xLjExLTEuNzYtMy4yLTIuODItNS42LTIuODItNC4yOCwwLTguMjEsMy41OS04LjIxLDguNzhzMy45NCw4Ljc4LDguMjEsOC43OFptLTE2Ljc5LTQuMjRjMCwyLjc4LDEuNzIsMy45MywzLjc4LDMuOTNoMy45N3YtMy4wOWgtMi44OWMtMS4yLDAtMS40NS0uNDYtMS40NS0xLjY0VjEyLjc4aDQuMzR2LTMuMDloLTQuMzRWNGgtMy40MVYyMi43MVptLTE1LjUzLDMuOTNoMy40MXYtNy4yN2gxLjE0bDUuODEsNy4yN2g0LjMxbC03LjQxLTkuMjIsNS42OS03LjczaC0zLjg0bC00LjY1LDYuNTNoLTEuMDVWNGgtMy40MVYyNi42NFptLTExLjA3LTE3LjI2Yy00Ljc3LDAtOC43LDMuNTktOC43LDguNzhzMy45NCw4Ljc4LDguNyw4Ljc4LDguNy0zLjU5LDguNy04Ljc4LTMuOTQtOC43OC04LjctOC43OFptMCwxNC4yOWMtMy4wNSwwLTUuMi0yLjM4LTUuMi01LjUxczIuMTUtNS41MSw1LjItNS41MSw1LjIsMi4zOCw1LjIsNS41MS0yLjE1LDUuNTEtNS4yLDUuNTFaIiBmaWxsPSJ3aGl0ZSI+PC9wYXRoPgogICAgICAgICAgPHBhdGggZD0iTTE5LjgsLjI2bC0uNzQsOS4xMmMtLjM1LS4wNC0uNy0uMDYtMS4wNi0uMDYtLjQ1LDAtLjg5LC4wMy0xLjMyLC4xbC0uNDItNC40MmMtLjAxLS4xNCwuMS0uMjYsLjI0LS4yNmguNzVsLS4zNi00LjQ3Yy0uMDEtLjE0LC4xLS4yNiwuMjMtLjI2aDIuNDVjLjE0LDAsLjI1LC4xMiwuMjMsLjI2aDBabS02LjE4LC40NWMtLjA0LS4xMy0uMTgtLjIxLS4zMS0uMTZsLTIuMywuODRjLS4xMywuMDUtLjE5LC4yLS4xMywuMzJsMS44Nyw0LjA4LS43MSwuMjZjLS4xMywuMDUtLjE5LC4yLS4xMywuMzJsMS45MSw0LjAxYy42OS0uMzgsMS40NC0uNjcsMi4yMy0uODVMMTMuNjMsLjcxWk03Ljk4LDMuMjVsNS4yOSw3LjQ2Yy0uNjcsLjQ0LTEuMjgsLjk2LTEuOCwxLjU2bC0zLjE3LTMuMTJjLS4xLS4xLS4wOS0uMjYsLjAxLS4zNWwuNTgtLjQ4LTMuMTUtMy4xOWMtLjEtLjEtLjA5LS4yNiwuMDItLjM1bDEuODctMS41N2MuMTEtLjA5LC4yNi0uMDcsLjM0LC4wNFpNMy41NCw3LjU3Yy0uMTEtLjA4LS4yNy0uMDQtLjM0LC4wOGwtMS4yMiwyLjEyYy0uMDcsLjEyLS4wMiwuMjcsLjEsLjMzbDQuMDYsMS45Mi0uMzgsLjY1Yy0uMDcsLjEyLS4wMiwuMjgsLjExLC4zM2w0LjA0LDEuODVjLjI5LS43NSwuNjgtMS40NSwxLjE2LTIuMDhMMy41NCw3LjU3Wk0uNTUsMTMuMzNjLjAyLS4xNCwuMTYtLjIyLC4yOS0uMTlsOC44NSwyLjMxYy0uMjMsLjc1LS4zNiwxLjU0LS4zOCwyLjM2bC00LjQzLS4zNmMtLjE0LS4wMS0uMjQtLjE0LS4yMS0uMjhsLjEzLS43NC00LjQ3LS40MmMtLjE0LS4wMS0uMjMtLjE0LS4yMS0uMjhsLjQyLTIuNDFoMFptLS4zMyw1Ljk4Yy0uMTQsLjAxLS4yMywuMTQtLjIxLC4yOGwuNDMsMi40MWMuMDIsLjE0LC4xNiwuMjIsLjI5LC4xOWw0LjM0LTEuMTMsLjEzLC43NGMuMDIsLjE0LC4xNiwuMjIsLjI5LC4xOWw0LjI4LTEuMThjLS4yNS0uNzQtLjQxLTEuNTMtLjQ1LTIuMzRMLjIxLDE5LjMxWm0xLjQyLDYuMzRjLS4wNy0uMTItLjAyLS4yNywuMS0uMzNsOC4yNi0zLjkyYy4zMSwuNzQsLjczLDEuNDMsMS4yMywyLjA1bC0zLjYyLDIuNThjLS4xMSwuMDgtLjI3LC4wNS0uMzQtLjA3bC0uMzgtLjY2LTMuNjksMi41NWMtLjExLC4wOC0uMjcsLjA0LS4zNC0uMDhsLTEuMjMtMi4xMlptMTAuMDEtMS43MmwtNi40Myw2LjUxYy0uMSwuMS0uMDksLjI2LC4wMiwuMzVsMS44OCwxLjU3Yy4xMSwuMDksLjI2LC4wNywuMzQtLjA0bDIuNi0zLjY2LC41OCwuNDljLjExLC4wOSwuMjcsLjA3LC4zNS0uMDVsMi41Mi0zLjY2Yy0uNjgtLjQyLTEuMzEtLjkzLTEuODUtMS41MVptLTEuMjcsMTAuNDVjLS4xMy0uMDUtLjE5LS4yLS4xMy0uMzJsMy44MS04LjMyYy43LC4zNiwxLjQ2LC42MywyLjI1LC43OGwtMS4xMiw0LjNjLS4wMywuMTMtLjE4LC4yMS0uMzEsLjE2bC0uNzEtLjI2LTEuMTksNC4zM2MtLjA0LC4xMy0uMTgsLjIxLS4zMSwuMTZsLTIuMy0uODRoMFptNi41Ni03Ljc1bC0uNzQsOS4xMmMtLjAxLC4xNCwuMSwuMjYsLjIzLC4yNmgyLjQ1Yy4xNCwwLC4yNS0uMTIsLjIzLS4yNmwtLjM2LTQuNDdoLjc1Yy4xNCwwLC4yNS0uMTIsLjI0LS4yNmwtLjQyLTQuNDJjLS40MywuMDctLjg3LC4xLTEuMzIsLjEtLjM2LDAtLjcxLS4wMi0xLjA2LS4wN2gwWk0yNS43NiwxLjk0Yy4wNi0uMTMsMC0uMjctLjEzLS4zMmwtMi4zLS44NGMtLjEzLS4wNS0uMjcsLjAzLS4zMSwuMTZsLTEuMTksNC4zMy0uNzEtLjI2Yy0uMTMtLjA1LS4yNywuMDMtLjMxLC4xNmwtMS4xMiw0LjNjLjgsLjE2LDEuNTUsLjQzLDIuMjUsLjc4TDI1Ljc2LDEuOTRoMFptNS4wMiwzLjYzbC02LjQzLDYuNTFjLS41NC0uNTgtMS4xNi0xLjA5LTEuODUtMS41MWwyLjUyLTMuNjZjLjA4LS4xMSwuMjQtLjE0LC4zNS0uMDVsLjU4LC40OSwyLjYtMy42NmMuMDgtLjExLC4yNC0uMTMsLjM0LS4wNGwxLjg4LDEuNTdjLjExLC4wOSwuMTEsLjI1LC4wMiwuMzVabTMuNDgsNS4xMmMuMTMtLjA2LC4xNy0uMjEsLjEtLjMzbC0xLjIzLTIuMTJjLS4wNy0uMTItLjIzLS4xNS0uMzQtLjA4bC0zLjY5LDIuNTUtLjM4LS42NWMtLjA3LS4xMi0uMjMtLjE2LS4zNC0uMDdsLTMuNjIsMi41OGMuNSwuNjIsLjkxLDEuMzEsMS4yMywyLjA1bDguMjYtMy45MlptMS4zLDMuMzJsLjQyLDIuNDFjLjAyLC4xNC0uMDcsLjI2LS4yMSwuMjhsLTkuMTEsLjg1Yy0uMDQtLjgyLS4yLTEuNi0uNDUtMi4zNGw0LjI4LTEuMThjLjEzLS4wNCwuMjcsLjA1LC4yOSwuMTlsLjEzLC43NCw0LjM0LTEuMTNjLjEzLS4wMywuMjcsLjA1LC4yOSwuMTloMFptLS40MSw4Ljg1Yy4xMywuMDMsLjI3LS4wNSwuMjktLjE5bC40Mi0yLjQxYy4wMi0uMTQtLjA3LS4yNi0uMjEtLjI4bC00LjQ3LS40MiwuMTMtLjc0Yy4wMi0uMTQtLjA3LS4yNi0uMjEtLjI4bC00LjQzLS4zNmMtLjAyLC44Mi0uMTUsMS42MS0uMzgsMi4zNmw4Ljg1LDIuMzFoMFptLTIuMzYsNS41Yy0uMDcsLjEyLS4yMywuMTUtLjM0LC4wOGwtNy41My01LjJjLjQ4LS42MywuODctMS4zMywxLjE2LTIuMDhsNC4wNCwxLjg1Yy4xMywuMDYsLjE4LC4yMSwuMTEsLjMzbC0uMzgsLjY1LDQuMDYsMS45MmMuMTIsLjA2LC4xNywuMjEsLjEsLjMzbC0xLjIyLDIuMTJoMFptLTEwLjA3LTMuMDdsNS4yOSw3LjQ2Yy4wOCwuMTEsLjI0LC4xMywuMzQsLjA0bDEuODctMS41N2MuMTEtLjA5LC4xMS0uMjUsLjAyLS4zNWwtMy4xNS0zLjE5LC41OC0uNDhjLjExLS4wOSwuMTEtLjI1LC4wMS0uMzVsLTMuMTctMy4xMmMtLjUzLC42LTEuMTMsMS4xMy0xLjgsMS41NmgwWm0tLjA1LDEwLjE2Yy0uMTMsLjA1LS4yNy0uMDMtLjMxLS4xNmwtMi40Mi04LjgyYy43OS0uMTgsMS41NC0uNDcsMi4yMy0uODVsMS45MSw0LjAxYy4wNiwuMTMsMCwuMjgtLjEzLC4zMmwtLjcxLC4yNiwxLjg3LDQuMDhjLjA2LC4xMywwLC4yNy0uMTMsLjMybC0yLjMsLjg0aDBaIiBmaWxsPSJ3aGl0ZSIgZmlsbC1ydWxlPSJldmVub2RkIj48L3BhdGg+CiAgICAgICAgPC9zdmc+"         x="340" y="284" width="72" height="24"/>
            <image href="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+CjwhLS0gR2VuZXJhdG9yOiBBZG9iZSBJbGx1c3RyYXRvciAxOS4wLjAsIFNWRyBFeHBvcnQgUGx1Zy1JbiAuIFNWRyBWZXJzaW9uOiA2LjAwIEJ1aWxkIDApICAtLT4KCjxzdmcKICAgdmVyc2lvbj0iMS4xIgogICBpZD0ibGF5ZXIiCiAgIHg9IjBweCIKICAgeT0iMHB4IgogICB2aWV3Qm94PSItMTUzIC00NiAyMjM1LjQ0NjUgNzIwIgogICB4bWw6c3BhY2U9InByZXNlcnZlIgogICBzb2RpcG9kaTpkb2NuYW1lPSJhdXRoMC1pbmMtbG9nby12ZWN0b3Iuc3ZnIgogICB3aWR0aD0iMjIzNS40NDY1IgogICBoZWlnaHQ9IjcyMCIKICAgaW5rc2NhcGU6dmVyc2lvbj0iMS4xIChjNjhlMjJjMzg3LCAyMDIxLTA1LTIzKSIKICAgeG1sbnM6aW5rc2NhcGU9Imh0dHA6Ly93d3cuaW5rc2NhcGUub3JnL25hbWVzcGFjZXMvaW5rc2NhcGUiCiAgIHhtbG5zOnNvZGlwb2RpPSJodHRwOi8vc29kaXBvZGkuc291cmNlZm9yZ2UubmV0L0RURC9zb2RpcG9kaS0wLmR0ZCIKICAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogICB4bWxuczpzdmc9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZGVmcwogICBpZD0iZGVmczExIiAvPjxzb2RpcG9kaTpuYW1lZHZpZXcKICAgaWQ9Im5hbWVkdmlldzkiCiAgIHBhZ2Vjb2xvcj0iI2ZmZmZmZiIKICAgYm9yZGVyY29sb3I9IiM2NjY2NjYiCiAgIGJvcmRlcm9wYWNpdHk9IjEuMCIKICAgaW5rc2NhcGU6cGFnZXNoYWRvdz0iMiIKICAgaW5rc2NhcGU6cGFnZW9wYWNpdHk9IjAuMCIKICAgaW5rc2NhcGU6cGFnZWNoZWNrZXJib2FyZD0iMCIKICAgc2hvd2dyaWQ9ImZhbHNlIgogICBmaXQtbWFyZ2luLXRvcD0iMCIKICAgZml0LW1hcmdpbi1sZWZ0PSIwIgogICBmaXQtbWFyZ2luLXJpZ2h0PSIwIgogICBmaXQtbWFyZ2luLWJvdHRvbT0iMCIKICAgaW5rc2NhcGU6em9vbT0iMC4zMTkwMTg0MSIKICAgaW5rc2NhcGU6Y3g9IjczNS4wNjczMSIKICAgaW5rc2NhcGU6Y3k9IjM2Mi4wNDgwOCIKICAgaW5rc2NhcGU6d2luZG93LXdpZHRoPSIxOTIwIgogICBpbmtzY2FwZTp3aW5kb3ctaGVpZ2h0PSIxMDE3IgogICBpbmtzY2FwZTp3aW5kb3cteD0iMTkxMiIKICAgaW5rc2NhcGU6d2luZG93LXk9Ii04IgogICBpbmtzY2FwZTp3aW5kb3ctbWF4aW1pemVkPSIxIgogICBpbmtzY2FwZTpjdXJyZW50LWxheWVyPSJsYXllciIgLz4KPHN0eWxlPgoJLnN0MHtmaWxsOndoaXRlO30KPC9zdHlsZT4KPHBhdGgKICAgY2xhc3M9InN0MCIKICAgZD0iTSAzNjAuMzM0ODQsNTM2LjQ4NDQ3IDI4OC4wMzY3LDMxNCA0NzcuMzUzNDcsMTc2LjQ4NDQ3IGMgNDYuNTgzODYsMTQyLjczMjkyIDAsMjc1LjAzMTA2IC0xMTcuMDE4NjMsMzYwIHogbSAxMTcuMDE4NjMsLTM2MCBMIDQwNS4wNTUzNCwtNDYgSCAxNzEuMDE4MDcgbCA3MS45MjU0NywyMjIuNDg0NDcgYyAwLDAgMjM0LjQwOTkzLDAgMjM0LjQwOTkzLDAgeiBNIDE3MS4wMTgwNywtNDYgSCAtNjMuMDE5MjAyIEwgLTEzNC45NDQ2NiwxNzYuNDg0NDcgSCA5OS4wOTI1OTUgWiBtIC0zMDYuMzM1NCwyMjIuNDg0NDcgYyAtNDYuMjExMTgsMTQyLjczMjkyIDAsMjc1LjAzMTA2IDExNy4wMTg2MjUsMzYwIEwgNTMuNjI2NzYxLDMxNCBaIG0gMTE3LjAxODYyNSwzNjAgTCAxNzEuMDE4MDcsNjc0IDM2MC4zMzQ4NCw1MzYuNDg0NDcgMTcxLjAxODA3LDM5OC45Njg5NCBaIgogICBpZD0icGF0aDQiCiAgIHN0eWxlPSJzdHJva2Utd2lkdGg6My43MjY3MSIgLz4KPHBhdGgKICAgZD0ibSA4MjQuNjgyNjcsODguOTA2ODMgYyAtMzAuMTg2MzQsMCAtNTYuNjQ1OTcsMTkuNzUxNTYgLTY1LjIxNzM5LDQ4LjgxOTg4IEwgNjU1Ljg2Mjc5LDQ5NCBoIDY4LjE5ODc2IGwgMzAuNTU5LC0xMDMuMjI5ODEgYyAwLjM3MjY4LC0xLjExODAyIDEuMTE4MDIsLTEuODYzMzYgMi4yMzYwMywtMS44NjMzNiBoIDEzNi43NzAxOSBjIDEuMTE4MDEsMCAxLjg2MzM1LDAuNzQ1MzQgMi4yMzYwMiwxLjg2MzM2IEwgOTI1LjY3NjQ2LDQ5NCBoIDY3LjgyNjA5IEwgODg5LjUyNzM5LDEzNy43MjY3MSBDIDg4MS4zMjg2MywxMDguNjU4MzkgODU0Ljg2OSw4OC45MDY4MyA4MjQuNjgyNjcsODguOTA2ODMgWiBtIDU0LjQwOTkzLDI0OC41NzE0MyBjIC0wLjM3MjY3LDAuNzQ1MzQgLTEuMTE4MDEsMC43NDUzNCAtMS44NjMzNSwwLjc0NTM0IEggNzcyLjg4MTQyIGMgLTAuNzQ1MzQsMCAtMS40OTA2OCwtMC4zNzI2NyAtMS44NjMzNSwtMC43NDUzNCAtMC4zNzI2NywtMC43NDUzNCAtMC4zNzI2NywtMS40OTA2OCAwLC0yLjIzNjAyIGwgNTEuODAxMjQsLTE3OS42MjczMyBjIDAuMzcyNjcsLTEuMTE4MDIgMS4xMTgwMiwtMS44NjMzNiAyLjIzNjAzLC0xLjg2MzM2IDEuMTE4MDEsMC4zNzI2NyAxLjQ5MDY4LDEuMTE4MDIgMS44NjMzNSwxLjg2MzM2IGwgNTIuMTczOTEsMTc5LjYyNzMzIGMgMCwwLjc0NTM0IDAsMS40OTA2OCAwLDIuMjM2MDIgeiBtIDMxNi43NzAxLC05OC43NTc3NiBoIDY1LjU5MDEgdiAyNTUuNjUyMTcgaCAtNTEuNDI4NiBsIC03LjA4MDcsLTIxLjYxNDkxIGMgLTAuMzcyNywtMC43NDUzNCAtMC43NDU0LC0xLjQ5MDY4IC0xLjQ5MDcsLTEuODYzMzUgLTAuNzQ1MywtMC4zNzI2NyAtMS40OTA3LC0wLjM3MjY3IC0yLjIzNiwwIC0yNC4yMjM2LDE4LjI2MDg3IC01My4yOTE5LDI4LjMyMjk4IC04My40NzgzLDI4LjY5NTY1IC0zNC4yODU3LDAgLTY1LjU5LC0yMC40OTY4OSAtNzkuMDA2MiwtNTIuMTczOTEgLTQuNDcyLC0xMC40MzQ3OCAtNi43MDgxLC0yMS4yNDIyNCAtNi43MDgxLC0zMi40MjIzNiBWIDIzOC43MjA1IGggNjUuNTkwMSB2IDE3Mi41NDY1OCBjIDAsMjAuNDk2OSAxNy4xNDI5LDM3LjI2NzA4IDM3LjYzOTcsMzcuMjY3MDggMjEuMjQyMywtMS4xMTgwMSA0Mi4xMTE4LC02LjcwODA3IDYwLjc0NTQsLTE2Ljc3MDE4IDAuNzQ1MywtMC4zNzI2OCAxLjQ5MDcsLTEuMTE4MDIgMS4xMTgsLTEuODYzMzYgeiBtIDU1NS4yNzk1LDc5LjAwNjIxIHYgMTc2LjY0NTk2IGggLTY1LjIxNzMgViAzMjEuNDUzNDIgYyAwLC05LjY4OTQ0IC00LjA5OTQsLTE5LjM3ODg5IC0xMS4xODAyLC0yNi4wODY5NiAtNy4wODA3LC03LjA4MDc1IC0xNi4zOTc1LC0xMC44MDc0NSAtMjYuNDU5NiwtMTAuODA3NDUgLTIxLjI0MjIsMS4xMTgwMSAtNDIuMTExOCw2LjcwODA3IC02MS4xMTgsMTYuNzcwMTggLTAuNzQ1NCwwLjM3MjY3IC0xLjExOCwxLjExODAxIC0xLjExOCwyLjIzNjAzIFYgNDk0LjM3MjY3IEggMTUyMC40NTkgViA5NC40OTY4OSBoIDY1LjU5MDEgdiAxNjAuMjQ4NDUgYyAwLDAuNzQ1MzQgMC4zNzI2LDEuODYzMzYgMS4xMTgsMi4yMzYwMyAwLjc0NTMsMC4zNzI2NyAxLjg2MzMsMC4zNzI2NyAyLjYwODcsMCAyMi43MzI5LC0xNC45MDY4NCA0OS4xOTI1LC0yMy4xMDU1OSA3Ni4wMjQ4LC0yMy40NzgyNiA0Ni41ODM5LDAuMzcyNjcgODQuMjIzNiwzNy42Mzk3NSA4NC41OTYzLDg0LjIyMzYgeiBtIC0zMzMuOTEzLC03OS4wMDYyMSBoIDM5Ljg3NTggdiA1MC42ODMyMyBoIC0zOS44NzU4IGMgLTAuNzQ1MywwIC0xLjExOCwwLjM3MjY3IC0xLjg2MzQsMC43NDUzNCAtMC4zNzI2LDAuMzcyNjcgLTAuNzQ1MywxLjExODAxIC0wLjc0NTMsMS44NjMzNSB2IDEzNy4xNDI4NiBjIDAsMTAuODA3NDUgOC45NDQxLDE5Ljc1MTU1IDIwLjEyNDIsMTkuNzUxNTUgMCwwIDAsMCAwLDAgNS45NjI4LDAgMTQuNTM0MiwwIDIyLjM2MDMsLTEuMTE4MDEgViA0OTQgYyAtMTMuMDQzNSwzLjcyNjcxIC0yNi40NTk3LDUuOTYyNzMgLTM5Ljg3NTgsNS41OTAwNiAtMzcuMjY3MSwwIC02Ny40NTM0LC0yOS44MTM2NiAtNjcuODI2MSwtNjcuMDgwNzQgViAyOTEuNjM5NzUgYyAwLC0xLjQ5MDY4IC0xLjExOCwtMi4yMzYwMiAtMi42MDg3LC0yLjYwODY5IGggLTM5LjEzMDQgdiAtNTAuNjgzMjMgaCAzOS44NzU4IGMgMS40OTA2LDAgMi4yMzYsLTEuMTE4MDIgMi42MDg3LC0yLjYwODcgdiAtODQuMjIzNiBoIDY1LjU5IHYgODQuMjIzNiBjIC0wLjM3MjcsMS40OTA2OCAwLjM3MjcsMi42MDg3IDEuNDkwNywyLjk4MTM3IHogbSA2MjYuNDU5NiwtOTIuNzk1MDMgYyAtMjIuMzYwMiwtMzUuNDAzNzMgLTYxLjExOCwtNTYuNjQ1OTcgLTEwMi44NTcxLC01Ni42NDU5NyAtNDEuNzM5MSwwIC04MC40OTY5LDIxLjI0MjI0IC0xMDIuODU3Miw1Ni42NDU5NyAtMjQuOTY4OSwzNi41MjE3MyAtMzguMzg1MSw4Ny45NTAzMSAtMzguMzg1MSwxNDguNjk1NjUgLTIuMjM2LDUyLjU0NjU4IDExLjU1MjgsMTA0LjM0NzgyIDM4Ljc1NzgsMTQ5LjA2ODMyIDIyLjM2MDMsMzUuNDAzNzMgNjEuMTE4LDU2LjY0NTk2IDEwMi44NTcyLDU2LjY0NTk2IDQxLjczOTEsMCA4MC40OTY5LC0yMS4yNDIyMyAxMDIuODU3MSwtNTYuNjQ1OTYgMjUuMzQxNiwtMzYuODk0NDEgMzguMzg1MSwtODguMzIyOTggMzguMzg1MSwtMTQ4LjY5NTY1IDAsLTYwLjM3MjY3IC0xMy40MTYyLC0xMTIuNTQ2NTkgLTM4LjM4NTEsLTE0OS4wNjgzMiB6IG0gLTUzLjY2NDYsMjY4LjY5NTY1IGMgLTEyLjY3MDgsMjMuMTA1NTkgLTI4LjY5NTYsMzQuMjg1NzEgLTQ4LjgxOTgsMzQuMjg1NzEgLTE5Ljc1MTYsMCAtMzUuNzc2NCwtMTEuOTI1NDYgLTQ4LjgxOTksLTM0LjI4NTcxIC0xNy4xNDI5LC0zNy42Mzk3NSAtMjUuMzQxNiwtNzguNjMzNTQgLTIzLjQ3ODMsLTEyMCAtMS44NjMzLC00MS4zNjY0NiA2LjMzNTQsLTgyLjczMjkyIDIzLjQ3ODMsLTEyMC43NDUzNCAxMi42NzA4LC0yMy4xMDU1OSAyOC42OTU2LC0zNC4yODU3MiA0OC40NDcyLC0zNC4yODU3MiAxOS43NTE1LDAgMzYuMTQ5MSwxMS4xODAxMyA0OC44MTk5LDM0LjI4NTcyIDE3LjE0MjgsMzcuNjM5NzUgMjUuMzQxNiw3OC42MzM1NCAyMy40NzgyLDEyMCAyLjIzNiw0MS43MzkxMyAtNS41OSw4My4xMDU1OSAtMjMuMTA1NiwxMjAuNzQ1MzQgeiIKICAgaWQ9InBhdGg2IgogICBzdHlsZT0ic3Ryb2tlLXdpZHRoOjMuNzI2NzEiIC8+Cjwvc3ZnPgo="            x="435" y="285" width="72" height="23"/>
            <image href="data:image/svg+xml;base64,PHN2ZyBhcmlhLWhpZGRlbj0idHJ1ZSIgZmlsbD0ibm9uZSIgaGVpZ2h0PSIyNCIgc3R5bGU9Im1hcmdpbi1ib3R0b206MHJlbSIgdmlld0JveD0iMCAwIDEyMyAyNCIgd2lkdGg9IjEyMyIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik05LjM0MzA0IDEzLjE0MjhIMC4yMDAxOTVDMC43NzU2OTEgMTkuMjM0MiA1LjkwNDUyIDI0IDEyLjE0NjUgMjRDMTMuNzY1MSAyNCAxNS4zMDg5IDIzLjY3OTUgMTYuNzE3OSAyMy4wOTg1QzEyLjY5MzUgMjEuNDM5MSA5Ljc2OTMgMTcuNjU0NiA5LjM0MzA0IDEzLjE0MjhaIiBmaWxsPSJ3aGl0ZSIgZmlsbC1ydWxlPSJldmVub2RkIj48L3BhdGg+PHBhdGggZD0iTTkuMzQzMDQgMTAuODU3MUM5Ljc2OTMgNi4zNDU0IDEyLjY5MzUgMi41NjA4NyAxNi43MTc5IDAuOTAxNDU5QzE1LjMwODkgMC4zMjA0ODQgMTMuNzY1MSAwIDEyLjE0NjUgMEM1LjkwNDUyIDAgMC43NzU2OTEgNC43NjU3OSAwLjIwMDE5NSAxMC44NTcxSDkuMzQzMDRaIiBmaWxsPSJ3aGl0ZSI+PC9wYXRoPjxwYXRoIGNsaXAtcnVsZT0iZXZlbm9kZCIgZD0iTTE0LjY2MTUgMTQuODU3MkMxMy43NDc0IDE4LjU5OTggMTEuMDc4IDIxLjY1NDIgNy41NzUyIDIzLjA5ODZDOC45ODQxNSAyMy42Nzk1IDEwLjUyOCAyNCAxMi4xNDY2IDI0QzE3Ljc4OTQgMjQgMjIuNTIyNiAyMC4xMDUyIDIzLjgwNDQgMTQuODU3MkgxNC42NjE1WiIgZmlsbD0id2hpdGUiIGZpbGwtcnVsZT0iZXZlbm9kZCI+PC9wYXRoPjxwYXRoIGQ9Ik0yMy43ODY4IDkuMTQyODZIMTQuNjQ0QzEzLjcyOTkgNS40MDAyNSAxMS4wNjA1IDIuMzQ1ODMgNy41NTc2MiAwLjkwMTQ1OUM4Ljk2NjU4IDAuMzIwNDgzIDEwLjUxMDQgMCAxMi4xMjkgMEMxNy43NzE5IDAgMjIuNTA1IDMuODk0ODQgMjMuNzg2OCA5LjE0Mjg2WiIgZmlsbD0id2hpdGUiPjwvcGF0aD48cGF0aCBkPSJNNDYuMDk2NCA5LjgwODc3QzQ1LjY5MTMgNi40NDk0IDQzLjE0NzQgNC41MTc1OCAzOS43NzkxIDQuNTE3NThDMzUuOTM0OCA0LjUxNzU4IDMzIDcuMjMwNjUgMzMgMTEuOTg5MkMzMyAxNi43MzM1IDM1Ljg4NSAxOS40NjA4IDM5Ljc3OTEgMTkuNDYwOEM0My41MDk4IDE5LjQ2MDggNDUuNzYyNCAxNi45ODIxIDQ2LjA5NjQgMTQuMzA0NUw0Mi45ODQgMTQuMjkwM0M0Mi42OTI2IDE1Ljg0NTcgNDEuNDcwNCAxNi43NDA2IDM5LjgyODkgMTYuNzQwNkMzNy42MTg5IDE2Ljc0MDYgMzYuMTE5NSAxNS4xIDM2LjExOTUgMTEuOTg5MkMzNi4xMTk1IDguOTYzNiAzNy41OTc2IDcuMjM3NzUgMzkuODUwMiA3LjIzNzc1QzQxLjUzNDMgNy4yMzc3NSA0Mi43NDk1IDguMjEwNzYgNDIuOTg0IDkuODA4NzdINDYuMDk2NFoiIGZpbGw9ImN1cnJlbnRDb2xvciI+PC9wYXRoPjxwYXRoIGQ9Ik01Mi4yMTAxIDE5LjQ3NUM1NC45MTA0IDE5LjQ3NSA1Ni43Mjk1IDE4LjE2MSA1Ny4xNTU5IDE2LjEzNjlMNTQuMzU2MSAxNS45NTIyQzU0LjA1MDYgMTYuNzgzMiA1My4yNjg5IDE3LjIxNjQgNTIuMjU5OSAxNy4yMTY0QzUwLjc0NjMgMTcuMjE2NCA0OS43ODcgMTYuMjE1IDQ5Ljc4NyAxNC41ODg2VjE0LjU4MTVINTcuMjE5OFYxMy43NTA1QzU3LjIxOTggMTAuMDQzMSA1NC45NzQzIDguMjEwNzYgNTIuMDg5MyA4LjIxMDc2QzQ4Ljg3NzQgOC4yMTA3NiA0Ni43OTUzIDEwLjQ5MDYgNDYuNzk1MyAxMy44NTcxQzQ2Ljc5NTMgMTcuMzE1OSA0OC44NDkgMTkuNDc1IDUyLjIxMDEgMTkuNDc1Wk00OS43ODcgMTIuNzA2NUM0OS44NTA5IDExLjQ2MzYgNTAuNzk2IDEwLjQ2OTMgNTIuMTM5IDEwLjQ2OTNDNTMuNDUzNyAxMC40NjkzIDU0LjM2MzIgMTEuNDA2OCA1NC4zNzAzIDEyLjcwNjVINDkuNzg3WiIgZmlsbD0iY3VycmVudENvbG9yIj48L3BhdGg+PHBhdGggZD0iTTY4LjUyMDMgMjMuMzUyOFY4LjM1MjgxSDY1LjUzNThWMTAuMTg1Mkg2NS40MDA4QzY0Ljk5NTcgOS4yOTc0MSA2NC4xMjE3IDguMjEwNzYgNjIuMjk1NSA4LjIxMDc2QzU5LjkwMDcgOC4yMTA3NiA1Ny44NzU1IDEwLjA3MTYgNTcuODc1NSAxMy44MjE2QzU3Ljg3NTUgMTcuNDcyMSA1OS44MTU1IDE5LjQzOTUgNjIuMzAyNiAxOS40Mzk1QzY0LjA2NDggMTkuNDM5NSA2NC45ODE1IDE4LjQyMzggNjUuNDAwOCAxNy41MTQ3SDY1LjQ5MzJWMjMuMzUyOEg2OC41MjAzWk02NS41NTcxIDEzLjgwNzRDNjUuNTU3MSAxNS43NTM0IDY0LjcxODYgMTcuMDMxOCA2My4yNjE5IDE3LjAzMThDNjEuNzc2NyAxNy4wMzE4IDYwLjk2NjYgMTUuNzEwOCA2MC45NjY2IDEzLjgwNzRDNjAuOTY2NiAxMS45MTgxIDYxLjc2MjUgMTAuNjE4NCA2My4yNjE5IDEwLjYxODRDNjQuNzMyOCAxMC42MTg0IDY1LjU1NzEgMTEuODYxMyA2NS41NTcxIDEzLjgwNzRaIiBmaWxsPSJjdXJyZW50Q29sb3IiPjwvcGF0aD48cGF0aCBkPSJNNzYuNTA0IDE0LjYxN0M3Ni41MTEyIDE2LjA4MDEgNzUuNTA5MiAxNi44NDcxIDc0LjQyMiAxNi44NDcxQzczLjI3NzkgMTYuODQ3MSA3Mi41Mzg5IDE2LjA0NDYgNzIuNTMxOCAxNC43NTkxVjguMzUyODFINjkuNTA0NlYxNS4yOTg4QzY5LjUxMTcgMTcuODQ4NSA3MS4wMDQgMTkuNDAzOSA3My4xOTk4IDE5LjQwMzlDNzQuODQxMiAxOS40MDM5IDc2LjAyMDggMTguNTU4OCA3Ni41MTEyIDE3LjI4MDRINzYuNjI0OVYxOS4yNjE5SDc5LjUzMTJWOC4zNTI4MUg3Ni41MDRWMTQuNjE3WiIgZmlsbD0iY3VycmVudENvbG9yIj48L3BhdGg+PHBhdGggZD0iTTg1LjYzMDkgMTkuNDc1Qzg4LjMzMTIgMTkuNDc1IDkwLjE1MDMgMTguMTYxIDkwLjU3NjcgMTYuMTM2OUw4Ny43NzY5IDE1Ljk1MjJDODcuNDcxMyAxNi43ODMyIDg2LjY4OTcgMTcuMjE2NCA4NS42ODA2IDE3LjIxNjRDODQuMTY3IDE3LjIxNjQgODMuMjA3NyAxNi4yMTUgODMuMjA3NyAxNC41ODg2VjE0LjU4MTVIOTAuNjQwNlYxMy43NTA1QzkwLjY0MDYgMTAuMDQzMSA4OC4zOTUxIDguMjEwNzYgODUuNTEwMSA4LjIxMDc2QzgyLjI5ODIgOC4yMTA3NiA4MC4yMTYxIDEwLjQ5MDYgODAuMjE2MSAxMy44NTcxQzgwLjIxNjEgMTcuMzE1OSA4Mi4yNjk3IDE5LjQ3NSA4NS42MzA5IDE5LjQ3NVpNODMuMjA3NyAxMi43MDY1QzgzLjI3MTcgMTEuNDYzNiA4NC4yMTY4IDEwLjQ2OTMgODUuNTU5OCAxMC40NjkzQzg2Ljg3NDQgMTAuNDY5MyA4Ny43ODQgMTEuNDA2OCA4Ny43OTExIDEyLjcwNjVIODMuMjA3N1oiIGZpbGw9ImN1cnJlbnRDb2xvciI+PC9wYXRoPjxwYXRoIGQ9Ik05NC40NDI2IDEyLjk1NTFDOTQuNDQ5NyAxMS41NDg4IDk1LjI4ODIgMTAuNzI1IDk2LjUxMDUgMTAuNzI1Qzk3LjcyNTYgMTAuNzI1IDk4LjQ1NzUgMTEuNTIwNCA5OC40NTA0IDEyLjg1NTZWMTkuMjYxOUgxMDEuNDc4VjEyLjMxNTlDMTAxLjQ3OCA5Ljc3MzI2IDk5Ljk4NTMgOC4yMTA3NiA5Ny43MTE0IDguMjEwNzZDOTYuMDkxMiA4LjIxMDc2IDk0LjkxODcgOS4wMDYyMSA5NC40Mjg0IDEwLjI3NzVIOTQuMzAwNVY4LjM1MjgxSDkxLjQxNTVWMTkuMjYxOUg5NC40NDI2VjEyLjk1NTFaIiBmaWxsPSJjdXJyZW50Q29sb3IiPjwvcGF0aD48cGF0aCBkPSJNMTA3LjQwNCAxOS40NzVDMTEwLjMxIDE5LjQ3NSAxMTIuMTM2IDE3Ljc3MDQgMTEyLjI3OSAxNS4yNjMzSDEwOS40MjJDMTA5LjI0NCAxNi40MjgxIDEwOC40NzcgMTcuMDgxNSAxMDcuNDM5IDE3LjA4MTVDMTA2LjAyNSAxNy4wODE1IDEwNS4xMDkgMTUuODk1NCAxMDUuMTA5IDEzLjgwNzRDMTA1LjEwOSAxMS43NDc3IDEwNi4wMzIgMTAuNTY4NyAxMDcuNDM5IDEwLjU2ODdDMTA4LjU0OCAxMC41Njg3IDEwOS4yNTggMTEuMzAwMiAxMDkuNDIyIDEyLjM4NjlIMTEyLjI3OUMxMTIuMTUxIDkuODY1NTkgMTEwLjIzOSA4LjIxMDc2IDEwNy4zOSA4LjIxMDc2QzEwNC4wNzggOC4yMTA3NiAxMDIuMDMyIDEwLjUwNDggMTAyLjAzMiAxMy44NUMxMDIuMDMyIDE3LjE2NjcgMTA0LjA0MyAxOS40NzUgMTA3LjQwNCAxOS40NzVaIiBmaWxsPSJjdXJyZW50Q29sb3IiPjwvcGF0aD48cGF0aCBkPSJNMTE3Ljk5IDE5LjQ3NUMxMjAuNjkxIDE5LjQ3NSAxMjIuNTEgMTguMTYxIDEyMi45MzYgMTYuMTM2OUwxMjAuMTM2IDE1Ljk1MjJDMTE5LjgzMSAxNi43ODMyIDExOS4wNDkgMTcuMjE2NCAxMTguMDQgMTcuMjE2NEMxMTYuNTI2IDE3LjIxNjQgMTE1LjU2NyAxNi4yMTUgMTE1LjU2NyAxNC41ODg2VjE0LjU4MTVIMTIzVjEzLjc1MDVDMTIzIDEwLjA0MzEgMTIwLjc1NCA4LjIxMDc2IDExNy44NjkgOC4yMTA3NkMxMTQuNjU4IDguMjEwNzYgMTEyLjU3NSAxMC40OTA2IDExMi41NzUgMTMuODU3MUMxMTIuNTc1IDE3LjMxNTkgMTE0LjYyOSAxOS40NzUgMTE3Ljk5IDE5LjQ3NVpNMTE1LjU2NyAxMi43MDY1QzExNS42MzEgMTEuNDYzNiAxMTYuNTc2IDEwLjQ2OTMgMTE3LjkxOSAxMC40NjkzQzExOS4yMzQgMTAuNDY5MyAxMjAuMTQzIDExLjQwNjggMTIwLjE1IDEyLjcwNjVIMTE1LjU2N1oiIGZpbGw9ImN1cnJlbnRDb2xvciI+PC9wYXRoPjxkZWZzPjxsaW5lYXJHcmFkaWVudCBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSIgaWQ9InBhaW50MF9saW5lYXIiIHgxPSI4LjQ5MjE5IiB4Mj0iOC40OTIxOSIgeTE9IjEzLjE0MjgiIHkyPSIyNCI+PHN0b3Agc3RvcC1jb2xvcj0iIzI5NzlGRiI+PC9zdG9wPjxzdG9wIG9mZnNldD0iMSIgc3RvcC1jb2xvcj0iIzQ0OEFGRiI+PC9zdG9wPjwvbGluZWFyR3JhZGllbnQ+PGxpbmVhckdyYWRpZW50IGdyYWRpZW50VW5pdHM9InVzZXJTcGFjZU9uVXNlIiBpZD0icGFpbnQxX2xpbmVhciIgeDE9IjE1LjY1MTciIHgyPSIxNS42NTE3IiB5MT0iMTQuODU3MiIgeTI9IjI0Ij48c3RvcCBzdG9wLWNvbG9yPSIjNDQ4QUZGIj48L3N0b3A+PHN0b3Agb2Zmc2V0PSIxIiBzdG9wLWNvbG9yPSIjMjk3OUZGIj48L3N0b3A+PC9saW5lYXJHcmFkaWVudD48L2RlZnM+PC9zdmc+"    x="530" y="289" width="76" height="15"/>
            <!-- Duplicate set (offset +570) for seamless loop -->
            <image href="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+CjwhLS0gQ3JlYXRlZCB3aXRoIElua3NjYXBlIChodHRwOi8vd3d3Lmlua3NjYXBlLm9yZy8pIC0tPgoKPHN2ZwogICB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iCiAgIHhtbG5zOmNjPSJodHRwOi8vY3JlYXRpdmVjb21tb25zLm9yZy9ucyMiCiAgIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyIKICAgeG1sbnM6c3ZnPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIKICAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogICB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIKICAgeG1sbnM6c29kaXBvZGk9Imh0dHA6Ly9zb2RpcG9kaS5zb3VyY2Vmb3JnZS5uZXQvRFREL3NvZGlwb2RpLTAuZHRkIgogICB4bWxuczppbmtzY2FwZT0iaHR0cDovL3d3dy5pbmtzY2FwZS5vcmcvbmFtZXNwYWNlcy9pbmtzY2FwZSIKICAgdmVyc2lvbj0iMS4xIgogICBpZD0ic3ZnODM0IgogICB4bWw6c3BhY2U9InByZXNlcnZlIgogICB3aWR0aD0iNDA5LjMzMjkyIgogICBoZWlnaHQ9IjE2Ni43NTA1OCIKICAgdmlld0JveD0iMCAwIDQwOS4zMzI5MiAxNjYuNzUwNTgiCiAgIHNvZGlwb2RpOmRvY25hbWU9IlBoYXNlZFJlbGVhc2UtQ1Muc3ZnIgogICBpbmtzY2FwZTp2ZXJzaW9uPSIwLjkyLjIgNWMzZTgwZCwgMjAxNy0wOC0wNiI+PG1ldGFkYXRhCiAgICAgaWQ9Im1ldGFkYXRhODQwIj48cmRmOlJERj48Y2M6V29yawogICAgICAgICByZGY6YWJvdXQ9IiI+PGRjOmZvcm1hdD5pbWFnZS9zdmcreG1sPC9kYzpmb3JtYXQ+PGRjOnR5cGUKICAgICAgICAgICByZGY6cmVzb3VyY2U9Imh0dHA6Ly9wdXJsLm9yZy9kYy9kY21pdHlwZS9TdGlsbEltYWdlIiAvPjxkYzp0aXRsZT48L2RjOnRpdGxlPjwvY2M6V29yaz48L3JkZjpSREY+PC9tZXRhZGF0YT48ZGVmcwogICAgIGlkPSJkZWZzODM4Ij48Y2xpcFBhdGgKICAgICAgIGNsaXBQYXRoVW5pdHM9InVzZXJTcGFjZU9uVXNlIgogICAgICAgaWQ9ImNsaXBQYXRoODUyIj48cGF0aAogICAgICAgICBkPSJNIDAsMCBIIDYxMiBWIDc5MiBIIDAgWiIKICAgICAgICAgaWQ9InBhdGg4NTAiCiAgICAgICAgIGlua3NjYXBlOmNvbm5lY3Rvci1jdXJ2YXR1cmU9IjAiIC8+PC9jbGlwUGF0aD48Y2xpcFBhdGgKICAgICAgIGNsaXBQYXRoVW5pdHM9InVzZXJTcGFjZU9uVXNlIgogICAgICAgaWQ9ImNsaXBQYXRoODYwIj48cGF0aAogICAgICAgICBkPSJtIC03NDkuMzY5LC00NS40MzkzIGggMiB2IC01OC43ODQ3IGggLTIgeiIKICAgICAgICAgaWQ9InBhdGg4NTgiCiAgICAgICAgIGlua3NjYXBlOmNvbm5lY3Rvci1jdXJ2YXR1cmU9IjAiIC8+PC9jbGlwUGF0aD48Y2xpcFBhdGgKICAgICAgIGNsaXBQYXRoVW5pdHM9InVzZXJTcGFjZU9uVXNlIgogICAgICAgaWQ9ImNsaXBQYXRoMTI1NiI+PHBhdGgKICAgICAgICAgZD0iTSAzNiwzOTEuNTIgSCAzMDQuMjI5IFYgMjcxLjQ3NSBIIDM2IFoiCiAgICAgICAgIGlkPSJwYXRoMTI1NCIKICAgICAgICAgaW5rc2NhcGU6Y29ubmVjdG9yLWN1cnZhdHVyZT0iMCIgLz48L2NsaXBQYXRoPjxjbGlwUGF0aAogICAgICAgY2xpcFBhdGhVbml0cz0idXNlclNwYWNlT25Vc2UiCiAgICAgICBpZD0iY2xpcFBhdGgxMzY4Ij48cGF0aAogICAgICAgICBkPSJNIDAsMCBIIDYxMiBWIDc5MiBIIDAgWiIKICAgICAgICAgaWQ9InBhdGgxMzY2IgogICAgICAgICBpbmtzY2FwZTpjb25uZWN0b3ItY3VydmF0dXJlPSIwIiAvPjwvY2xpcFBhdGg+PGNsaXBQYXRoCiAgICAgICBjbGlwUGF0aFVuaXRzPSJ1c2VyU3BhY2VPblVzZSIKICAgICAgIGlkPSJjbGlwUGF0aDEzOTYiPjxwYXRoCiAgICAgICAgIGQ9Ik0gMCwwIEggNjEyIFYgNzkyIEggMCBaIgogICAgICAgICBpZD0icGF0aDEzOTQiCiAgICAgICAgIGlua3NjYXBlOmNvbm5lY3Rvci1jdXJ2YXR1cmU9IjAiIC8+PC9jbGlwUGF0aD48Y2xpcFBhdGgKICAgICAgIGNsaXBQYXRoVW5pdHM9InVzZXJTcGFjZU9uVXNlIgogICAgICAgaWQ9ImNsaXBQYXRoMTQzMiI+PHBhdGgKICAgICAgICAgZD0iTSAwLDAgSCA2MTIgViA3OTIgSCAwIFoiCiAgICAgICAgIGlkPSJwYXRoMTQzMCIKICAgICAgICAgaW5rc2NhcGU6Y29ubmVjdG9yLWN1cnZhdHVyZT0iMCIgLz48L2NsaXBQYXRoPjwvZGVmcz48c29kaXBvZGk6bmFtZWR2aWV3CiAgICAgcGFnZWNvbG9yPSIjZmZmZmZmIgogICAgIGJvcmRlcmNvbG9yPSIjNjY2NjY2IgogICAgIGJvcmRlcm9wYWNpdHk9IjEiCiAgICAgb2JqZWN0dG9sZXJhbmNlPSIxMCIKICAgICBncmlkdG9sZXJhbmNlPSIxMCIKICAgICBndWlkZXRvbGVyYW5jZT0iMTAiCiAgICAgaW5rc2NhcGU6cGFnZW9wYWNpdHk9IjAiCiAgICAgaW5rc2NhcGU6cGFnZXNoYWRvdz0iMiIKICAgICBpbmtzY2FwZTp3aW5kb3ctd2lkdGg9IjEzODIiCiAgICAgaW5rc2NhcGU6d2luZG93LWhlaWdodD0iOTQ1IgogICAgIGlkPSJuYW1lZHZpZXc4MzYiCiAgICAgc2hvd2dyaWQ9ImZhbHNlIgogICAgIGZpdC1tYXJnaW4tdG9wPSIwIgogICAgIGZpdC1tYXJnaW4tbGVmdD0iMCIKICAgICBmaXQtbWFyZ2luLXJpZ2h0PSIwIgogICAgIGZpdC1tYXJnaW4tYm90dG9tPSIwIgogICAgIGlua3NjYXBlOnpvb209IjEiCiAgICAgaW5rc2NhcGU6Y3g9IjIyNC4xNzAxIgogICAgIGlua3NjYXBlOmN5PSIxNzEuNzEwOTciCiAgICAgaW5rc2NhcGU6d2luZG93LXg9IjE2OCIKICAgICBpbmtzY2FwZTp3aW5kb3cteT0iMjAiCiAgICAgaW5rc2NhcGU6d2luZG93LW1heGltaXplZD0iMCIKICAgICBpbmtzY2FwZTpjdXJyZW50LWxheWVyPSJnMTUxOCIgLz48ZwogICAgIGlkPSJnODQyIgogICAgIGlua3NjYXBlOmdyb3VwbW9kZT0ibGF5ZXIiCiAgICAgaW5rc2NhcGU6bGFiZWw9IlBoYXNlZFJlbGVhc2UtQ1MiCiAgICAgdHJhbnNmb3JtPSJtYXRyaXgoMS4zMzMzMzMzLDAsMCwtMS4zMzMzMzMzLC0yMzcuMDk1OTcsMTAwMi40MzQzKSI+PGcKICAgICAgIGlkPSJnMTUxOCIKICAgICAgIHRyYW5zZm9ybT0ibWF0cml4KDQuMjA1NDkyNywwLDAsNC4yMDU0OTI3LC0xOTM3Ljg0NDksLTI0MTkuMTAyNykiPjxnCiAgICAgICAgIGlkPSJnMTM5MiIKICAgICAgICAgY2xpcC1wYXRoPSJ1cmwoI2NsaXBQYXRoMTM5NikiCiAgICAgICAgIHN0eWxlPSJmaWxsOndoaXRlIiAvPjxnCiAgICAgICAgIGlkPSJnMTU1NyI+PGcKICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZTtmaWxsLW9wYWNpdHk6MSIKICAgICAgICAgICB0cmFuc2Zvcm09InRyYW5zbGF0ZSg1MTguMTc2Myw3MjQuOTE4OSkiCiAgICAgICAgICAgaWQ9ImcxNDAyIj48cGF0aAogICAgICAgICAgICAgaW5rc2NhcGU6Y29ubmVjdG9yLWN1cnZhdHVyZT0iMCIKICAgICAgICAgICAgIGlkPSJwYXRoMTQwNCIKICAgICAgICAgICAgIHN0eWxlPSJmaWxsOndoaXRlO2ZpbGwtb3BhY2l0eToxO2ZpbGwtcnVsZTpub256ZXJvO3N0cm9rZTpub25lIgogICAgICAgICAgICAgZD0ibSAwLDAgYyAtNi4xMjcsMS44NjIgLTEwLjU4LDcuNTE3IC0xMC41OCwxNC4yMDkgMCw2Ljc2MyA0LjU0OCwxMi40NjUgMTAuNzY4LDE0LjI3OSAwLjYzNywwLjE4OSAwLjQ3MiwwLjU5IC0wLjMwNiwwLjU5IC04LjI3MSwwIC0xNC45ODYsLTYuNjY5IC0xNC45ODYsLTE0Ljg2OSAwLC04LjIgNi43MTUsLTE0Ljg2OSAxNC45ODYsLTE0Ljg2OSBDIDAuNjYsLTAuNjYgMC43MDcsLTAuMjEyIDAsMCIgLz48L2c+PGcKICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZSIKICAgICAgICAgICB0cmFuc2Zvcm09InRyYW5zbGF0ZSg1MTAuNDQ3NCw3MzUuNjYzOSkiCiAgICAgICAgICAgaWQ9ImcxNDA2Ij48cGF0aAogICAgICAgICAgICAgaW5rc2NhcGU6Y29ubmVjdG9yLWN1cnZhdHVyZT0iMCIKICAgICAgICAgICAgIGlkPSJwYXRoMTQwOCIKICAgICAgICAgICAgIHN0eWxlPSJmaWxsOndoaXRlO2ZpbGwtb3BhY2l0eToxO2ZpbGwtcnVsZTpub256ZXJvO3N0cm9rZTpub25lIgogICAgICAgICAgICAgZD0ibSAwLDAgYyAtMC4wNDcsMC40MDEgLTAuMDcxLDAuODAxIC0wLjA3MSwxLjIwMiAwLDYuNTI3IDUuMjc5LDExLjgwNSAxMS44MDYsMTEuODA1IDYuMTczLDAgOC4wMTEsLTIuNzU3IDguMjQ3LC0yLjU2OCAwLjI1OSwwLjE4OCAtMi4yMzksNS42NTUgLTkuNDczLDUuNjU1IC02LjUyNywwIC0xMS44MDUsLTUuMjc4IC0xMS44MDUsLTExLjgwNSAwLC0xLjUwOCAwLjI4MywtMi45NDYgMC44MDEsLTQuMjY1IEMgLTAuMjgzLC0wLjU0MiAwLjA0NywtMC41NDIgMCwwIiAvPjwvZz48ZwogICAgICAgICAgIHN0eWxlPSJmaWxsOndoaXRlO2ZpbGwtb3BhY2l0eToxIgogICAgICAgICAgIHRyYW5zZm9ybT0idHJhbnNsYXRlKDUxNS4zOTU4LDc0NC4xNzA0KSIKICAgICAgICAgICBpZD0iZzE0MTAiPjxwYXRoCiAgICAgICAgICAgICBpbmtzY2FwZTpjb25uZWN0b3ItY3VydmF0dXJlPSIwIgogICAgICAgICAgICAgaWQ9InBhdGgxNDEyIgogICAgICAgICAgICAgc3R5bGU9ImZpbGw6d2hpdGU7ZmlsbC1vcGFjaXR5OjE7ZmlsbC1ydWxlOm5vbnplcm87c3Ryb2tlOm5vbmUiCiAgICAgICAgICAgICBkPSJtIDAsMCBjIDMuMDYzLDEuMzQzIDYuOTI4LDEuMzkgMTAuNzIxLDAuMDQ3IDIuNTQ1LC0wLjg5NSA0LjAzLC0yLjE2OCA0LjE0OCwtMi4wOTcgMC4yMTIsMC4wOTQgLTEuNDg1LDIuNzU3IC00LjUyNSwzLjkxMiBDIDYuNjY4LDMuMjUyIDIuNzEsMi41MjEgLTAuMTY1LDAuMjU5IC0wLjQ5NSwwIC0wLjM3NywtMC4xNjUgMCwwIiAvPjwvZz48ZwogICAgICAgICAgIHN0eWxlPSJmaWxsOndoaXRlO2ZpbGwtb3BhY2l0eToxIgogICAgICAgICAgIHRyYW5zZm9ybT0idHJhbnNsYXRlKDU3Ni4wNzIsNzM4LjYwOTQpIgogICAgICAgICAgIGlkPSJnMTQxNCI+PHBhdGgKICAgICAgICAgICAgIGlua3NjYXBlOmNvbm5lY3Rvci1jdXJ2YXR1cmU9IjAiCiAgICAgICAgICAgICBpZD0icGF0aDE0MTYiCiAgICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZTtmaWxsLW9wYWNpdHk6MTtmaWxsLXJ1bGU6bm9uemVybztzdHJva2U6bm9uZSIKICAgICAgICAgICAgIGQ9Im0gMCwwIGMgMCwtMC44NDggLTAuNzA3LC0xLjU1NSAtMS41NTUsLTEuNTU1IC0wLjg0OSwwIC0xLjU1NSwwLjY4MyAtMS41NTUsMS41NTUgMCwwLjg0OCAwLjY4MywxLjU1NSAxLjU1NSwxLjU1NSBDIC0wLjY4MywxLjU1NSAwLDAuODcyIDAsMCIgLz48L2c+PHBhdGgKICAgICAgICAgICBpbmtzY2FwZTpjb25uZWN0b3ItY3VydmF0dXJlPSIwIgogICAgICAgICAgIGlkPSJwYXRoMTQyMCIKICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZTtmaWxsLW9wYWNpdHk6MTtmaWxsLXJ1bGU6bm9uemVybztzdHJva2U6bm9uZSIKICAgICAgICAgICBkPSJtIDUyNS40NTc0LDcyOS45MTQ0IDAuMTg4LC0yLjA3NCBoIDMuMjc2IGwgLTEuMTA4LDEyLjA0MSBoIC00Ljg3NyBsIC02LjE3NCwtMTIuMDQxIGggMy4zNDYgbCAxLjAzNywyLjA3NCB6IG0gLTAuMTY1LDIuMzMzIGggLTIuOTkzIGwgMi41NjksNS4yMDcgaCAwLjAyMyB6IiAvPjxwYXRoCiAgICAgICAgICAgaW5rc2NhcGU6Y29ubmVjdG9yLWN1cnZhdHVyZT0iMCIKICAgICAgICAgICBpZD0icGF0aDE0MjQiCiAgICAgICAgICAgc3R5bGU9ImZpbGw6d2hpdGU7ZmlsbC1vcGFjaXR5OjE7ZmlsbC1ydWxlOm5vbnplcm87c3Ryb2tlOm5vbmUiCiAgICAgICAgICAgZD0ibSA1MzMuNDY5LDczMy4wOTU2IGggMC40OTUgbCAyLjMzMywzLjE4MSBoIDMuMDM5IGwgLTMuMjI4LC00LjA1MyAxLjk4LC00LjM4MyBoIC0zLjIyOSBsIC0xLjI5NiwzLjQxNyBoIC0wLjQ3MSBsIC0wLjczLC0zLjQxNyBoIC0yLjc1NyBsIDIuNTQ0LDEyLjA0MSBoIDIuNzU3IHoiIC8+PGcKICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZTtmaWxsLW9wYWNpdHk6MSIKICAgICAgICAgICBjbGlwLXBhdGg9InVybCgjY2xpcFBhdGgxNDMyKSIKICAgICAgICAgICBpZD0iZzE0MjgiPjxnCiAgICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZTtmaWxsLW9wYWNpdHk6MSIKICAgICAgICAgICAgIHRyYW5zZm9ybT0idHJhbnNsYXRlKDU0My42NDg1LDcyNy44NDA4KSIKICAgICAgICAgICAgIGlkPSJnMTQzNCI+PHBhdGgKICAgICAgICAgICAgICAgaW5rc2NhcGU6Y29ubmVjdG9yLWN1cnZhdHVyZT0iMCIKICAgICAgICAgICAgICAgaWQ9InBhdGgxNDM2IgogICAgICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZTtmaWxsLW9wYWNpdHk6MTtmaWxsLXJ1bGU6bm9uemVybztzdHJva2U6bm9uZSIKICAgICAgICAgICAgICAgZD0iTSAwLDAgSCAyLjc1NyBMIDMuODY0LDUuMjU1IEMgNC40NzcsOC4xNTMgMy4zNyw4LjUwNiAwLjU0Miw4LjUwNiBjIC0xLjk3OSwwIC0zLjg4OCwwLjAyNCAtNC40MywtMi41OTEgaCAyLjc1NyBjIDAuMTY1LDAuNzU0IDAuNjM2LDAuOTE4IDEuMzIsMC45MTggMS4yMDEsMCAxLjE1NCwtMC40OTQgMC45ODksLTEuMjcyIEwgMC44OTUsNC4yMTggSCAwLjc3OCBDIDAuNjgzLDUuMTg0IC0wLjU0Miw1LjE2IC0xLjMyLDUuMTYgYyAtMi4wMDIsMCAtMy4xODEsLTAuNjM2IC0zLjYwNSwtMi42NjIgLTAuNDQ3LC0yLjE0NCAwLjU2NiwtMi42MTYgMi40OTgsLTIuNjE2IDAuOTY2LDAgMi4yNjIsMC4xODkgMi43MSwxLjM0MyBIIDAuMzc3IFogTSAtMC43NzgsMy40ODcgQyAwLjExOCwzLjQ4NyAwLjcwNywzLjQxNyAwLjU2NSwyLjcxIDAuMzc3LDEuODM4IDAsMS42NzMgLTEuMTU1LDEuNjczIGMgLTAuNDI0LDAgLTEuMjAxLDAgLTEuMDEzLDAuOTE5IDAuMTY1LDAuNzc4IDAuNzA3LDAuODk1IDEuMzksMC44OTUiIC8+PC9nPjxnCiAgICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZTtmaWxsLW9wYWNpdHk6MSIKICAgICAgICAgICAgIHRyYW5zZm9ybT0idHJhbnNsYXRlKDU1MS45OSw3MzYuMjc2NikiCiAgICAgICAgICAgICBpZD0iZzE0MzgiPjxwYXRoCiAgICAgICAgICAgICAgIGlua3NjYXBlOmNvbm5lY3Rvci1jdXJ2YXR1cmU9IjAiCiAgICAgICAgICAgICAgIGlkPSJwYXRoMTQ0MCIKICAgICAgICAgICAgICAgc3R5bGU9ImZpbGw6d2hpdGU7ZmlsbC1vcGFjaXR5OjE7ZmlsbC1ydWxlOm5vbnplcm87c3Ryb2tlOm5vbmUiCiAgICAgICAgICAgICAgIGQ9Im0gMCwwIC0wLjI1OSwtMS4xNzggaCAwLjExOCBjIDAuNTQyLDAuOTkgMS42NDksMS4yNzIgMi41OTIsMS4yNzIgMS4xNzgsMCAyLjM1NiwtMC4yMTIgMi4xOTEsLTEuNjQ5IEggNC43NiBjIDAuNCwxLjIwMiAxLjYyNiwxLjY0OSAyLjY4NiwxLjY0OSAxLjk1NiwwIDIuNzgxLC0wLjgwMSAyLjM1NiwtMi43NTcgTCA4LjU3NywtOC40MzYgSCA1LjgyIGwgMS4wMzcsNC44NzggYyAwLjE0MSwwLjg3MiAwLjI4MywxLjUzMiAtMC43NzgsMS41MzIgLTEuMDg0LDAgLTEuNDM3LC0wLjcwNyAtMS42MjYsLTEuNjI2IEwgMy40NCwtOC40MzYgSCAwLjY4MyBsIDEuMDg0LDUuMTE0IGMgMC4xNDIsMC43NzcgMC4xODksMS4yOTYgLTAuNzc3LDEuMjk2IC0xLjEzMSwwIC0xLjQ4NSwtMC42MTMgLTEuNjk3LC0xLjYyNiBMIC0xLjcyLC04LjQzNiBIIC00LjQ3NyBMIC0yLjY4NiwwIFoiIC8+PC9nPjxnCiAgICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZTtmaWxsLW9wYWNpdHk6MSIKICAgICAgICAgICAgIHRyYW5zZm9ybT0idHJhbnNsYXRlKDU2Ni45MDU4LDcyNy44NDA4KSIKICAgICAgICAgICAgIGlkPSJnMTQ0MiI+PHBhdGgKICAgICAgICAgICAgICAgaW5rc2NhcGU6Y29ubmVjdG9yLWN1cnZhdHVyZT0iMCIKICAgICAgICAgICAgICAgaWQ9InBhdGgxNDQ0IgogICAgICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZTtmaWxsLW9wYWNpdHk6MTtmaWxsLXJ1bGU6bm9uemVybztzdHJva2U6bm9uZSIKICAgICAgICAgICAgICAgZD0ibSAwLDAgaCAyLjc1NyBsIDEuMTMxLDUuMjU1IGMgMC42MTMsMi44OTggLTAuNDk1LDMuMjUxIC0zLjMyMiwzLjI1MSAtMS45OCwwIC0zLjg4OSwwLjAyNCAtNC40MywtMi41OTEgaCAyLjc1NyBjIDAuMTY0LDAuNzU0IDAuNjM2LDAuOTE4IDEuMzE5LDAuOTE4IDEuMjAyLDAgMS4xNTUsLTAuNDk0IDAuOTksLTEuMjcyIEwgMC45MTksNC4yMTggSCAwLjgwMSBDIDAuNzA3LDUuMTg0IC0wLjUxOCw1LjE2IC0xLjI5Niw1LjE2IGMgLTIuMDAzLDAgLTMuMTgxLC0wLjYzNiAtMy42MDUsLTIuNjYyIC0wLjQ0OCwtMi4xNDQgMC41NjUsLTIuNjE2IDIuNDk3LC0yLjYxNiAwLjk2NywwIDIuMjYzLDAuMTg5IDIuNzEsMS4zNDMgSCAwLjQwMSBaIE0gLTAuNzU0LDMuNDg3IEMgMC4xNDEsMy40ODcgMC43MywzLjQxNyAwLjU4OSwyLjcxIDAuNDAxLDEuODM4IDAuMDI0LDEuNjczIC0xLjEzMSwxLjY3MyBjIC0wLjQyNCwwIC0xLjIwMiwwIC0xLjAxMywwLjkxOSAwLjE2NSwwLjc3OCAwLjcwNywwLjg5NSAxLjM5LDAuODk1IiAvPjwvZz48L2c+PHBhdGgKICAgICAgICAgICBpbmtzY2FwZTpjb25uZWN0b3ItY3VydmF0dXJlPSIwIgogICAgICAgICAgIGlkPSJwYXRoMTQ0OCIKICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZTtmaWxsLW9wYWNpdHk6MTtmaWxsLXJ1bGU6bm9uemVybztzdHJva2U6bm9uZSIKICAgICAgICAgICBkPSJtIDU3My42Njg1LDcyNy44NDA4IGggLTIuNzU3IGwgMS43NjcsOC40MzYgaCAyLjc4MSB6IiAvPjwvZz48L2c+PC9nPjwvc3ZnPg=="              x="625" y="282" width="76" height="31"/>
            <image href="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDA5NiIgaGVpZ2h0PSI1MjgiIHZpZXdCb3g9IjAgMCA0MDk2IDUyOCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGcgY2xpcC1wYXRoPSJ1cmwoI2NsaXAwXzNfNjcpIj4KPHBhdGggZD0iTTI5MzQuMTEgMTI0LjY0M0MyODIxLjcyIDEyNC42NDMgMjc0My4yMiAyMDcuNTU3IDI3NDMuMjIgMzI2LjMwM0MyNzQzLjIyIDQ0NS4wNDggMjgyMS43MiA1MjcuOTYyIDI5MzQuMTEgNTI3Ljk2MkMyOTg4LjM1IDUyNy45NjIgMzAzNy4xNyA1MDcuNDk4IDMwNzEuNjEgNDcwLjMxOUMzMTA1LjU3IDQzMy42NTEgMzEyNC4yOCAzODIuMjM0IDMxMjQuMjggMzI1LjUzOEMzMTI0LjI4IDIwNy4yMyAzMDQ2LjA3IDEyNC42MDcgMjkzNC4xMSAxMjQuNjA3VjEyNC42NDNaTTI5MzQuMTEgNDQ2LjkwNUMyODczLjg4IDQ0Ni45MDUgMjgzMS44MiAzOTcuMzEgMjgzMS44MiAzMjYuMzM5QzI4MzEuODIgMjU1LjM2OSAyODczLjg4IDIwNS43NzMgMjkzNC4xMSAyMDUuNzczQzI5OTQuMzQgMjA1Ljc3MyAzMDM1LjY4IDI1NS4wNDEgMzAzNS42OCAzMjUuNjExQzMwMzUuNjggMzk2LjE4MSAyOTkzLjkxIDQ0Ni45NDIgMjkzNC4xMSA0NDYuOTQyVjQ0Ni45MDVaIiBmaWxsPSJ3aGl0ZSIvPgo8cGF0aCBkPSJNMTc3MS44MiAzMy43NTM4SDE2ODIuNDlWMTM2LjY1OUgxNjExLjg0VjIxNy43NTNIMTY4Mi40OVY1MTYuNzFIMTc3MS44MlYyMTcuNzUzSDE4NDMuMTZWMTM2LjY1OUgxNzcxLjgyVjMzLjc1MzhaIiBmaWxsPSJ3aGl0ZSIvPgo8cGF0aCBkPSJNNDA0OS44MiAxNzcuNjI2QzQwMTkuMDIgMTQyLjk2IDM5NzQuMDggMTI0LjY0NCAzOTE5Ljg4IDEyNC42NDRDMzgxMC41NCAxMjQuNjQ0IDM3MzQuMTUgMjA3Ljg4NSAzNzM0LjE1IDMyNy4wNjhDMzczNC4xNSA0NDYuMjUgMzgxMC41NCA1MjcuOTk5IDM5MTkuODggNTI3Ljk5OUMzOTk2LjMxIDUyNy45OTkgNDA1Ni4xNCA0OTAuNjc1IDQwODguMzYgNDIyLjg3Mkw0MDg5LjYzIDQyMC4xNzhMNDAwOS4wNiAzOTMuNzA1TDQwMDguMDUgMzk1LjU2MkMzOTg5LjIzIDQyOS42NDUgMzk1OS4yMiA0NDcuNjM0IDM5MjEuMzMgNDQ3LjYzNEMzODY5Ljc5IDQ0Ny42MzQgMzgzMC45MiA0MTAuODkyIDM4MjEuNjYgMzUzLjcyM0g0MDk0LjMyTDQwOTQuNzIgMzQ3Ljg5NkM0MDk1LjM3IDMzOC4yMSA0MDk1Ljk5IDMyOS4wMzQgNDA5NS45OSAzMTguODM4QzQwOTUuOTkgMjYwLjQ2NyA0MDgwLjAxIDIxMS42MzYgNDA0OS44MiAxNzcuNjYyVjE3Ny42MjZaTTM4MjQuOTYgMjgzLjE1M0MzODM4LjY2IDIzMy42NjYgMzg3My45MyAyMDQuMjQ0IDM5MTkuODUgMjA0LjI0NEMzOTY4LjA5IDIwNC4yNDQgMzk5OS45NCAyMzIuMjQ2IDQwMDkuNzkgMjgzLjE1M0gzODI0Ljk2WiIgZmlsbD0id2hpdGUiLz4KPHBhdGggZD0iTTU1NC41NDggNDQ5LjI3NEM1OTIuMTEgNDA2LjQ1MSA2MTEuMTgxIDM0Mi4zMjYgNjExLjE4MSAyNTguNjQ3VjI1OC4wMjhDNjExLjE4MSAxNzQuMzUgNTkyLjExIDExMC4xODggNTU0LjU0OCA2Ny40MDIzQzUxNi4yMjQgMjMuNzA1NyA0NzkuOTcxIDAuMDM2NzQzMiAzOTguMTI4IDAuMDM2NzQzMkgyMjIuMDkxQzIzMS41MzYgOS43OTU2NCAyNTMuNDQgMzIuNDgxNCAyNjAuNzQyIDM5Ljk4MjdDMjY0LjE5MyA0My41MTQ4IDI2Ni45OSA0Ni4yNDU4IDI2OS4xMzMgNDguMzIxNEwyNjkuNDI0IDQ4LjYxMjdDMjcwLjYyMyA0OS43NzggMjcxLjYwMyA1MC43MjQ3IDI3Mi4yOTQgNTEuNDg5NEMyNzMuMDU3IDUyLjI1NDEgMjczLjU2NSA1Mi44MDAzIDI3My44OTIgNTMuMDkxNkMyODguNDIzIDY3LjY5MzYgMzA1LjM1MSA3My41OTI2IDMzMi40NSA3My41OTI2QzMzMy40NjcgNzMuNTkyNiAzMzUuNDY1IDczLjU5MjYgMzM4LjIyNiA3My41OTI2QzM0NC43MjggNzMuNTU2MiAzNTcuNzMzIDczLjU5MjYgMzcxLjc1NSA3My41OTI2QzM4MC42NTUgNzMuNTkyNiAzODkuOTkxIDczLjU5MjYgMzk4LjM0NiA3My41OTI2QzQ3MC45MjUgNzMuNTkyNiA0OTIuNjEyIDExNi4zNDIgNDk2LjM1NCAxMjUuMjI3QzQ5OS45ODYgMTMwLjMyNSA1MDMuMDAyIDEzNi4wNzkgNTA1LjMyNiAxNDIuMzQyQzUxOC40NCAxNzcuMzcyIDUyNS4xNjEgMjE3LjUzNiA1MjQuNzk3IDI1OC40MjlDNTI1LjE2MSAyOTguNTkzIDUxOC40NCAzMzguNjg1IDUwNS4zMjYgMzc0LjI2MUM0ODIuNDc3IDQzNi4zMSA0MjQuNDY0IDQ0My4wMTEgNDAwLjU2MiA0NDMuMDExSDMzMi40NUMzMDYuMzMxIDQ0My4wMTEgMjgwLjg2NyA0NTQuOTU0IDI2MC43NDIgNDc2LjYyQzI1MS4xMTUgNDg2Ljk5OCAyMzEuNjgxIDUwNy40NjMgMjIzLjAzNSA1MTYuNTY2SDM5OC4wMTlDNDc5LjkzNCA1MTYuNTY2IDUxNi4yMjQgNDkyLjg5NyA1NTQuNTQ4IDQ0OS4yMzdWNDQ5LjI3NFoiIGZpbGw9IndoaXRlIi8+CjxwYXRoIGQ9Ik0zMzkuMTA1IDI1OC4zOTlDMzM5LjEwNSAyNTguMzk5IDMzOS4xMDUgMjU4LjM5OSAzMzkuMTA1IDI1OC4zNjJDMzM5LjEwNSAyNTguMzYyIDMzOS4xMDUgMjU4LjM2MiAzMzkuMTA1IDI1OC4zMjZDMzM5LjEwNSAyNTguMzI2IDMzOS4xMDUgMjU4LjMyNiAzMzkuMTA1IDI1OC4yODlDMzM5Ljc1OSAyMjAuMjM3IDMzMi40NTggMTg2LjcgMzI2LjYwOSAxNjguMzExQzMxOS40MTcgMTQ1LjYyNSAzMTIuMjk3IDEzNy4wNjggMzEwLjA0NCAxMzQuMTkxQzI3NS4yMDggODkuMTEwOSAyMzQuODg1IDEwOC41NTYgMjAwLjM3NSA4NC45OTYxQzE2NS45MDIgNjEuNDcyOCAxNjAuMTI2IDQzLjYzMDEgMTQ3Ljg0OCAzMS4xNDAxQzE0NS43NDEgMjguOTkxNyAxNDEuMDkxIDI0LjI1NzkgMTMzLjg5OCAxOS4zMDU2QzEzMy44OTggMTkuMzA1NiAxMjIuNjM3IDExLjU0OTUgMTA2Ljk4MSA2LjY3MDA1QzkwLjAxNjQgMS4zMTcyMyAzOC44NjkxIC0wLjA2NjQ5NzIgMCAwLjA0Mjc0NDFWNzguMjIzMkgxMTUuOTE3QzEyOS43OTQgNzcuOTMxOCAxNjMuNTQxIDc5LjI0MjcgMTkzLjI5MiAxMDIuNzNDMjA4LjgzOSAxMTUuMDAxIDIxNy4wNDkgMTI4LjM2NSAyMjIuMDk5IDEzNi43MDRDMjQ2LjAwMSAxNzYuMzk1IDI0Ni43MjggMjI0LjY0MyAyNDcuMiAyNTguMjE3VjI1OC4zOTlDMjQ2LjcyOCAyOTEuOTcyIDI0Ni4wMDEgMzQwLjIyIDIyMi4wOTkgMzc5LjkxMUMyMTcuMDg2IDM4OC4yNSAyMDguODM5IDQwMS42NSAxOTMuMjkyIDQxMy44ODZDMTYzLjUwNCA0MzcuMzcyIDEyOS43OTQgNDM4LjY4MyAxMTUuOTE3IDQzOC4zOTJIMFY1MTYuNTcyQzM4Ljg2OTEgNTE2LjcxOCA5MC4wMTY0IDUxNS4yOTggMTA2Ljk4MSA1MDkuOTgxQzEyMi42MzcgNTA1LjA2NiAxMzMuODk4IDQ5Ny4zNDYgMTMzLjg5OCA0OTcuMzQ2QzE0MS4wOTEgNDkyLjM5NCAxNDUuNzQxIDQ4Ny42NiAxNDcuODQ4IDQ4NS41MTFDMTYwLjEyNiA0NzMuMDIxIDE2NS45MDIgNDU1LjIxNSAyMDAuMzc1IDQzMS42NTVDMjM0Ljg0OSA0MDguMTMyIDI3NS4yMDggNDI3LjU3NyAzMTAuMDQ0IDM4Mi40NkMzMTIuMjk3IDM3OS41ODQgMzE5LjQxNyAzNzEuMDI2IDMyNi42MDkgMzQ4LjM0MUMzMzIuNDIxIDMyOS45NTIgMzM5Ljc1OSAyOTYuNDE1IDMzOS4xMDUgMjU4LjM2MlYyNTguMzk5WiIgZmlsbD0id2hpdGUiLz4KPHBhdGggZD0iTTI3MTUuMzkgMjU4LjM5MkMyNzEzLjQ3IDk4Ljc1NDIgMjY1Mi44OCAwIDI0NjQuNzQgMEgyMzEyLjA2SDIzMTIuMUwyMjg0LjE2IDAuMDM2NDEzOFYyNTguMzkyVjUxNi43NDhIMjMxMi4xSDIzMTIuMDZMMjQ2NC43NCA1MTYuNzg0QzI2NTIuODggNTE2Ljc4NCAyNzEzLjQ3IDQxOC4wMyAyNzE1LjM5IDI1OC4zOTJaTTI0NjUuNDcgNDMxLjE3NkgyMzc3Ljg5VjI1OC4zOTJWODUuNjA4OEgyNDY1LjQ3QzI0OTEuNTUgODUuOTM2NSAyNTQ1Ljg5IDg1LjQyNjggMjU3Ny41MyAxMTkuNzI5QzI2MDQuNjMgMTQ5LjA3OCAyNjEzLjQzIDIwNS43NzQgMjYxNC41OSAyNTguMzkyQzI2MTQuNTkgMzE4LjAwMiAyNjA0LjYgMzY3LjcwNiAyNTc3LjUzIDM5Ny4wNTZDMjU0NS44OSA0MzEuMzU4IDI0OTEuNTUgNDMwLjg0OCAyNDY1LjQ3IDQzMS4xNzZaIiBmaWxsPSJ3aGl0ZSIvPgo8cGF0aCBkPSJNMTE3Mi4xOCAyNTguMzkyQzExNzAuMjEgOTguNzU0MiAxMTA5LjY2IDAgOTIxLjQ4OCAwSDc2OC44MDlINzY4Ljg0NUw3NDAuOTEgMC4wMzY0MTM4VjI1OC4zOTJWNTE2Ljc0OEg3NjguODQ1SDc2OC44MDlMOTIxLjQ4OCA1MTYuNzg0QzExMDkuNjIgNTE2Ljc4NCAxMTcwLjIxIDQxOC4wMyAxMTcyLjE0IDI1OC4zOTJIMTE3Mi4xOFpNOTIyLjI1MSA0MzEuMTc2SDgzNC42NjhWMjU4LjM5MlY4NS42MDg4SDkyMi4yNTFDOTQ4LjMzMyA4NS45MzY1IDEwMDIuNjggODUuNDI2OCAxMDM0LjMyIDExOS43MjlDMTA2MS40MiAxNDkuMDc4IDEwNzAuMjEgMjA1Ljc3NCAxMDcxLjM3IDI1OC4zOTJDMTA3MS4zNyAzMTguMDAyIDEwNjEuMzggMzY3LjcwNiAxMDM0LjMyIDM5Ny4wNTZDMTAwMi42OCA0MzEuMzU4IDk0OC4zMzMgNDMwLjg0OCA5MjIuMjUxIDQzMS4xNzZaIiBmaWxsPSJ3aGl0ZSIvPgo8cGF0aCBkPSJNMzU3Ny42NSAxMjYuNjQ4QzM1MjguMjEgMTI2LjY0OCAzNDg3LjIgMTUwLjc5IDM0NjIuMjEgMTk0LjYzM0MzNDYxLjA4IDE5Ni41OTkgMzQ1Ny44NSAxOTYuMzA4IDM0NTcuMDUgMTk0LjE5NkMzNDQwLjc0IDE1MC42NDUgMzQwMy45MSAxMjYuNjg0IDMzNTMuMyAxMjYuNjg0QzMzMDguOTkgMTI2LjY4NCAzMjcyLjg0IDE0Ny42OTUgMzI0OC43NiAxODcuNDk1QzMyNDcuNzggMTg5LjA5OCAzMjQ1Ljg5IDE4OS44MjYgMzI0NC4xNCAxODkuMjQzQzMyNDIuNTQgMTg4LjY5NyAzMjQxLjQ1IDE4Ny4yMDQgMzI0MS40NSAxODUuNTI5VjEzNS43NTFIMzE1My40NFY1MTguNjc5SDMyNDIuOTRWMjk2Ljg0NkMzMjQyLjk0IDI0NC4xNTUgMzI3My43NSAyMDcuMzc3IDMzMTcuODkgMjA3LjM3N0MzMzYyLjAyIDIwNy4zNzcgMzM4Ni4wNyAyNDAuMjU5IDMzODYuMDcgMjk1LjM1M1Y1MTguNjc5SDM0NzQuODVWMjgyLjM1M0MzNDc0Ljg1IDI0MS41MzMgMzUwNy4yNSAyMDcuODg3IDM1NDcuMDcgMjA3LjM3N0MzNTY2LjU0IDIwNy4wODYgMzU4Mi41MiAyMTIuODc2IDM1OTQuMjYgMjI0LjQ5MkMzNjA5LjI5IDIzOS4zNDkgMzYxNy4yMSAyNjMuODU1IDM2MTcuMjEgMjk1LjM1M1Y1MTguNjc5SDM3MDYuNzJWMjgwLjI0MUMzNzA2LjcyIDE4MS4yMzIgMzY2MC44OCAxMjYuNjg0IDM1NzcuNjUgMTI2LjY4NFYxMjYuNjQ4WiIgZmlsbD0id2hpdGUiLz4KPHBhdGggZD0iTTE0OTAuMTQgMTM2LjA3OFYxMzcuOTM1QzE0OTAuMTQgMTQ4Ljg5NiAxNDkwLjE0IDE1Ni44MzQgMTQ5MC4xNCAxNjQuNzM2VjE4NS45MjlDMTQ5MC4xNCAxODcuODk1IDE0ODguNjUgMTg5LjUzNCAxNDg2LjcyIDE4OS42MDdDMTQ4NS40MiAxODkuNjQzIDE0ODQuMjkgMTg5LjAyNCAxNDgzLjYgMTg3Ljk2OEMxNDU3LjIzIDE0Ny40NzYgMTQyMC4xNyAxMjcuODEyIDEzNzAuMzMgMTI3LjgxMkMxMjcxLjA5IDEyNy44MTIgMTIwMS43NCAyMDkuNTYxIDEyMDEuNzQgMzI2LjU5NUMxMjAxLjc0IDQ0My42MjkgMTI3MS4wOSA1MjUuMzc4IDEzNzAuMzMgNTI1LjM3OEMxNDIwLjE0IDUyNS4zNzggMTQ1Ny4xOSA1MDUuNzE1IDE0ODMuNiA0NjUuMjIzQzE0ODQuMjkgNDY0LjE2NyAxNDg1LjQyIDQ2My41MTEgMTQ4Ni43MiA0NjMuNTg0QzE0ODguNjUgNDYzLjY1NyAxNDkwLjE3IDQ2NS4yOTUgMTQ5MC4xNCA0NjcuMjYyVjQ4OC40NTVDMTQ5MC4xIDQ5Ni4zNTYgMTQ5MC4wNyA1MDQuMjk1IDE0OTAuMDcgNTE1LjI1NVY1MTcuMTEySDE1NzYuN1YzMjYuNjMyVjEzNi4xMTVIMTQ5MC4wN0wxNDkwLjE0IDEzNi4wNzhaTTE0OTEuNjMgMzI2LjU5NUMxNDkxLjYzIDMyNi44NSAxNDkxLjYzIDMyNy4wNjkgMTQ5MS42MyAzMjcuMzI0QzE0OTEuNjMgMzk4LjAwMyAxNDUwLjM2IDQ0NS40ODYgMTM4OC45MyA0NDUuNDg2QzEzMjcuNTEgNDQ1LjQ4NiAxMjg5LjIyIDM5Ni41ODMgMTI4OS4yMiAzMjYuNTk1QzEyODkuMjIgMjU2LjYwOCAxMzMwLjIzIDIwNy43MDQgMTM4OC45MyAyMDcuNzA0QzE0NDcuNjQgMjA3LjcwNCAxNDkxLjYzIDI1NS4xODggMTQ5MS42MyAzMjUuODY3QzE0OTEuNjMgMzI2LjEyMiAxNDkxLjYzIDMyNi4zNCAxNDkxLjYzIDMyNi41OTVaIiBmaWxsPSJ3aGl0ZSIvPgo8cGF0aCBkPSJNMjE0NC44OCAxMzYuMDc4VjEzNy45MzVDMjE0NC44OCAxNDguODk2IDIxNDQuODggMTU2LjgzNCAyMTQ0Ljg4IDE2NC43MzZWMTg1LjkyOUMyMTQ0Ljg4IDE4Ny44OTUgMjE0My4zOSAxODkuNTM0IDIxNDEuNDcgMTg5LjYwN0MyMTQwLjE2IDE4OS42NDMgMjEzOS4wMyAxODkuMDI0IDIxMzguMzQgMTg3Ljk2OEMyMTExLjk3IDE0Ny40NzYgMjA3NC45MiAxMjcuODEyIDIwMjUuMDggMTI3LjgxMkMxOTI1LjgzIDEyNy44MTIgMTg1Ni40OSAyMDkuNTYxIDE4NTYuNDkgMzI2LjU5NUMxODU2LjQ5IDQ0My42MjkgMTkyNS44MyA1MjUuMzc4IDIwMjUuMDggNTI1LjM3OEMyMDc0Ljg4IDUyNS4zNzggMjExMS45MyA1MDUuNzE1IDIxMzguMzQgNDY1LjIyM0MyMTM5LjAzIDQ2NC4xNjcgMjE0MC4xNiA0NjMuNTExIDIxNDEuNDcgNDYzLjU4NEMyMTQzLjM5IDQ2My42NTcgMjE0NC45MiA0NjUuMjk1IDIxNDQuODggNDY3LjI2MlY0ODguNDU1QzIxNDQuODUgNDk2LjM1NiAyMTQ0LjgxIDUwNC4yOTUgMjE0NC44MSA1MTUuMjU1VjUxNy4xMTJIMjIzMS40NVYzMjYuNjMyVjEzNi4xMTVIMjE0NC44MUwyMTQ0Ljg4IDEzNi4wNzhaTTIxNDYuMzQgMzI2LjU5NUMyMTQ2LjM0IDMyNi44NSAyMTQ2LjM0IDMyNy4wNjkgMjE0Ni4zNCAzMjcuMzI0QzIxNDYuMzQgMzk4LjAwMyAyMTA1LjA3IDQ0NS40ODYgMjA0My42NCA0NDUuNDg2QzE5ODIuMjEgNDQ1LjQ4NiAxOTQzLjkzIDM5Ni41ODMgMTk0My45MyAzMjYuNTk1QzE5NDMuOTMgMjU2LjYwOCAxOTg0Ljk0IDIwNy43MDQgMjA0My42NCAyMDcuNzA0QzIxMDIuMzQgMjA3LjcwNCAyMTQ2LjM0IDI1NS4xODggMjE0Ni4zNCAzMjUuODY3QzIxNDYuMzQgMzI2LjEyMiAyMTQ2LjM0IDMyNi4zNCAyMTQ2LjM0IDMyNi41OTVaIiBmaWxsPSJ3aGl0ZSIvPgo8L2c+CjxkZWZzPgo8Y2xpcFBhdGggaWQ9ImNsaXAwXzNfNjciPgo8cmVjdCB3aWR0aD0iNDA5NiIgaGVpZ2h0PSI1MjgiIGZpbGw9IndoaXRlIi8+CjwvY2xpcFBhdGg+CjwvZGVmcz4KPC9zdmc+Cg==" x="720" y="291" width="80" height="10"/>
            <image href="data:image/svg+xml;base64,PHN2ZyB2ZXJzaW9uPSIxLjEiIGlkPSJMYXllcl8xIiB4bWxuczp4PSJuc19leHRlbmQ7IiB4bWxuczppPSJuc19haTsiIHhtbG5zOmdyYXBoPSJuc19ncmFwaHM7IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB4PSIwcHgiIHk9IjBweCIgdmlld0JveD0iMCAwIDMyNiA4OCIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzI2IDg4OyIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSI+CiA8c3R5bGU+CiAgLnN0MHtmaWxsOndoaXRlO30KIDwvc3R5bGU+CiA8bWV0YWRhdGE+CiAgPHNmdyB4bWxucz0ibnNfc2Z3OyI+CiAgIDxzbGljZXM+CiAgIDwvc2xpY2VzPgogICA8c2xpY2VTb3VyY2VCb3VuZHMgYm90dG9tTGVmdE9yaWdpbj0idHJ1ZSIgaGVpZ2h0PSI4OCIgd2lkdGg9IjMyNiIgeD0iLTE3Ny44IiB5PSIwIj4KICAgPC9zbGljZVNvdXJjZUJvdW5kcz4KICA8L3Nmdz4KIDwvbWV0YWRhdGE+CiA8Zz4KICA8cGF0aCBjbGFzcz0ic3QwIiBkPSJNMTMuNCwwSDYuN0gwdjEzLjVoMTMuNFYweiBNMzI1LjksNzQuNWgtNi43aC02LjdWODhoMTMuNFY3NC41eiI+CiAgPC9wYXRoPgogIDxwYXRoIGNsYXNzPSJzdDAiIGQ9Ik0xMy40LDY4LjJIMFYxOS44aDYuN2g2LjdWNjguMnogTTc1LDE4LjhjOS45LDAsMTUuOCw2LjksMTUuOCwxNy45djMxLjVINzcuNVYzOS40YzAtNS4yLTIuMy04LjYtNi45LTguNgoJCWMtMy41LDAtNi42LDIuMi03LjQsNi4zdjMxLjJINDkuN1YzOS40YzAtNS4yLTIuMi04LjYtNi44LTguNmMtMy41LDAtNi43LDIuMi03LjUsNi4zdjMxLjJIMjIuMVYxOS44aDEzLjR2NAoJCWMyLjQtMyw2LjgtNS4xLDEyLjEtNS4xYzUuNywwLDEwLjMsMi42LDEyLjksNi4yQzYzLjYsMjEuNCw2OC4yLDE4LjgsNzUsMTguOHogTTExMi44LDg4SDk5LjRWMTkuOGgxMy40djRjMi4yLTIuNiw2LjktNS4xLDEyLTUuMQoJCWMxNCwwLDIxLjksMTEuNywyMS45LDI1LjNzLTgsMjUuMi0yMS45LDI1LjJjLTUuMiwwLTkuOS0yLjUtMTItNS4xVjg4eiBNMTEyLjgsNTJjMS42LDMuMyw1LjIsNS42LDksNS42YzcuMiwwLDExLjUtNS45LDExLjUtMTMuNQoJCWMwLTcuOC00LjMtMTMuNi0xMS41LTEzLjZjLTQsMC03LjQsMi40LTksNS42VjUyeiBNMTY0LjYsNDcuMWMxLDcuOSw2LjgsMTEuMiwxMy44LDExLjJjNS4zLDAsOS0xLjIsMTMuNy00LjN2MTEuMQoJCWMtNCwyLjktOS4zLDQuMy0xNS44LDQuM2MtMTQuNiwwLTI0LjctOS42LTI0LjctMjQuOWMwLTE1LjIsOS41LTI1LjcsMjIuNi0yNS43YzE0LDAsMjEuMiw5LjgsMjEuMiwyNC4xdjQuNEwxNjQuNiw0Ny4xCgkJTDE2NC42LDQ3LjF6IE0xNjUuMSwzOC40aDE4LjJjLTAuMy01LjItMy4yLTguOS04LjUtOC45QzE3MC40LDI5LjUsMTY2LjYsMzIuMywxNjUuMSwzOC40eiBNMjMxLjksMzMuMWMtMS44LTEtNC4yLTEuNi02LjctMS42CgkJYy00LjUsMC04LjIsMi40LTkuMSw2Ljh2MjkuOWgtMTMuNFYxOS44aDEzLjR2NC43YzIuMS0zLjUsNi01LjksMTAuNy01LjljMi4zLDAsNC4zLDAuNSw1LjEsMC45VjMzLjF6IE0yNTIuNyw2OC4ybC0xOC4yLTQ4LjQKCQloMTMuOWwxMS4xLDMyLjFsMTAuOC0zMi4xaDEzLjVsLTE4LjMsNDguNEgyNTIuN3ogTTMxMi43LDM4YzAtNC42LTQtNy42LTEwLjctNy42Yy00LjgsMC05LjMsMS40LTEzLjEsMy45VjIyLjcKCQljMy41LTIuMiw5LjctNCwxNi00YzEzLjMsMCwyMS4yLDYuOCwyMS4yLDE4Ljd2MzAuOGgtMTMuNHYtMi42Yy0xLjYsMS42LTYuMywzLjUtMTEuNiwzLjVjLTkuNywwLTE3LjgtNS42LTE3LjgtMTUuNwoJCWMwLTkuMiw4LjEtMTUuNCwxOC42LTE1LjRjNC4yLDAsOC44LDEuNCwxMC43LDIuOFYzOHogTTMxMi43LDUxLjVjLTEuMi0yLjYtNC43LTQuMy04LjUtNC4zYy00LjIsMC04LjUsMS44LTguNSw2CgkJYzAsNC4zLDQuMyw2LDguNSw2YzMuOCwwLDcuMy0xLjYsOC41LTQuM1Y1MS41eiI+CiAgPC9wYXRoPgogPC9nPgo8L3N2Zz4="     x="815" y="286" width="76" height="20"/>
            <image href="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAxMDkuMjEgMzYiPgogICAgICAgICAgPHBhdGggZD0iTTk4Ljk3LDIzLjY3Yy0zLjA1LDAtNS4yLTIuMzgtNS4yLTUuNTFzMi4xNS01LjUxLDUuMi01LjUxLDUuMTQsMi4zOCw1LjE0LDUuNTEtMi4xMiw1LjUxLTUuMTQsNS41MVptLS40OSwzLjI4YzIuNDYsMCw0LjU1LS45Niw1Ljg3LTIuOTcsLjI1LDEuOTUsMS42NiwyLjY2LDMuNDQsMi42NmgxLjQydi0zLjA5aC0uNjFjLTEuMDEsMC0xLjI2LS40OS0xLjI2LTEuNjRWOS42OWgtMy4yNnYyLjUxYy0xLjExLTEuNzYtMy4yLTIuODItNS42LTIuODItNC4yOCwwLTguMjEsMy41OS04LjIxLDguNzhzMy45NCw4Ljc4LDguMjEsOC43OFptLTE2Ljc5LTQuMjRjMCwyLjc4LDEuNzIsMy45MywzLjc4LDMuOTNoMy45N3YtMy4wOWgtMi44OWMtMS4yLDAtMS40NS0uNDYtMS40NS0xLjY0VjEyLjc4aDQuMzR2LTMuMDloLTQuMzRWNGgtMy40MVYyMi43MVptLTE1LjUzLDMuOTNoMy40MXYtNy4yN2gxLjE0bDUuODEsNy4yN2g0LjMxbC03LjQxLTkuMjIsNS42OS03LjczaC0zLjg0bC00LjY1LDYuNTNoLTEuMDVWNGgtMy40MVYyNi42NFptLTExLjA3LTE3LjI2Yy00Ljc3LDAtOC43LDMuNTktOC43LDguNzhzMy45NCw4Ljc4LDguNyw4Ljc4LDguNy0zLjU5LDguNy04Ljc4LTMuOTQtOC43OC04LjctOC43OFptMCwxNC4yOWMtMy4wNSwwLTUuMi0yLjM4LTUuMi01LjUxczIuMTUtNS41MSw1LjItNS41MSw1LjIsMi4zOCw1LjIsNS41MS0yLjE1LDUuNTEtNS4yLDUuNTFaIiBmaWxsPSJ3aGl0ZSI+PC9wYXRoPgogICAgICAgICAgPHBhdGggZD0iTTE5LjgsLjI2bC0uNzQsOS4xMmMtLjM1LS4wNC0uNy0uMDYtMS4wNi0uMDYtLjQ1LDAtLjg5LC4wMy0xLjMyLC4xbC0uNDItNC40MmMtLjAxLS4xNCwuMS0uMjYsLjI0LS4yNmguNzVsLS4zNi00LjQ3Yy0uMDEtLjE0LC4xLS4yNiwuMjMtLjI2aDIuNDVjLjE0LDAsLjI1LC4xMiwuMjMsLjI2aDBabS02LjE4LC40NWMtLjA0LS4xMy0uMTgtLjIxLS4zMS0uMTZsLTIuMywuODRjLS4xMywuMDUtLjE5LC4yLS4xMywuMzJsMS44Nyw0LjA4LS43MSwuMjZjLS4xMywuMDUtLjE5LC4yLS4xMywuMzJsMS45MSw0LjAxYy42OS0uMzgsMS40NC0uNjcsMi4yMy0uODVMMTMuNjMsLjcxWk03Ljk4LDMuMjVsNS4yOSw3LjQ2Yy0uNjcsLjQ0LTEuMjgsLjk2LTEuOCwxLjU2bC0zLjE3LTMuMTJjLS4xLS4xLS4wOS0uMjYsLjAxLS4zNWwuNTgtLjQ4LTMuMTUtMy4xOWMtLjEtLjEtLjA5LS4yNiwuMDItLjM1bDEuODctMS41N2MuMTEtLjA5LC4yNi0uMDcsLjM0LC4wNFpNMy41NCw3LjU3Yy0uMTEtLjA4LS4yNy0uMDQtLjM0LC4wOGwtMS4yMiwyLjEyYy0uMDcsLjEyLS4wMiwuMjcsLjEsLjMzbDQuMDYsMS45Mi0uMzgsLjY1Yy0uMDcsLjEyLS4wMiwuMjgsLjExLC4zM2w0LjA0LDEuODVjLjI5LS43NSwuNjgtMS40NSwxLjE2LTIuMDhMMy41NCw3LjU3Wk0uNTUsMTMuMzNjLjAyLS4xNCwuMTYtLjIyLC4yOS0uMTlsOC44NSwyLjMxYy0uMjMsLjc1LS4zNiwxLjU0LS4zOCwyLjM2bC00LjQzLS4zNmMtLjE0LS4wMS0uMjQtLjE0LS4yMS0uMjhsLjEzLS43NC00LjQ3LS40MmMtLjE0LS4wMS0uMjMtLjE0LS4yMS0uMjhsLjQyLTIuNDFoMFptLS4zMyw1Ljk4Yy0uMTQsLjAxLS4yMywuMTQtLjIxLC4yOGwuNDMsMi40MWMuMDIsLjE0LC4xNiwuMjIsLjI5LC4xOWw0LjM0LTEuMTMsLjEzLC43NGMuMDIsLjE0LC4xNiwuMjIsLjI5LC4xOWw0LjI4LTEuMThjLS4yNS0uNzQtLjQxLTEuNTMtLjQ1LTIuMzRMLjIxLDE5LjMxWm0xLjQyLDYuMzRjLS4wNy0uMTItLjAyLS4yNywuMS0uMzNsOC4yNi0zLjkyYy4zMSwuNzQsLjczLDEuNDMsMS4yMywyLjA1bC0zLjYyLDIuNThjLS4xMSwuMDgtLjI3LC4wNS0uMzQtLjA3bC0uMzgtLjY2LTMuNjksMi41NWMtLjExLC4wOC0uMjcsLjA0LS4zNC0uMDhsLTEuMjMtMi4xMlptMTAuMDEtMS43MmwtNi40Myw2LjUxYy0uMSwuMS0uMDksLjI2LC4wMiwuMzVsMS44OCwxLjU3Yy4xMSwuMDksLjI2LC4wNywuMzQtLjA0bDIuNi0zLjY2LC41OCwuNDljLjExLC4wOSwuMjcsLjA3LC4zNS0uMDVsMi41Mi0zLjY2Yy0uNjgtLjQyLTEuMzEtLjkzLTEuODUtMS41MVptLTEuMjcsMTAuNDVjLS4xMy0uMDUtLjE5LS4yLS4xMy0uMzJsMy44MS04LjMyYy43LC4zNiwxLjQ2LC42MywyLjI1LC43OGwtMS4xMiw0LjNjLS4wMywuMTMtLjE4LC4yMS0uMzEsLjE2bC0uNzEtLjI2LTEuMTksNC4zM2MtLjA0LC4xMy0uMTgsLjIxLS4zMSwuMTZsLTIuMy0uODRoMFptNi41Ni03Ljc1bC0uNzQsOS4xMmMtLjAxLC4xNCwuMSwuMjYsLjIzLC4yNmgyLjQ1Yy4xNCwwLC4yNS0uMTIsLjIzLS4yNmwtLjM2LTQuNDdoLjc1Yy4xNCwwLC4yNS0uMTIsLjI0LS4yNmwtLjQyLTQuNDJjLS40MywuMDctLjg3LC4xLTEuMzIsLjEtLjM2LDAtLjcxLS4wMi0xLjA2LS4wN2gwWk0yNS43NiwxLjk0Yy4wNi0uMTMsMC0uMjctLjEzLS4zMmwtMi4zLS44NGMtLjEzLS4wNS0uMjcsLjAzLS4zMSwuMTZsLTEuMTksNC4zMy0uNzEtLjI2Yy0uMTMtLjA1LS4yNywuMDMtLjMxLC4xNmwtMS4xMiw0LjNjLjgsLjE2LDEuNTUsLjQzLDIuMjUsLjc4TDI1Ljc2LDEuOTRoMFptNS4wMiwzLjYzbC02LjQzLDYuNTFjLS41NC0uNTgtMS4xNi0xLjA5LTEuODUtMS41MWwyLjUyLTMuNjZjLjA4LS4xMSwuMjQtLjE0LC4zNS0uMDVsLjU4LC40OSwyLjYtMy42NmMuMDgtLjExLC4yNC0uMTMsLjM0LS4wNGwxLjg4LDEuNTdjLjExLC4wOSwuMTEsLjI1LC4wMiwuMzVabTMuNDgsNS4xMmMuMTMtLjA2LC4xNy0uMjEsLjEtLjMzbC0xLjIzLTIuMTJjLS4wNy0uMTItLjIzLS4xNS0uMzQtLjA4bC0zLjY5LDIuNTUtLjM4LS42NWMtLjA3LS4xMi0uMjMtLjE2LS4zNC0uMDdsLTMuNjIsMi41OGMuNSwuNjIsLjkxLDEuMzEsMS4yMywyLjA1bDguMjYtMy45MlptMS4zLDMuMzJsLjQyLDIuNDFjLjAyLC4xNC0uMDcsLjI2LS4yMSwuMjhsLTkuMTEsLjg1Yy0uMDQtLjgyLS4yLTEuNi0uNDUtMi4zNGw0LjI4LTEuMThjLjEzLS4wNCwuMjcsLjA1LC4yOSwuMTlsLjEzLC43NCw0LjM0LTEuMTNjLjEzLS4wMywuMjcsLjA1LC4yOSwuMTloMFptLS40MSw4Ljg1Yy4xMywuMDMsLjI3LS4wNSwuMjktLjE5bC40Mi0yLjQxYy4wMi0uMTQtLjA3LS4yNi0uMjEtLjI4bC00LjQ3LS40MiwuMTMtLjc0Yy4wMi0uMTQtLjA3LS4yNi0uMjEtLjI4bC00LjQzLS4zNmMtLjAyLC44Mi0uMTUsMS42MS0uMzgsMi4zNmw4Ljg1LDIuMzFoMFptLTIuMzYsNS41Yy0uMDcsLjEyLS4yMywuMTUtLjM0LC4wOGwtNy41My01LjJjLjQ4LS42MywuODctMS4zMywxLjE2LTIuMDhsNC4wNCwxLjg1Yy4xMywuMDYsLjE4LC4yMSwuMTEsLjMzbC0uMzgsLjY1LDQuMDYsMS45MmMuMTIsLjA2LC4xNywuMjEsLjEsLjMzbC0xLjIyLDIuMTJoMFptLTEwLjA3LTMuMDdsNS4yOSw3LjQ2Yy4wOCwuMTEsLjI0LC4xMywuMzQsLjA0bDEuODctMS41N2MuMTEtLjA5LC4xMS0uMjUsLjAyLS4zNWwtMy4xNS0zLjE5LC41OC0uNDhjLjExLS4wOSwuMTEtLjI1LC4wMS0uMzVsLTMuMTctMy4xMmMtLjUzLC42LTEuMTMsMS4xMy0xLjgsMS41NmgwWm0tLjA1LDEwLjE2Yy0uMTMsLjA1LS4yNy0uMDMtLjMxLS4xNmwtMi40Mi04LjgyYy43OS0uMTgsMS41NC0uNDcsMi4yMy0uODVsMS45MSw0LjAxYy4wNiwuMTMsMCwuMjgtLjEzLC4zMmwtLjcxLC4yNiwxLjg3LDQuMDhjLjA2LC4xMywwLC4yNy0uMTMsLjMybC0yLjMsLjg0aDBaIiBmaWxsPSJ3aGl0ZSIgZmlsbC1ydWxlPSJldmVub2RkIj48L3BhdGg+CiAgICAgICAgPC9zdmc+"         x="910" y="284" width="72" height="24"/>
            <image href="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+CjwhLS0gR2VuZXJhdG9yOiBBZG9iZSBJbGx1c3RyYXRvciAxOS4wLjAsIFNWRyBFeHBvcnQgUGx1Zy1JbiAuIFNWRyBWZXJzaW9uOiA2LjAwIEJ1aWxkIDApICAtLT4KCjxzdmcKICAgdmVyc2lvbj0iMS4xIgogICBpZD0ibGF5ZXIiCiAgIHg9IjBweCIKICAgeT0iMHB4IgogICB2aWV3Qm94PSItMTUzIC00NiAyMjM1LjQ0NjUgNzIwIgogICB4bWw6c3BhY2U9InByZXNlcnZlIgogICBzb2RpcG9kaTpkb2NuYW1lPSJhdXRoMC1pbmMtbG9nby12ZWN0b3Iuc3ZnIgogICB3aWR0aD0iMjIzNS40NDY1IgogICBoZWlnaHQ9IjcyMCIKICAgaW5rc2NhcGU6dmVyc2lvbj0iMS4xIChjNjhlMjJjMzg3LCAyMDIxLTA1LTIzKSIKICAgeG1sbnM6aW5rc2NhcGU9Imh0dHA6Ly93d3cuaW5rc2NhcGUub3JnL25hbWVzcGFjZXMvaW5rc2NhcGUiCiAgIHhtbG5zOnNvZGlwb2RpPSJodHRwOi8vc29kaXBvZGkuc291cmNlZm9yZ2UubmV0L0RURC9zb2RpcG9kaS0wLmR0ZCIKICAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogICB4bWxuczpzdmc9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZGVmcwogICBpZD0iZGVmczExIiAvPjxzb2RpcG9kaTpuYW1lZHZpZXcKICAgaWQ9Im5hbWVkdmlldzkiCiAgIHBhZ2Vjb2xvcj0iI2ZmZmZmZiIKICAgYm9yZGVyY29sb3I9IiM2NjY2NjYiCiAgIGJvcmRlcm9wYWNpdHk9IjEuMCIKICAgaW5rc2NhcGU6cGFnZXNoYWRvdz0iMiIKICAgaW5rc2NhcGU6cGFnZW9wYWNpdHk9IjAuMCIKICAgaW5rc2NhcGU6cGFnZWNoZWNrZXJib2FyZD0iMCIKICAgc2hvd2dyaWQ9ImZhbHNlIgogICBmaXQtbWFyZ2luLXRvcD0iMCIKICAgZml0LW1hcmdpbi1sZWZ0PSIwIgogICBmaXQtbWFyZ2luLXJpZ2h0PSIwIgogICBmaXQtbWFyZ2luLWJvdHRvbT0iMCIKICAgaW5rc2NhcGU6em9vbT0iMC4zMTkwMTg0MSIKICAgaW5rc2NhcGU6Y3g9IjczNS4wNjczMSIKICAgaW5rc2NhcGU6Y3k9IjM2Mi4wNDgwOCIKICAgaW5rc2NhcGU6d2luZG93LXdpZHRoPSIxOTIwIgogICBpbmtzY2FwZTp3aW5kb3ctaGVpZ2h0PSIxMDE3IgogICBpbmtzY2FwZTp3aW5kb3cteD0iMTkxMiIKICAgaW5rc2NhcGU6d2luZG93LXk9Ii04IgogICBpbmtzY2FwZTp3aW5kb3ctbWF4aW1pemVkPSIxIgogICBpbmtzY2FwZTpjdXJyZW50LWxheWVyPSJsYXllciIgLz4KPHN0eWxlPgoJLnN0MHtmaWxsOndoaXRlO30KPC9zdHlsZT4KPHBhdGgKICAgY2xhc3M9InN0MCIKICAgZD0iTSAzNjAuMzM0ODQsNTM2LjQ4NDQ3IDI4OC4wMzY3LDMxNCA0NzcuMzUzNDcsMTc2LjQ4NDQ3IGMgNDYuNTgzODYsMTQyLjczMjkyIDAsMjc1LjAzMTA2IC0xMTcuMDE4NjMsMzYwIHogbSAxMTcuMDE4NjMsLTM2MCBMIDQwNS4wNTUzNCwtNDYgSCAxNzEuMDE4MDcgbCA3MS45MjU0NywyMjIuNDg0NDcgYyAwLDAgMjM0LjQwOTkzLDAgMjM0LjQwOTkzLDAgeiBNIDE3MS4wMTgwNywtNDYgSCAtNjMuMDE5MjAyIEwgLTEzNC45NDQ2NiwxNzYuNDg0NDcgSCA5OS4wOTI1OTUgWiBtIC0zMDYuMzM1NCwyMjIuNDg0NDcgYyAtNDYuMjExMTgsMTQyLjczMjkyIDAsMjc1LjAzMTA2IDExNy4wMTg2MjUsMzYwIEwgNTMuNjI2NzYxLDMxNCBaIG0gMTE3LjAxODYyNSwzNjAgTCAxNzEuMDE4MDcsNjc0IDM2MC4zMzQ4NCw1MzYuNDg0NDcgMTcxLjAxODA3LDM5OC45Njg5NCBaIgogICBpZD0icGF0aDQiCiAgIHN0eWxlPSJzdHJva2Utd2lkdGg6My43MjY3MSIgLz4KPHBhdGgKICAgZD0ibSA4MjQuNjgyNjcsODguOTA2ODMgYyAtMzAuMTg2MzQsMCAtNTYuNjQ1OTcsMTkuNzUxNTYgLTY1LjIxNzM5LDQ4LjgxOTg4IEwgNjU1Ljg2Mjc5LDQ5NCBoIDY4LjE5ODc2IGwgMzAuNTU5LC0xMDMuMjI5ODEgYyAwLjM3MjY4LC0xLjExODAyIDEuMTE4MDIsLTEuODYzMzYgMi4yMzYwMywtMS44NjMzNiBoIDEzNi43NzAxOSBjIDEuMTE4MDEsMCAxLjg2MzM1LDAuNzQ1MzQgMi4yMzYwMiwxLjg2MzM2IEwgOTI1LjY3NjQ2LDQ5NCBoIDY3LjgyNjA5IEwgODg5LjUyNzM5LDEzNy43MjY3MSBDIDg4MS4zMjg2MywxMDguNjU4MzkgODU0Ljg2OSw4OC45MDY4MyA4MjQuNjgyNjcsODguOTA2ODMgWiBtIDU0LjQwOTkzLDI0OC41NzE0MyBjIC0wLjM3MjY3LDAuNzQ1MzQgLTEuMTE4MDEsMC43NDUzNCAtMS44NjMzNSwwLjc0NTM0IEggNzcyLjg4MTQyIGMgLTAuNzQ1MzQsMCAtMS40OTA2OCwtMC4zNzI2NyAtMS44NjMzNSwtMC43NDUzNCAtMC4zNzI2NywtMC43NDUzNCAtMC4zNzI2NywtMS40OTA2OCAwLC0yLjIzNjAyIGwgNTEuODAxMjQsLTE3OS42MjczMyBjIDAuMzcyNjcsLTEuMTE4MDIgMS4xMTgwMiwtMS44NjMzNiAyLjIzNjAzLC0xLjg2MzM2IDEuMTE4MDEsMC4zNzI2NyAxLjQ5MDY4LDEuMTE4MDIgMS44NjMzNSwxLjg2MzM2IGwgNTIuMTczOTEsMTc5LjYyNzMzIGMgMCwwLjc0NTM0IDAsMS40OTA2OCAwLDIuMjM2MDIgeiBtIDMxNi43NzAxLC05OC43NTc3NiBoIDY1LjU5MDEgdiAyNTUuNjUyMTcgaCAtNTEuNDI4NiBsIC03LjA4MDcsLTIxLjYxNDkxIGMgLTAuMzcyNywtMC43NDUzNCAtMC43NDU0LC0xLjQ5MDY4IC0xLjQ5MDcsLTEuODYzMzUgLTAuNzQ1MywtMC4zNzI2NyAtMS40OTA3LC0wLjM3MjY3IC0yLjIzNiwwIC0yNC4yMjM2LDE4LjI2MDg3IC01My4yOTE5LDI4LjMyMjk4IC04My40NzgzLDI4LjY5NTY1IC0zNC4yODU3LDAgLTY1LjU5LC0yMC40OTY4OSAtNzkuMDA2MiwtNTIuMTczOTEgLTQuNDcyLC0xMC40MzQ3OCAtNi43MDgxLC0yMS4yNDIyNCAtNi43MDgxLC0zMi40MjIzNiBWIDIzOC43MjA1IGggNjUuNTkwMSB2IDE3Mi41NDY1OCBjIDAsMjAuNDk2OSAxNy4xNDI5LDM3LjI2NzA4IDM3LjYzOTcsMzcuMjY3MDggMjEuMjQyMywtMS4xMTgwMSA0Mi4xMTE4LC02LjcwODA3IDYwLjc0NTQsLTE2Ljc3MDE4IDAuNzQ1MywtMC4zNzI2OCAxLjQ5MDcsLTEuMTE4MDIgMS4xMTgsLTEuODYzMzYgeiBtIDU1NS4yNzk1LDc5LjAwNjIxIHYgMTc2LjY0NTk2IGggLTY1LjIxNzMgViAzMjEuNDUzNDIgYyAwLC05LjY4OTQ0IC00LjA5OTQsLTE5LjM3ODg5IC0xMS4xODAyLC0yNi4wODY5NiAtNy4wODA3LC03LjA4MDc1IC0xNi4zOTc1LC0xMC44MDc0NSAtMjYuNDU5NiwtMTAuODA3NDUgLTIxLjI0MjIsMS4xMTgwMSAtNDIuMTExOCw2LjcwODA3IC02MS4xMTgsMTYuNzcwMTggLTAuNzQ1NCwwLjM3MjY3IC0xLjExOCwxLjExODAxIC0xLjExOCwyLjIzNjAzIFYgNDk0LjM3MjY3IEggMTUyMC40NTkgViA5NC40OTY4OSBoIDY1LjU5MDEgdiAxNjAuMjQ4NDUgYyAwLDAuNzQ1MzQgMC4zNzI2LDEuODYzMzYgMS4xMTgsMi4yMzYwMyAwLjc0NTMsMC4zNzI2NyAxLjg2MzMsMC4zNzI2NyAyLjYwODcsMCAyMi43MzI5LC0xNC45MDY4NCA0OS4xOTI1LC0yMy4xMDU1OSA3Ni4wMjQ4LC0yMy40NzgyNiA0Ni41ODM5LDAuMzcyNjcgODQuMjIzNiwzNy42Mzk3NSA4NC41OTYzLDg0LjIyMzYgeiBtIC0zMzMuOTEzLC03OS4wMDYyMSBoIDM5Ljg3NTggdiA1MC42ODMyMyBoIC0zOS44NzU4IGMgLTAuNzQ1MywwIC0xLjExOCwwLjM3MjY3IC0xLjg2MzQsMC43NDUzNCAtMC4zNzI2LDAuMzcyNjcgLTAuNzQ1MywxLjExODAxIC0wLjc0NTMsMS44NjMzNSB2IDEzNy4xNDI4NiBjIDAsMTAuODA3NDUgOC45NDQxLDE5Ljc1MTU1IDIwLjEyNDIsMTkuNzUxNTUgMCwwIDAsMCAwLDAgNS45NjI4LDAgMTQuNTM0MiwwIDIyLjM2MDMsLTEuMTE4MDEgViA0OTQgYyAtMTMuMDQzNSwzLjcyNjcxIC0yNi40NTk3LDUuOTYyNzMgLTM5Ljg3NTgsNS41OTAwNiAtMzcuMjY3MSwwIC02Ny40NTM0LC0yOS44MTM2NiAtNjcuODI2MSwtNjcuMDgwNzQgViAyOTEuNjM5NzUgYyAwLC0xLjQ5MDY4IC0xLjExOCwtMi4yMzYwMiAtMi42MDg3LC0yLjYwODY5IGggLTM5LjEzMDQgdiAtNTAuNjgzMjMgaCAzOS44NzU4IGMgMS40OTA2LDAgMi4yMzYsLTEuMTE4MDIgMi42MDg3LC0yLjYwODcgdiAtODQuMjIzNiBoIDY1LjU5IHYgODQuMjIzNiBjIC0wLjM3MjcsMS40OTA2OCAwLjM3MjcsMi42MDg3IDEuNDkwNywyLjk4MTM3IHogbSA2MjYuNDU5NiwtOTIuNzk1MDMgYyAtMjIuMzYwMiwtMzUuNDAzNzMgLTYxLjExOCwtNTYuNjQ1OTcgLTEwMi44NTcxLC01Ni42NDU5NyAtNDEuNzM5MSwwIC04MC40OTY5LDIxLjI0MjI0IC0xMDIuODU3Miw1Ni42NDU5NyAtMjQuOTY4OSwzNi41MjE3MyAtMzguMzg1MSw4Ny45NTAzMSAtMzguMzg1MSwxNDguNjk1NjUgLTIuMjM2LDUyLjU0NjU4IDExLjU1MjgsMTA0LjM0NzgyIDM4Ljc1NzgsMTQ5LjA2ODMyIDIyLjM2MDMsMzUuNDAzNzMgNjEuMTE4LDU2LjY0NTk2IDEwMi44NTcyLDU2LjY0NTk2IDQxLjczOTEsMCA4MC40OTY5LC0yMS4yNDIyMyAxMDIuODU3MSwtNTYuNjQ1OTYgMjUuMzQxNiwtMzYuODk0NDEgMzguMzg1MSwtODguMzIyOTggMzguMzg1MSwtMTQ4LjY5NTY1IDAsLTYwLjM3MjY3IC0xMy40MTYyLC0xMTIuNTQ2NTkgLTM4LjM4NTEsLTE0OS4wNjgzMiB6IG0gLTUzLjY2NDYsMjY4LjY5NTY1IGMgLTEyLjY3MDgsMjMuMTA1NTkgLTI4LjY5NTYsMzQuMjg1NzEgLTQ4LjgxOTgsMzQuMjg1NzEgLTE5Ljc1MTYsMCAtMzUuNzc2NCwtMTEuOTI1NDYgLTQ4LjgxOTksLTM0LjI4NTcxIC0xNy4xNDI5LC0zNy42Mzk3NSAtMjUuMzQxNiwtNzguNjMzNTQgLTIzLjQ3ODMsLTEyMCAtMS44NjMzLC00MS4zNjY0NiA2LjMzNTQsLTgyLjczMjkyIDIzLjQ3ODMsLTEyMC43NDUzNCAxMi42NzA4LC0yMy4xMDU1OSAyOC42OTU2LC0zNC4yODU3MiA0OC40NDcyLC0zNC4yODU3MiAxOS43NTE1LDAgMzYuMTQ5MSwxMS4xODAxMyA0OC44MTk5LDM0LjI4NTcyIDE3LjE0MjgsMzcuNjM5NzUgMjUuMzQxNiw3OC42MzM1NCAyMy40NzgyLDEyMCAyLjIzNiw0MS43MzkxMyAtNS41OSw4My4xMDU1OSAtMjMuMTA1NiwxMjAuNzQ1MzQgeiIKICAgaWQ9InBhdGg2IgogICBzdHlsZT0ic3Ryb2tlLXdpZHRoOjMuNzI2NzEiIC8+Cjwvc3ZnPgo="            x="1005" y="285" width="72" height="23"/>
            <image href="data:image/svg+xml;base64,PHN2ZyBhcmlhLWhpZGRlbj0idHJ1ZSIgZmlsbD0ibm9uZSIgaGVpZ2h0PSIyNCIgc3R5bGU9Im1hcmdpbi1ib3R0b206MHJlbSIgdmlld0JveD0iMCAwIDEyMyAyNCIgd2lkdGg9IjEyMyIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik05LjM0MzA0IDEzLjE0MjhIMC4yMDAxOTVDMC43NzU2OTEgMTkuMjM0MiA1LjkwNDUyIDI0IDEyLjE0NjUgMjRDMTMuNzY1MSAyNCAxNS4zMDg5IDIzLjY3OTUgMTYuNzE3OSAyMy4wOTg1QzEyLjY5MzUgMjEuNDM5MSA5Ljc2OTMgMTcuNjU0NiA5LjM0MzA0IDEzLjE0MjhaIiBmaWxsPSJ3aGl0ZSIgZmlsbC1ydWxlPSJldmVub2RkIj48L3BhdGg+PHBhdGggZD0iTTkuMzQzMDQgMTAuODU3MUM5Ljc2OTMgNi4zNDU0IDEyLjY5MzUgMi41NjA4NyAxNi43MTc5IDAuOTAxNDU5QzE1LjMwODkgMC4zMjA0ODQgMTMuNzY1MSAwIDEyLjE0NjUgMEM1LjkwNDUyIDAgMC43NzU2OTEgNC43NjU3OSAwLjIwMDE5NSAxMC44NTcxSDkuMzQzMDRaIiBmaWxsPSJ3aGl0ZSI+PC9wYXRoPjxwYXRoIGNsaXAtcnVsZT0iZXZlbm9kZCIgZD0iTTE0LjY2MTUgMTQuODU3MkMxMy43NDc0IDE4LjU5OTggMTEuMDc4IDIxLjY1NDIgNy41NzUyIDIzLjA5ODZDOC45ODQxNSAyMy42Nzk1IDEwLjUyOCAyNCAxMi4xNDY2IDI0QzE3Ljc4OTQgMjQgMjIuNTIyNiAyMC4xMDUyIDIzLjgwNDQgMTQuODU3MkgxNC42NjE1WiIgZmlsbD0id2hpdGUiIGZpbGwtcnVsZT0iZXZlbm9kZCI+PC9wYXRoPjxwYXRoIGQ9Ik0yMy43ODY4IDkuMTQyODZIMTQuNjQ0QzEzLjcyOTkgNS40MDAyNSAxMS4wNjA1IDIuMzQ1ODMgNy41NTc2MiAwLjkwMTQ1OUM4Ljk2NjU4IDAuMzIwNDgzIDEwLjUxMDQgMCAxMi4xMjkgMEMxNy43NzE5IDAgMjIuNTA1IDMuODk0ODQgMjMuNzg2OCA5LjE0Mjg2WiIgZmlsbD0id2hpdGUiPjwvcGF0aD48cGF0aCBkPSJNNDYuMDk2NCA5LjgwODc3QzQ1LjY5MTMgNi40NDk0IDQzLjE0NzQgNC41MTc1OCAzOS43NzkxIDQuNTE3NThDMzUuOTM0OCA0LjUxNzU4IDMzIDcuMjMwNjUgMzMgMTEuOTg5MkMzMyAxNi43MzM1IDM1Ljg4NSAxOS40NjA4IDM5Ljc3OTEgMTkuNDYwOEM0My41MDk4IDE5LjQ2MDggNDUuNzYyNCAxNi45ODIxIDQ2LjA5NjQgMTQuMzA0NUw0Mi45ODQgMTQuMjkwM0M0Mi42OTI2IDE1Ljg0NTcgNDEuNDcwNCAxNi43NDA2IDM5LjgyODkgMTYuNzQwNkMzNy42MTg5IDE2Ljc0MDYgMzYuMTE5NSAxNS4xIDM2LjExOTUgMTEuOTg5MkMzNi4xMTk1IDguOTYzNiAzNy41OTc2IDcuMjM3NzUgMzkuODUwMiA3LjIzNzc1QzQxLjUzNDMgNy4yMzc3NSA0Mi43NDk1IDguMjEwNzYgNDIuOTg0IDkuODA4NzdINDYuMDk2NFoiIGZpbGw9ImN1cnJlbnRDb2xvciI+PC9wYXRoPjxwYXRoIGQ9Ik01Mi4yMTAxIDE5LjQ3NUM1NC45MTA0IDE5LjQ3NSA1Ni43Mjk1IDE4LjE2MSA1Ny4xNTU5IDE2LjEzNjlMNTQuMzU2MSAxNS45NTIyQzU0LjA1MDYgMTYuNzgzMiA1My4yNjg5IDE3LjIxNjQgNTIuMjU5OSAxNy4yMTY0QzUwLjc0NjMgMTcuMjE2NCA0OS43ODcgMTYuMjE1IDQ5Ljc4NyAxNC41ODg2VjE0LjU4MTVINTcuMjE5OFYxMy43NTA1QzU3LjIxOTggMTAuMDQzMSA1NC45NzQzIDguMjEwNzYgNTIuMDg5MyA4LjIxMDc2QzQ4Ljg3NzQgOC4yMTA3NiA0Ni43OTUzIDEwLjQ5MDYgNDYuNzk1MyAxMy44NTcxQzQ2Ljc5NTMgMTcuMzE1OSA0OC44NDkgMTkuNDc1IDUyLjIxMDEgMTkuNDc1Wk00OS43ODcgMTIuNzA2NUM0OS44NTA5IDExLjQ2MzYgNTAuNzk2IDEwLjQ2OTMgNTIuMTM5IDEwLjQ2OTNDNTMuNDUzNyAxMC40NjkzIDU0LjM2MzIgMTEuNDA2OCA1NC4zNzAzIDEyLjcwNjVINDkuNzg3WiIgZmlsbD0iY3VycmVudENvbG9yIj48L3BhdGg+PHBhdGggZD0iTTY4LjUyMDMgMjMuMzUyOFY4LjM1MjgxSDY1LjUzNThWMTAuMTg1Mkg2NS40MDA4QzY0Ljk5NTcgOS4yOTc0MSA2NC4xMjE3IDguMjEwNzYgNjIuMjk1NSA4LjIxMDc2QzU5LjkwMDcgOC4yMTA3NiA1Ny44NzU1IDEwLjA3MTYgNTcuODc1NSAxMy44MjE2QzU3Ljg3NTUgMTcuNDcyMSA1OS44MTU1IDE5LjQzOTUgNjIuMzAyNiAxOS40Mzk1QzY0LjA2NDggMTkuNDM5NSA2NC45ODE1IDE4LjQyMzggNjUuNDAwOCAxNy41MTQ3SDY1LjQ5MzJWMjMuMzUyOEg2OC41MjAzWk02NS41NTcxIDEzLjgwNzRDNjUuNTU3MSAxNS43NTM0IDY0LjcxODYgMTcuMDMxOCA2My4yNjE5IDE3LjAzMThDNjEuNzc2NyAxNy4wMzE4IDYwLjk2NjYgMTUuNzEwOCA2MC45NjY2IDEzLjgwNzRDNjAuOTY2NiAxMS45MTgxIDYxLjc2MjUgMTAuNjE4NCA2My4yNjE5IDEwLjYxODRDNjQuNzMyOCAxMC42MTg0IDY1LjU1NzEgMTEuODYxMyA2NS41NTcxIDEzLjgwNzRaIiBmaWxsPSJjdXJyZW50Q29sb3IiPjwvcGF0aD48cGF0aCBkPSJNNzYuNTA0IDE0LjYxN0M3Ni41MTEyIDE2LjA4MDEgNzUuNTA5MiAxNi44NDcxIDc0LjQyMiAxNi44NDcxQzczLjI3NzkgMTYuODQ3MSA3Mi41Mzg5IDE2LjA0NDYgNzIuNTMxOCAxNC43NTkxVjguMzUyODFINjkuNTA0NlYxNS4yOTg4QzY5LjUxMTcgMTcuODQ4NSA3MS4wMDQgMTkuNDAzOSA3My4xOTk4IDE5LjQwMzlDNzQuODQxMiAxOS40MDM5IDc2LjAyMDggMTguNTU4OCA3Ni41MTEyIDE3LjI4MDRINzYuNjI0OVYxOS4yNjE5SDc5LjUzMTJWOC4zNTI4MUg3Ni41MDRWMTQuNjE3WiIgZmlsbD0iY3VycmVudENvbG9yIj48L3BhdGg+PHBhdGggZD0iTTg1LjYzMDkgMTkuNDc1Qzg4LjMzMTIgMTkuNDc1IDkwLjE1MDMgMTguMTYxIDkwLjU3NjcgMTYuMTM2OUw4Ny43NzY5IDE1Ljk1MjJDODcuNDcxMyAxNi43ODMyIDg2LjY4OTcgMTcuMjE2NCA4NS42ODA2IDE3LjIxNjRDODQuMTY3IDE3LjIxNjQgODMuMjA3NyAxNi4yMTUgODMuMjA3NyAxNC41ODg2VjE0LjU4MTVIOTAuNjQwNlYxMy43NTA1QzkwLjY0MDYgMTAuMDQzMSA4OC4zOTUxIDguMjEwNzYgODUuNTEwMSA4LjIxMDc2QzgyLjI5ODIgOC4yMTA3NiA4MC4yMTYxIDEwLjQ5MDYgODAuMjE2MSAxMy44NTcxQzgwLjIxNjEgMTcuMzE1OSA4Mi4yNjk3IDE5LjQ3NSA4NS42MzA5IDE5LjQ3NVpNODMuMjA3NyAxMi43MDY1QzgzLjI3MTcgMTEuNDYzNiA4NC4yMTY4IDEwLjQ2OTMgODUuNTU5OCAxMC40NjkzQzg2Ljg3NDQgMTAuNDY5MyA4Ny43ODQgMTEuNDA2OCA4Ny43OTExIDEyLjcwNjVIODMuMjA3N1oiIGZpbGw9ImN1cnJlbnRDb2xvciI+PC9wYXRoPjxwYXRoIGQ9Ik05NC40NDI2IDEyLjk1NTFDOTQuNDQ5NyAxMS41NDg4IDk1LjI4ODIgMTAuNzI1IDk2LjUxMDUgMTAuNzI1Qzk3LjcyNTYgMTAuNzI1IDk4LjQ1NzUgMTEuNTIwNCA5OC40NTA0IDEyLjg1NTZWMTkuMjYxOUgxMDEuNDc4VjEyLjMxNTlDMTAxLjQ3OCA5Ljc3MzI2IDk5Ljk4NTMgOC4yMTA3NiA5Ny43MTE0IDguMjEwNzZDOTYuMDkxMiA4LjIxMDc2IDk0LjkxODcgOS4wMDYyMSA5NC40Mjg0IDEwLjI3NzVIOTQuMzAwNVY4LjM1MjgxSDkxLjQxNTVWMTkuMjYxOUg5NC40NDI2VjEyLjk1NTFaIiBmaWxsPSJjdXJyZW50Q29sb3IiPjwvcGF0aD48cGF0aCBkPSJNMTA3LjQwNCAxOS40NzVDMTEwLjMxIDE5LjQ3NSAxMTIuMTM2IDE3Ljc3MDQgMTEyLjI3OSAxNS4yNjMzSDEwOS40MjJDMTA5LjI0NCAxNi40MjgxIDEwOC40NzcgMTcuMDgxNSAxMDcuNDM5IDE3LjA4MTVDMTA2LjAyNSAxNy4wODE1IDEwNS4xMDkgMTUuODk1NCAxMDUuMTA5IDEzLjgwNzRDMTA1LjEwOSAxMS43NDc3IDEwNi4wMzIgMTAuNTY4NyAxMDcuNDM5IDEwLjU2ODdDMTA4LjU0OCAxMC41Njg3IDEwOS4yNTggMTEuMzAwMiAxMDkuNDIyIDEyLjM4NjlIMTEyLjI3OUMxMTIuMTUxIDkuODY1NTkgMTEwLjIzOSA4LjIxMDc2IDEwNy4zOSA4LjIxMDc2QzEwNC4wNzggOC4yMTA3NiAxMDIuMDMyIDEwLjUwNDggMTAyLjAzMiAxMy44NUMxMDIuMDMyIDE3LjE2NjcgMTA0LjA0MyAxOS40NzUgMTA3LjQwNCAxOS40NzVaIiBmaWxsPSJjdXJyZW50Q29sb3IiPjwvcGF0aD48cGF0aCBkPSJNMTE3Ljk5IDE5LjQ3NUMxMjAuNjkxIDE5LjQ3NSAxMjIuNTEgMTguMTYxIDEyMi45MzYgMTYuMTM2OUwxMjAuMTM2IDE1Ljk1MjJDMTE5LjgzMSAxNi43ODMyIDExOS4wNDkgMTcuMjE2NCAxMTguMDQgMTcuMjE2NEMxMTYuNTI2IDE3LjIxNjQgMTE1LjU2NyAxNi4yMTUgMTE1LjU2NyAxNC41ODg2VjE0LjU4MTVIMTIzVjEzLjc1MDVDMTIzIDEwLjA0MzEgMTIwLjc1NCA4LjIxMDc2IDExNy44NjkgOC4yMTA3NkMxMTQuNjU4IDguMjEwNzYgMTEyLjU3NSAxMC40OTA2IDExMi41NzUgMTMuODU3MUMxMTIuNTc1IDE3LjMxNTkgMTE0LjYyOSAxOS40NzUgMTE3Ljk5IDE5LjQ3NVpNMTE1LjU2NyAxMi43MDY1QzExNS42MzEgMTEuNDYzNiAxMTYuNTc2IDEwLjQ2OTMgMTE3LjkxOSAxMC40NjkzQzExOS4yMzQgMTAuNDY5MyAxMjAuMTQzIDExLjQwNjggMTIwLjE1IDEyLjcwNjVIMTE1LjU2N1oiIGZpbGw9ImN1cnJlbnRDb2xvciI+PC9wYXRoPjxkZWZzPjxsaW5lYXJHcmFkaWVudCBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSIgaWQ9InBhaW50MF9saW5lYXIiIHgxPSI4LjQ5MjE5IiB4Mj0iOC40OTIxOSIgeTE9IjEzLjE0MjgiIHkyPSIyNCI+PHN0b3Agc3RvcC1jb2xvcj0iIzI5NzlGRiI+PC9zdG9wPjxzdG9wIG9mZnNldD0iMSIgc3RvcC1jb2xvcj0iIzQ0OEFGRiI+PC9zdG9wPjwvbGluZWFyR3JhZGllbnQ+PGxpbmVhckdyYWRpZW50IGdyYWRpZW50VW5pdHM9InVzZXJTcGFjZU9uVXNlIiBpZD0icGFpbnQxX2xpbmVhciIgeDE9IjE1LjY1MTciIHgyPSIxNS42NTE3IiB5MT0iMTQuODU3MiIgeTI9IjI0Ij48c3RvcCBzdG9wLWNvbG9yPSIjNDQ4QUZGIj48L3N0b3A+PHN0b3Agb2Zmc2V0PSIxIiBzdG9wLWNvbG9yPSIjMjk3OUZGIj48L3N0b3A+PC9saW5lYXJHcmFkaWVudD48L2RlZnM+PC9zdmc+"    x="1100" y="289" width="76" height="15"/>
            <animateTransform attributeName="transform" type="translate" from="0 0" to="-570 0" dur="22s" repeatCount="indefinite"/>
          </g>
        </g>

        <!-- Security → 3 destinations: straight vertical arrows from bar bottom -->
        <line class="kf2" x1="80"  y1="336" x2="80"  y2="402" stroke="rgba(255,255,255,0.55)" stroke-width="1.8" marker-end="url(#ah)"/>
        <rect x="60"  y="357" width="40" height="18" rx="9" fill="rgba(201,60,9,0.95)"/>
        <text x="80"  y="370" text-anchor="middle" fill="white" font-size="10" font-family="Inter,sans-serif" font-weight="600" letter-spacing="0.8">KYA</text>

        <line class="kf3" x1="240" y1="336" x2="240" y2="402" stroke="rgba(255,255,255,0.55)" stroke-width="1.8" marker-end="url(#ah)"/>
        <rect x="220" y="357" width="40" height="18" rx="9" fill="rgba(201,60,9,0.95)"/>
        <text x="240" y="370" text-anchor="middle" fill="white" font-size="10" font-family="Inter,sans-serif" font-weight="600" letter-spacing="0.8">KYA</text>

        <line class="kf4" x1="400" y1="336" x2="400" y2="402" stroke="rgba(255,255,255,0.55)" stroke-width="1.8" marker-end="url(#ah)"/>
        <rect x="380" y="357" width="40" height="18" rx="9" fill="rgba(201,60,9,0.95)"/>
        <text x="400" y="370" text-anchor="middle" fill="white" font-size="10" font-family="Inter,sans-serif" font-weight="600" letter-spacing="0.8">KYA</text>

        <!-- Websites box (bottom-left) -->
        <rect class="dest-node" x="20" y="404" width="120" height="80" rx="14" fill="url(#dest-grad)" stroke="rgba(255,255,255,0.32)" stroke-width="1.8"/>
        <g transform="translate(67.000 449.000) scale(0.02708)"><path d="M324-111.5Q251-143 197-197t-85.5-127Q80-397 80-480t31.5-156Q143-709 197-763t127-85.5Q397-880 480-880t156 31.5Q709-817 763-763t85.5 127Q880-563 880-480t-31.5 156Q817-251 763-197t-127 85.5Q563-80 480-80t-156-31.5ZM440-162v-78q-33 0-56.5-23.5T360-320v-40L168-552q-3 18-5.5 36t-2.5 36q0 121 79.5 212T440-162Zm276-102q41-45 62.5-100.5T800-480q0-98-54.5-179T600-776v16q0 33-23.5 56.5T520-680h-80v80q0 17-11.5 28.5T400-560h-80v80h240q17 0 28.5 11.5T600-440v120h40q26 0 47 15.5t29 40.5Z" fill="rgba(255,255,255,0.92)"/></g>
        <text x="80" y="468" text-anchor="middle" fill="white" font-size="14" font-family="Geist,Inter,sans-serif" font-weight="500" letter-spacing="-0.3">Websites</text>

        <!-- Login box (bottom-center) -->
        <rect class="dest-node" style="animation-delay:1.4s" x="180" y="404" width="120" height="80" rx="14" fill="url(#dest-grad)" stroke="rgba(255,255,255,0.32)" stroke-width="1.8"/>
        <g transform="translate(227.000 449.000) scale(0.02708)"><path d="M223.5-423.5Q200-447 200-480t23.5-56.5Q247-560 280-560t56.5 23.5Q360-513 360-480t-23.5 56.5Q313-400 280-400t-56.5-23.5ZM280-240q-100 0-170-70T40-480q0-100 70-170t170-70q67 0 121.5 33t86.5 87h352l120 120-180 180-80-60-80 60-85-60h-47q-32 54-86.5 87T280-240Zm0-80q56 0 98.5-34t56.5-86h125l58 41 82-61 71 55 75-75-40-40H435q-14-52-56.5-86T280-640q-66 0-113 47t-47 113q0 66 47 113t113 47Z" fill="rgba(255,255,255,0.92)"/></g>
        <text x="240" y="468" text-anchor="middle" fill="white" font-size="14" font-family="Geist,Inter,sans-serif" font-weight="500" letter-spacing="-0.3">Login</text>

        <!-- Checkout box (bottom-right) -->
        <rect class="dest-node" style="animation-delay:2.8s" x="340" y="404" width="120" height="80" rx="14" fill="url(#dest-grad)" stroke="rgba(255,255,255,0.32)" stroke-width="1.8"/>
        <g transform="translate(387.000 449.000) scale(0.02708)"><path d="M223.5-103.5Q200-127 200-160t23.5-56.5Q247-240 280-240t56.5 23.5Q360-193 360-160t-23.5 56.5Q313-80 280-80t-56.5-23.5Zm400 0Q600-127 600-160t23.5-56.5Q647-240 680-240t56.5 23.5Q760-193 760-160t-23.5 56.5Q713-80 680-80t-56.5-23.5ZM246-720l96 200h280l110-200H246Zm-38-80h590q23 0 35 20.5t1 41.5L692-482q-11 20-29.5 31T622-440H324l-44 80h480v80H280q-45 0-68-39.5t-2-78.5l54-98-144-304H40v-80h130l38 80Zm134 280h280-280Z" fill="rgba(255,255,255,0.92)"/></g>
        <text x="400" y="468" text-anchor="middle" fill="white" font-size="14" font-family="Geist,Inter,sans-serif" font-weight="500" letter-spacing="-0.3">Checkout</text>
      </svg>
    </div>
  </div>
</header>

<!-- ============ TWO CARDS ============ -->
<section class="section cards-section" id="products">
  <div class="wrap">
    <div class="section-head reveal">
      <div class="eyebrow">What KYA Powers</div>
      <h2>One token, two surfaces.</h2>
      <p class="lede">
        An extensible identity token accepted by the majority of the commercial internet, enabling the entire agentic customer journey from access to login to checkout.
      </p>
    </div>

    <div class="two-cards reveal">
      <article class="card card-rust">
        <div class="card-tag">KYA · Access</div>
        <div class="card-icon" aria-hidden="true">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="9" cy="14" r="4"/>
            <path d="M12.5 11 L21 2.5"/>
            <path d="M17 6.5 L19.5 9"/>
            <path d="M14 9.5 L16.5 12"/>
          </svg>
        </div>
        <h3>Access &amp; Login</h3>
        <p>A portable, verified identity token accepted by the majority of the commercial internet. KYA is designed to give your agent programmatic access and log-in capabilities to websites, applications and agent protocols with little engineering effort.</p>
        <div class="chips chips-ticker">
          <div class="chips-track"><span class="chip">Experian</span><span class="chip">Akamai</span><span class="chip">DataDome</span><span class="chip">Okta</span><span class="chip">Auth0</span><span class="chip">Ory</span><span class="chip">Apify</span><span class="chip">Rye</span><span class="chip">Sequentum</span><span class="chip">Cequence</span><span class="chip">f5</span><span class="chip">Forter</span><span class="chip">Consumer Reports</span><span class="chip">Getty Images</span><span class="chip">Fastly</span><span class="chip">Agntcy</span><span class="chip">Fetch.ai</span><span class="chip">Linkup</span><span class="chip">BuildShip</span><span class="chip">Imperva</span><span class="chip">NeuroID</span><span class="chip">Reuters</span><span class="chip">Blackhawk Networks</span><span class="chip">Mastercard</span><span class="chip">Experian</span><span class="chip">Akamai</span><span class="chip">DataDome</span><span class="chip">Okta</span><span class="chip">Auth0</span><span class="chip">Ory</span><span class="chip">Apify</span><span class="chip">Rye</span><span class="chip">Sequentum</span><span class="chip">Cequence</span><span class="chip">f5</span><span class="chip">Forter</span><span class="chip">Consumer Reports</span><span class="chip">Getty Images</span><span class="chip">Fastly</span><span class="chip">Agntcy</span><span class="chip">Fetch.ai</span><span class="chip">Linkup</span><span class="chip">BuildShip</span><span class="chip">Imperva</span><span class="chip">NeuroID</span><span class="chip">Reuters</span><span class="chip">Blackhawk Networks</span><span class="chip">Mastercard</span></div>
        </div>
        <a class="card-link" href="https://docs.skyfire.xyz/docs/kya-token" target="_blank" rel="noopener">Learn more about KYA →</a>
      </article>

      <article class="card card-forest">
        <div class="card-tag">Agentic Commerce</div>
        <div class="card-icon" aria-hidden="true">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
            <rect x="3" y="6" width="18" height="13" rx="2"/>
            <path d="M3 10 H21"/>
            <path d="M7 15 H10"/>
          </svg>
        </div>
        <h3>Checkout &amp; Payments</h3>
        <p>A complete agentic commerce wallet that allows your agents to securely complete checkouts via websites and emerging agentic protocols. Skyfire partners will all major credit card networks to allow tokenized card transactions and user mandate collection so agents can reliably checkout out at the scale of the internet.</p>
        <div class="chips chips--single-line">
          <span class="chip">Visa</span><span class="chip">Mastercard</span><span class="chip">Discover</span><span class="chip">USDC</span>
        </div>
        <a class="card-link" href="https://skyfire.xyz/use-case/">Learn more about Checkout &amp; Payments →</a>
      </article>
    </div>

    <div class="cards-cta reveal">
      <a class="btn btn--secondary" href="https://skyfire.xyz/use-case/">
        See Use Cases <span class="arr">→</span>
      </a>
    </div>
  </div>
</section>

<!-- ============ COVERAGE BAND ============ -->
<section class="coverage" id="coverage">
  <div class="wrap">
    <h2 class="reveal">
      Covering more than <span class="pct">60%</span> of the Web.
    </h2>
    <p class="sub reveal">Powering agentic commerce through leading infrastructure partners</p>
    <div class="coverage-logos reveal">
      <span class="cov-logo" data-h="28" aria-label="Akamai"><svg xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="svg834" xml:space="preserve" viewBox="0 0 409.33292 166.75058" ><defs id="defs838"><clipPath clipPathUnits="userSpaceOnUse" id="clipPath852"><path d="M 0,0 H 612 V 792 H 0 Z" id="path850" /></clipPath><clipPath clipPathUnits="userSpaceOnUse" id="clipPath860"><path d="m -749.369,-45.4393 h 2 v -58.7847 h -2 z" id="path858" /></clipPath><clipPath clipPathUnits="userSpaceOnUse" id="clipPath1256"><path d="M 36,391.52 H 304.229 V 271.475 H 36 Z" id="path1254" /></clipPath><clipPath clipPathUnits="userSpaceOnUse" id="clipPath1368"><path d="M 0,0 H 612 V 792 H 0 Z" id="path1366" /></clipPath><clipPath clipPathUnits="userSpaceOnUse" id="clipPath1396"><path d="M 0,0 H 612 V 792 H 0 Z" id="path1394" /></clipPath><clipPath clipPathUnits="userSpaceOnUse" id="clipPath1432"><path d="M 0,0 H 612 V 792 H 0 Z" id="path1430" /></clipPath></defs><g id="g842" transform="matrix(1.3333333,0,0,-1.3333333,-237.09597,1002.4343)"><g id="g1518" transform="matrix(4.2054927,0,0,4.2054927,-1937.8449,-2419.1027)"><g id="g1392" clip-path="url(#clipPath1396)" style="fill:currentColor" /><g id="g1557"><g style="fill:currentColor;fill-opacity:1" transform="translate(518.1763,724.9189)" id="g1402"><path id="path1404" style="fill:currentColor;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 0,0 c -6.127,1.862 -10.58,7.517 -10.58,14.209 0,6.763 4.548,12.465 10.768,14.279 0.637,0.189 0.472,0.59 -0.306,0.59 -8.271,0 -14.986,-6.669 -14.986,-14.869 0,-8.2 6.715,-14.869 14.986,-14.869 C 0.66,-0.66 0.707,-0.212 0,0" /></g><g style="fill:currentColor" transform="translate(510.4474,735.6639)" id="g1406"><path id="path1408" style="fill:currentColor;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 0,0 c -0.047,0.401 -0.071,0.801 -0.071,1.202 0,6.527 5.279,11.805 11.806,11.805 6.173,0 8.011,-2.757 8.247,-2.568 0.259,0.188 -2.239,5.655 -9.473,5.655 -6.527,0 -11.805,-5.278 -11.805,-11.805 0,-1.508 0.283,-2.946 0.801,-4.265 C -0.283,-0.542 0.047,-0.542 0,0" /></g><g style="fill:currentColor;fill-opacity:1" transform="translate(515.3958,744.1704)" id="g1410"><path id="path1412" style="fill:currentColor;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 0,0 c 3.063,1.343 6.928,1.39 10.721,0.047 2.545,-0.895 4.03,-2.168 4.148,-2.097 0.212,0.094 -1.485,2.757 -4.525,3.912 C 6.668,3.252 2.71,2.521 -0.165,0.259 -0.495,0 -0.377,-0.165 0,0" /></g><g style="fill:currentColor;fill-opacity:1" transform="translate(576.072,738.6094)" id="g1414"><path id="path1416" style="fill:currentColor;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 0,0 c 0,-0.848 -0.707,-1.555 -1.555,-1.555 -0.849,0 -1.555,0.683 -1.555,1.555 0,0.848 0.683,1.555 1.555,1.555 C -0.683,1.555 0,0.872 0,0" /></g><path id="path1420" style="fill:currentColor;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 525.4574,729.9144 0.188,-2.074 h 3.276 l -1.108,12.041 h -4.877 l -6.174,-12.041 h 3.346 l 1.037,2.074 z m -0.165,2.333 h -2.993 l 2.569,5.207 h 0.023 z" /><path id="path1424" style="fill:currentColor;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 533.469,733.0956 h 0.495 l 2.333,3.181 h 3.039 l -3.228,-4.053 1.98,-4.383 h -3.229 l -1.296,3.417 h -0.471 l -0.73,-3.417 h -2.757 l 2.544,12.041 h 2.757 z" /><g style="fill:currentColor;fill-opacity:1" clip-path="url(#clipPath1432)" id="g1428"><g style="fill:currentColor;fill-opacity:1" transform="translate(543.6485,727.8408)" id="g1434"><path id="path1436" style="fill:currentColor;fill-opacity:1;fill-rule:nonzero;stroke:none" d="M 0,0 H 2.757 L 3.864,5.255 C 4.477,8.153 3.37,8.506 0.542,8.506 c -1.979,0 -3.888,0.024 -4.43,-2.591 h 2.757 c 0.165,0.754 0.636,0.918 1.32,0.918 1.201,0 1.154,-0.494 0.989,-1.272 L 0.895,4.218 H 0.778 C 0.683,5.184 -0.542,5.16 -1.32,5.16 c -2.002,0 -3.181,-0.636 -3.605,-2.662 -0.447,-2.144 0.566,-2.616 2.498,-2.616 0.966,0 2.262,0.189 2.71,1.343 H 0.377 Z M -0.778,3.487 C 0.118,3.487 0.707,3.417 0.565,2.71 0.377,1.838 0,1.673 -1.155,1.673 c -0.424,0 -1.201,0 -1.013,0.919 0.165,0.778 0.707,0.895 1.39,0.895" /></g><g style="fill:currentColor;fill-opacity:1" transform="translate(551.99,736.2766)" id="g1438"><path id="path1440" style="fill:currentColor;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 0,0 -0.259,-1.178 h 0.118 c 0.542,0.99 1.649,1.272 2.592,1.272 1.178,0 2.356,-0.212 2.191,-1.649 H 4.76 c 0.4,1.202 1.626,1.649 2.686,1.649 1.956,0 2.781,-0.801 2.356,-2.757 L 8.577,-8.436 H 5.82 l 1.037,4.878 c 0.141,0.872 0.283,1.532 -0.778,1.532 -1.084,0 -1.437,-0.707 -1.626,-1.626 L 3.44,-8.436 H 0.683 l 1.084,5.114 c 0.142,0.777 0.189,1.296 -0.777,1.296 -1.131,0 -1.485,-0.613 -1.697,-1.626 L -1.72,-8.436 H -4.477 L -2.686,0 Z" /></g><g style="fill:currentColor;fill-opacity:1" transform="translate(566.9058,727.8408)" id="g1442"><path id="path1444" style="fill:currentColor;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 0,0 h 2.757 l 1.131,5.255 c 0.613,2.898 -0.495,3.251 -3.322,3.251 -1.98,0 -3.889,0.024 -4.43,-2.591 h 2.757 c 0.164,0.754 0.636,0.918 1.319,0.918 1.202,0 1.155,-0.494 0.99,-1.272 L 0.919,4.218 H 0.801 C 0.707,5.184 -0.518,5.16 -1.296,5.16 c -2.003,0 -3.181,-0.636 -3.605,-2.662 -0.448,-2.144 0.565,-2.616 2.497,-2.616 0.967,0 2.263,0.189 2.71,1.343 H 0.401 Z M -0.754,3.487 C 0.141,3.487 0.73,3.417 0.589,2.71 0.401,1.838 0.024,1.673 -1.131,1.673 c -0.424,0 -1.202,0 -1.013,0.919 0.165,0.778 0.707,0.895 1.39,0.895" /></g></g><path id="path1448" style="fill:currentColor;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 573.6685,727.8408 h -2.757 l 1.767,8.436 h 2.781 z" /></g></g></g></svg></span>
      <span class="cov-logo" data-h="20" aria-label="DataDome"><svg viewBox="0 0 4096 528" fill="none" xmlns="http://www.w3.org/2000/svg"><g clip-path="url(#clip0_3_67)"><path d="M2934.11 124.643C2821.72 124.643 2743.22 207.557 2743.22 326.303C2743.22 445.048 2821.72 527.962 2934.11 527.962C2988.35 527.962 3037.17 507.498 3071.61 470.319C3105.57 433.651 3124.28 382.234 3124.28 325.538C3124.28 207.23 3046.07 124.607 2934.11 124.607V124.643ZM2934.11 446.905C2873.88 446.905 2831.82 397.31 2831.82 326.339C2831.82 255.369 2873.88 205.773 2934.11 205.773C2994.34 205.773 3035.68 255.041 3035.68 325.611C3035.68 396.181 2993.91 446.942 2934.11 446.942V446.905Z" fill="currentColor"/><path d="M1771.82 33.7538H1682.49V136.659H1611.84V217.753H1682.49V516.71H1771.82V217.753H1843.16V136.659H1771.82V33.7538Z" fill="currentColor"/><path d="M4049.82 177.626C4019.02 142.96 3974.08 124.644 3919.88 124.644C3810.54 124.644 3734.15 207.885 3734.15 327.068C3734.15 446.25 3810.54 527.999 3919.88 527.999C3996.31 527.999 4056.14 490.675 4088.36 422.872L4089.63 420.178L4009.06 393.705L4008.05 395.562C3989.23 429.645 3959.22 447.634 3921.33 447.634C3869.79 447.634 3830.92 410.892 3821.66 353.723H4094.32L4094.72 347.896C4095.37 338.21 4095.99 329.034 4095.99 318.838C4095.99 260.467 4080.01 211.636 4049.82 177.662V177.626ZM3824.96 283.153C3838.66 233.666 3873.93 204.244 3919.85 204.244C3968.09 204.244 3999.94 232.246 4009.79 283.153H3824.96Z" fill="currentColor"/><path d="M554.548 449.274C592.11 406.451 611.181 342.326 611.181 258.647V258.028C611.181 174.35 592.11 110.188 554.548 67.4023C516.224 23.7057 479.971 0.0367432 398.128 0.0367432H222.091C231.536 9.79564 253.44 32.4814 260.742 39.9827C264.193 43.5148 266.99 46.2458 269.133 48.3214L269.424 48.6127C270.623 49.778 271.603 50.7247 272.294 51.4894C273.057 52.2541 273.565 52.8003 273.892 53.0916C288.423 67.6936 305.351 73.5926 332.45 73.5926C333.467 73.5926 335.465 73.5926 338.226 73.5926C344.728 73.5562 357.733 73.5926 371.755 73.5926C380.655 73.5926 389.991 73.5926 398.346 73.5926C470.925 73.5926 492.612 116.342 496.354 125.227C499.986 130.325 503.002 136.079 505.326 142.342C518.44 177.372 525.161 217.536 524.797 258.429C525.161 298.593 518.44 338.685 505.326 374.261C482.477 436.31 424.464 443.011 400.562 443.011H332.45C306.331 443.011 280.867 454.954 260.742 476.62C251.115 486.998 231.681 507.463 223.035 516.566H398.019C479.934 516.566 516.224 492.897 554.548 449.237V449.274Z" fill="currentColor"/><path d="M339.105 258.399C339.105 258.399 339.105 258.399 339.105 258.362C339.105 258.362 339.105 258.362 339.105 258.326C339.105 258.326 339.105 258.326 339.105 258.289C339.759 220.237 332.458 186.7 326.609 168.311C319.417 145.625 312.297 137.068 310.044 134.191C275.208 89.1109 234.885 108.556 200.375 84.9961C165.902 61.4728 160.126 43.6301 147.848 31.1401C145.741 28.9917 141.091 24.2579 133.898 19.3056C133.898 19.3056 122.637 11.5495 106.981 6.67005C90.0164 1.31723 38.8691 -0.0664972 0 0.0427441V78.2232H115.917C129.794 77.9318 163.541 79.2427 193.292 102.73C208.839 115.001 217.049 128.365 222.099 136.704C246.001 176.395 246.728 224.643 247.2 258.217V258.399C246.728 291.972 246.001 340.22 222.099 379.911C217.086 388.25 208.839 401.65 193.292 413.886C163.504 437.372 129.794 438.683 115.917 438.392H0V516.572C38.8691 516.718 90.0164 515.298 106.981 509.981C122.637 505.066 133.898 497.346 133.898 497.346C141.091 492.394 145.741 487.66 147.848 485.511C160.126 473.021 165.902 455.215 200.375 431.655C234.849 408.132 275.208 427.577 310.044 382.46C312.297 379.584 319.417 371.026 326.609 348.341C332.421 329.952 339.759 296.415 339.105 258.362V258.399Z" fill="currentColor"/><path d="M2715.39 258.392C2713.47 98.7542 2652.88 0 2464.74 0H2312.06H2312.1L2284.16 0.0364138V258.392V516.748H2312.1H2312.06L2464.74 516.784C2652.88 516.784 2713.47 418.03 2715.39 258.392ZM2465.47 431.176H2377.89V258.392V85.6088H2465.47C2491.55 85.9365 2545.89 85.4268 2577.53 119.729C2604.63 149.078 2613.43 205.774 2614.59 258.392C2614.59 318.002 2604.6 367.706 2577.53 397.056C2545.89 431.358 2491.55 430.848 2465.47 431.176Z" fill="currentColor"/><path d="M1172.18 258.392C1170.21 98.7542 1109.66 0 921.488 0H768.809H768.845L740.91 0.0364138V258.392V516.748H768.845H768.809L921.488 516.784C1109.62 516.784 1170.21 418.03 1172.14 258.392H1172.18ZM922.251 431.176H834.668V258.392V85.6088H922.251C948.333 85.9365 1002.68 85.4268 1034.32 119.729C1061.42 149.078 1070.21 205.774 1071.37 258.392C1071.37 318.002 1061.38 367.706 1034.32 397.056C1002.68 431.358 948.333 430.848 922.251 431.176Z" fill="currentColor"/><path d="M3577.65 126.648C3528.21 126.648 3487.2 150.79 3462.21 194.633C3461.08 196.599 3457.85 196.308 3457.05 194.196C3440.74 150.645 3403.91 126.684 3353.3 126.684C3308.99 126.684 3272.84 147.695 3248.76 187.495C3247.78 189.098 3245.89 189.826 3244.14 189.243C3242.54 188.697 3241.45 187.204 3241.45 185.529V135.751H3153.44V518.679H3242.94V296.846C3242.94 244.155 3273.75 207.377 3317.89 207.377C3362.02 207.377 3386.07 240.259 3386.07 295.353V518.679H3474.85V282.353C3474.85 241.533 3507.25 207.887 3547.07 207.377C3566.54 207.086 3582.52 212.876 3594.26 224.492C3609.29 239.349 3617.21 263.855 3617.21 295.353V518.679H3706.72V280.241C3706.72 181.232 3660.88 126.684 3577.65 126.684V126.648Z" fill="currentColor"/><path d="M1490.14 136.078V137.935C1490.14 148.896 1490.14 156.834 1490.14 164.736V185.929C1490.14 187.895 1488.65 189.534 1486.72 189.607C1485.42 189.643 1484.29 189.024 1483.6 187.968C1457.23 147.476 1420.17 127.812 1370.33 127.812C1271.09 127.812 1201.74 209.561 1201.74 326.595C1201.74 443.629 1271.09 525.378 1370.33 525.378C1420.14 525.378 1457.19 505.715 1483.6 465.223C1484.29 464.167 1485.42 463.511 1486.72 463.584C1488.65 463.657 1490.17 465.295 1490.14 467.262V488.455C1490.1 496.356 1490.07 504.295 1490.07 515.255V517.112H1576.7V326.632V136.115H1490.07L1490.14 136.078ZM1491.63 326.595C1491.63 326.85 1491.63 327.069 1491.63 327.324C1491.63 398.003 1450.36 445.486 1388.93 445.486C1327.51 445.486 1289.22 396.583 1289.22 326.595C1289.22 256.608 1330.23 207.704 1388.93 207.704C1447.64 207.704 1491.63 255.188 1491.63 325.867C1491.63 326.122 1491.63 326.34 1491.63 326.595Z" fill="currentColor"/><path d="M2144.88 136.078V137.935C2144.88 148.896 2144.88 156.834 2144.88 164.736V185.929C2144.88 187.895 2143.39 189.534 2141.47 189.607C2140.16 189.643 2139.03 189.024 2138.34 187.968C2111.97 147.476 2074.92 127.812 2025.08 127.812C1925.83 127.812 1856.49 209.561 1856.49 326.595C1856.49 443.629 1925.83 525.378 2025.08 525.378C2074.88 525.378 2111.93 505.715 2138.34 465.223C2139.03 464.167 2140.16 463.511 2141.47 463.584C2143.39 463.657 2144.92 465.295 2144.88 467.262V488.455C2144.85 496.356 2144.81 504.295 2144.81 515.255V517.112H2231.45V326.632V136.115H2144.81L2144.88 136.078ZM2146.34 326.595C2146.34 326.85 2146.34 327.069 2146.34 327.324C2146.34 398.003 2105.07 445.486 2043.64 445.486C1982.21 445.486 1943.93 396.583 1943.93 326.595C1943.93 256.608 1984.94 207.704 2043.64 207.704C2102.34 207.704 2146.34 255.188 2146.34 325.867C2146.34 326.122 2146.34 326.34 2146.34 326.595Z" fill="currentColor"/></g><defs><clipPath id="clip0_3_67"><rect width="4096" height="528" fill="white"/></clipPath></defs></svg></span>
      <span class="cov-logo" data-h="22" aria-label="Cequence"><svg aria-hidden="true" fill="none" style="margin-bottom:0rem" viewBox="0 0 123 24" xmlns="http://www.w3.org/2000/svg"><path clip-rule="evenodd" d="M9.34304 13.1428H0.200195C0.775691 19.2342 5.90452 24 12.1465 24C13.7651 24 15.3089 23.6795 16.7179 23.0985C12.6935 21.4391 9.7693 17.6546 9.34304 13.1428Z" fill="currentColor" fill-rule="evenodd"></path><path d="M9.34304 10.8571C9.7693 6.3454 12.6935 2.56087 16.7179 0.901459C15.3089 0.320484 13.7651 0 12.1465 0C5.90452 0 0.775691 4.76579 0.200195 10.8571H9.34304Z" fill="currentColor"></path><path clip-rule="evenodd" d="M14.6615 14.8572C13.7474 18.5998 11.078 21.6542 7.5752 23.0986C8.98415 23.6795 10.528 24 12.1466 24C17.7894 24 22.5226 20.1052 23.8044 14.8572H14.6615Z" fill="currentColor" fill-rule="evenodd"></path><path d="M23.7868 9.14286H14.644C13.7299 5.40025 11.0605 2.34583 7.55762 0.901459C8.96658 0.320483 10.5104 0 12.129 0C17.7719 0 22.505 3.89484 23.7868 9.14286Z" fill="currentColor"></path><path d="M46.0964 9.80877C45.6913 6.4494 43.1474 4.51758 39.7791 4.51758C35.9348 4.51758 33 7.23065 33 11.9892C33 16.7335 35.885 19.4608 39.7791 19.4608C43.5098 19.4608 45.7624 16.9821 46.0964 14.3045L42.984 14.2903C42.6926 15.8457 41.4704 16.7406 39.8289 16.7406C37.6189 16.7406 36.1195 15.1 36.1195 11.9892C36.1195 8.9636 37.5976 7.23775 39.8502 7.23775C41.5343 7.23775 42.7495 8.21076 42.984 9.80877H46.0964Z" fill="currentColor"></path><path d="M52.2101 19.475C54.9104 19.475 56.7295 18.161 57.1559 16.1369L54.3561 15.9522C54.0506 16.7832 53.2689 17.2164 52.2599 17.2164C50.7463 17.2164 49.787 16.215 49.787 14.5886V14.5815H57.2198V13.7505C57.2198 10.0431 54.9743 8.21076 52.0893 8.21076C48.8774 8.21076 46.7953 10.4906 46.7953 13.8571C46.7953 17.3159 48.849 19.475 52.2101 19.475ZM49.787 12.7065C49.8509 11.4636 50.796 10.4693 52.139 10.4693C53.4537 10.4693 54.3632 11.4068 54.3703 12.7065H49.787Z" fill="currentColor"></path><path d="M68.5203 23.3528V8.35281H65.5358V10.1852H65.4008C64.9957 9.29741 64.1217 8.21076 62.2955 8.21076C59.9007 8.21076 57.8755 10.0716 57.8755 13.8216C57.8755 17.4721 59.8155 19.4395 62.3026 19.4395C64.0648 19.4395 64.9815 18.4238 65.4008 17.5147H65.4932V23.3528H68.5203ZM65.5571 13.8074C65.5571 15.7534 64.7186 17.0318 63.2619 17.0318C61.7767 17.0318 60.9666 15.7108 60.9666 13.8074C60.9666 11.9181 61.7625 10.6184 63.2619 10.6184C64.7328 10.6184 65.5571 11.8613 65.5571 13.8074Z" fill="currentColor"></path><path d="M76.504 14.617C76.5112 16.0801 75.5092 16.8471 74.422 16.8471C73.2779 16.8471 72.5389 16.0446 72.5318 14.7591V8.35281H69.5046V15.2988C69.5117 17.8485 71.004 19.4039 73.1998 19.4039C74.8412 19.4039 76.0208 18.5588 76.5112 17.2804H76.6249V19.2619H79.5312V8.35281H76.504V14.617Z" fill="currentColor"></path><path d="M85.6309 19.475C88.3312 19.475 90.1503 18.161 90.5767 16.1369L87.7769 15.9522C87.4713 16.7832 86.6897 17.2164 85.6806 17.2164C84.167 17.2164 83.2077 16.215 83.2077 14.5886V14.5815H90.6406V13.7505C90.6406 10.0431 88.3951 8.21076 85.5101 8.21076C82.2982 8.21076 80.2161 10.4906 80.2161 13.8571C80.2161 17.3159 82.2697 19.475 85.6309 19.475ZM83.2077 12.7065C83.2717 11.4636 84.2168 10.4693 85.5598 10.4693C86.8744 10.4693 87.784 11.4068 87.7911 12.7065H83.2077Z" fill="currentColor"></path><path d="M94.4426 12.9551C94.4497 11.5488 95.2882 10.725 96.5105 10.725C97.7256 10.725 98.4575 11.5204 98.4504 12.8556V19.2619H101.478V12.3159C101.478 9.77326 99.9853 8.21076 97.7114 8.21076C96.0912 8.21076 94.9187 9.00621 94.4284 10.2775H94.3005V8.35281H91.4155V19.2619H94.4426V12.9551Z" fill="currentColor"></path><path d="M107.404 19.475C110.31 19.475 112.136 17.7704 112.279 15.2633H109.422C109.244 16.4281 108.477 17.0815 107.439 17.0815C106.025 17.0815 105.109 15.8954 105.109 13.8074C105.109 11.7477 106.032 10.5687 107.439 10.5687C108.548 10.5687 109.258 11.3002 109.422 12.3869H112.279C112.151 9.86559 110.239 8.21076 107.39 8.21076C104.078 8.21076 102.032 10.5048 102.032 13.85C102.032 17.1667 104.043 19.475 107.404 19.475Z" fill="currentColor"></path><path d="M117.99 19.475C120.691 19.475 122.51 18.161 122.936 16.1369L120.136 15.9522C119.831 16.7832 119.049 17.2164 118.04 17.2164C116.526 17.2164 115.567 16.215 115.567 14.5886V14.5815H123V13.7505C123 10.0431 120.754 8.21076 117.869 8.21076C114.658 8.21076 112.575 10.4906 112.575 13.8571C112.575 17.3159 114.629 19.475 117.99 19.475ZM115.567 12.7065C115.631 11.4636 116.576 10.4693 117.919 10.4693C119.234 10.4693 120.143 11.4068 120.15 12.7065H115.567Z" fill="currentColor"></path></svg></span>
      <span class="cov-logo" data-h="32" aria-label="F5"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 1000"><title>f5-logo-black</title><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><g id="f5-logo-rgb"><g id="Logo-black-and-white"><path d="M940.37,894.53a30.85,30.85,0,0,1,9.47,22.94,32.43,32.43,0,0,1-55.4,23.08A32,32,0,0,1,885,917.47a32.54,32.54,0,0,1,32.37-32.57A30.88,30.88,0,0,1,940.37,894.53Zm3.81-3.75a36.65,36.65,0,0,0-26.8-11,37.72,37.72,0,1,0,26.8,64.32,37.71,37.71,0,0,0,0-53.36ZM923,915.65a18.8,18.8,0,0,1-6.93.92h-6.54v-15h6.23c4,0,7,.57,8.77,1.58s2.76,3.07,2.76,6A6.38,6.38,0,0,1,923,915.65Zm-20.75,22.29h7.28V921.66h5.77c3.82,0,6.56.4,8.11,1.36,2.57,1.54,3.88,4.72,3.88,9.48v3.33l.14,1.25a2.91,2.91,0,0,1,.11.5c0,.2.06.27.19.36h6.76l-.24-.48a4.42,4.42,0,0,1-.35-2.11c-.09-1.14-.09-2.15-.09-3.07v-3.07a11.52,11.52,0,0,0-2.26-6.43c-1.54-2.21-3.95-3.51-7.19-4.08a17,17,0,0,0,6-2c2.77-1.75,4.06-4.56,4.06-8.2,0-5.18-2.06-8.73-6.4-10.49-2.39-1-6.14-1.49-11.3-1.49H902.25Z"/><path d="M912.66,217.69c-6.13,25.33-9.34,51.58-15.26,78.43-75-9.73-163.08-16.86-262-20.34-7.94,25.11-15.46,49.69-24.06,76.52,165.55,10.18,246,53.81,293.72,105.22,46.41,52,56.26,109.45,53.58,162.79C952.67,707,914.45,761.79,862,802.41c-53.08,40-117.29,59.84-168.65,64.16C617.56,872.24,516.22,854.2,494.66,841c-13-29.54-25.77-59.3-39.54-91.76-3.35-6.91-5.46-14,4-22.23,14.74-14.13,28.92-27.8,43.84-42.28,6.59-6.44,13.9-12.44,19.44-3.21,20.38,31.43,39.48,60.27,58.61,89,21.73,32.05,54.83,61.26,127.14,56.4,60.79-5.44,107-51.42,111.93-102,5.32-93.6-89.38-160-335.64-181.27C531.7,401,577.75,262.93,614.59,153.2c58.5,2.7,112.65,7.47,164.38,14.15,38.26,4.87,73.81,13.78,109.46,17.9C796.77,72.26,656.88,0,500,0,223.87,0,0,223.86,0,500A497.64,497.64,0,0,0,97.31,796.3c21.18.16,35.86-4.57,37.45-13.7,1.94-9.55.31-24.33-1.36-39.24-10-98.12-13.53-204.06-9.77-310.22-25.36,1.1-48.12,2.24-69.94,3.52.88-19.63,1.94-38.23,3.52-57.59,21.55-2.07,44.38-3.88,69.46-6,1.07-16.91,2.28-33.28,3.74-49.81C141.67,222,248.29,160.08,337.1,136.18c39.41-9.6,63.51-12.63,82.43-13.62,6.84-.22,14.21-.49,21.55-.49,18.41,0,37.09,1.72,48.92,9.76,19.16,14.36,38.09,28.65,58.22,44.54,2,2.72,4.2,7-.8,14.35-9.24,10.81-18.16,21.14-27.55,32.26-5.41,6.57-14.39,4.84-21.95,2.79-15.84-8.11-31.08-15.56-46.54-23.05-28-12.46-57-25.28-89.27-24-20.13,1.61-39.62,22.21-41.64,50.39-2.79,42.88-4.66,86.84-6.24,134.46C370.18,362,426,361,484.85,360.74c0,13.39-.09,25.67-.09,39.39-19.2,8.58-37.3,17.25-56.54,26-39.7.46-77.48.77-115.53,1.43-1.76,113.29-.09,226.16,5,330.51,1,15.75,1.76,31.7,6.29,42.38,5.43,13.44,36.66,23.8,104.6,27.63.27,11.83.6,23,1,34.46-110.63-3.22-216.86-13.81-302-29.13C219.07,935.63,352,1000,500,1000c276.15,0,500-223.87,500-500A497.6,497.6,0,0,0,912.66,217.69Z"/><path class="cls-1" d="M127.51,833.43h0v0Z"/></g></g></g></g></svg></span>
      <span class="cov-logo" data-h="24" aria-label="Fastly"><svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 1709 735" style="enable-background:new 0 0 1709 735;" xml:space="preserve"><g><path d="M1135.1,129.9v405.5h121.8v-62h-40.2V68.2l-81.6,0L1135.1,129.9z"></path><path d="M77.4,473.5h41.4V277.8H77.4V224l41.4-6.8v-54.5c0-66,14.4-94.6,98.5-94.6c18.2,0,39.7,2.7,58.6,6.1l-11.2,66.3 c-12.8-2-19.1-2.4-27.2-2.4c-29.6,0-37.1,3-37.1,31.9v47.1h61.5v60.6h-61.5v195.6h41v61.9l-163.9,0L77.4,473.5L77.4,473.5z"></path><path d="M1093.6,453.9c-12.8,2.7-23.9,2.4-32,2.6c-33.6,0.8-30.7-10.2-30.7-41.8V277.8h63.9v-60.6H1031V68.2h-81.6v363.4 c0,71.3,17.6,103.9,94.3,103.9c18.2,0,43.1-4.7,62-8.7L1093.6,453.9z"></path><path d="M1600.3,473.8c17.1,0,31,13.6,31,30.8c0,17.1-13.9,30.8-31,30.8c-17.1,0-30.9-13.6-30.9-30.8 C1569.4,487.4,1583.2,473.8,1600.3,473.8 M1600.3,530.5c14.2,0,25.8-11.7,25.8-25.9c0-14.2-11.6-25.6-25.8-25.6 c-14.2,0-25.8,11.3-25.8,25.6C1574.5,518.8,1586.1,530.5,1600.3,530.5 M1606,519.7l-6.2-9.1h-4.3v9.1h-6.9v-30.2h12.7 c7.5,0,12.1,3.8,12.1,10.5c0,4.9-2.5,8.3-6.3,9.4l7.6,10.4L1606,519.7L1606,519.7z M1595.5,504.5h5.5c3.2,0,5.3-1.2,5.3-4.6 c0-3.2-2.1-4.4-5.1-4.4h-5.7L1595.5,504.5L1595.5,504.5z"></path><path d="M847.6,277.7v-10.9c-24.7-4.5-49.2-4.6-62.5-4.6c-38,0-42.6,20.1-42.6,31c0,15.4,5.3,23.8,46.4,32.8 c60.1,13.5,120.5,27.6,120.5,102.1c0,70.7-36.4,107.2-112.9,107.2c-51.2,0-101-11-138.9-20.6v-60.9h61.8l0,10.8 c26.6,5.1,54.4,4.6,69,4.6c40.5,0,47-21.8,47-33.3c0-16.1-11.6-23.8-49.6-31.5c-71.5-12.2-128.2-36.6-128.2-109.3 c0-68.7,46-95.7,122.5-95.7c51.9,0,91.3,8,129.3,17.7v60.5H847.6z"></path><path d="M472.3,331.3l-6.2-6.2l-31.5,27.5c-1.6-0.6-3.3-0.9-5.1-0.9c-8.5,0-15.4,7.1-15.4,15.8c0,8.7,6.9,15.8,15.4,15.8 c8.5,0,15.4-7.1,15.4-15.8c0-1.7-0.3-3.3-0.7-4.8L472.3,331.3z"></path><path d="M597.3,453.9l-0.1-253.8h-81.6v23.8c-16.8-10.1-35.5-17.3-55.5-21h0.5v-28.2h10V154h-82.1v20.7h10v28.2h0.6 c-78,14.4-137.1,82.7-137.1,164.8c0,92.6,75.1,167.7,167.7,167.7c31.6,0,61.2-8.8,86.4-24l14.7,24h86.2v-81.5L597.3,453.9 L597.3,453.9z M434.4,453.7v-9.6h-9.8v9.6c-43.8-2.6-78.8-37.7-81.1-81.6h9.7v-9.8h-9.7c2.6-43.5,37.5-78.4,81-80.9v9.6h9.8v-9.6 c42.9,2.3,77.5,36,81.3,78.5v2.8h-9.8v9.8h9.8l0,2.7C512,417.7,477.4,451.4,434.4,453.7L434.4,453.7z"></path><path d="M1463.3,217.2h168.2v60.6h-40.2l-103.2,253.8C1458.6,602.9,1410,670,1336.1,670c-18.2,0-42.4-2-59.2-6l7.4-74 c10.8,2,24.9,3.3,32.3,3.3c34.3,0,73-21.3,85.1-58.3l-104.5-257.2h-40.2v-60.6h168.3v60.6H1385l59.2,145.7l59.2-145.7h-40.1 L1463.3,217.2L1463.3,217.2z"></path></g></svg></span>
      <span class="cov-logo" data-h="22" aria-label="Imperva"><svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 326 88" style="enable-background:new 0 0 326 88;" xml:space="preserve"><style> .st0{fill:currentColor;} </style><g><path class="st0" d="M13.4,0H6.7H0v13.5h13.4V0z M325.9,74.5h-6.7h-6.7V88h13.4V74.5z"></path><path class="st0" d="M13.4,68.2H0V19.8h6.7h6.7V68.2z M75,18.8c9.9,0,15.8,6.9,15.8,17.9v31.5H77.5V39.4c0-5.2-2.3-8.6-6.9-8.6 c-3.5,0-6.6,2.2-7.4,6.3v31.2H49.7V39.4c0-5.2-2.2-8.6-6.8-8.6c-3.5,0-6.7,2.2-7.5,6.3v31.2H22.1V19.8h13.4v4 c2.4-3,6.8-5.1,12.1-5.1c5.7,0,10.3,2.6,12.9,6.2C63.6,21.4,68.2,18.8,75,18.8z M112.8,88H99.4V19.8h13.4v4c2.2-2.6,6.9-5.1,12-5.1 c14,0,21.9,11.7,21.9,25.3s-8,25.2-21.9,25.2c-5.2,0-9.9-2.5-12-5.1V88z M112.8,52c1.6,3.3,5.2,5.6,9,5.6c7.2,0,11.5-5.9,11.5-13.5 c0-7.8-4.3-13.6-11.5-13.6c-4,0-7.4,2.4-9,5.6V52z M164.6,47.1c1,7.9,6.8,11.2,13.8,11.2c5.3,0,9-1.2,13.7-4.3v11.1 c-4,2.9-9.3,4.3-15.8,4.3c-14.6,0-24.7-9.6-24.7-24.9c0-15.2,9.5-25.7,22.6-25.7c14,0,21.2,9.8,21.2,24.1v4.4L164.6,47.1 L164.6,47.1z M165.1,38.4h18.2c-0.3-5.2-3.2-8.9-8.5-8.9C170.4,29.5,166.6,32.3,165.1,38.4z M231.9,33.1c-1.8-1-4.2-1.6-6.7-1.6 c-4.5,0-8.2,2.4-9.1,6.8v29.9h-13.4V19.8h13.4v4.7c2.1-3.5,6-5.9,10.7-5.9c2.3,0,4.3,0.5,5.1,0.9V33.1z M252.7,68.2l-18.2-48.4 h13.9l11.1,32.1l10.8-32.1h13.5l-18.3,48.4H252.7z M312.7,38c0-4.6-4-7.6-10.7-7.6c-4.8,0-9.3,1.4-13.1,3.9V22.7 c3.5-2.2,9.7-4,16-4c13.3,0,21.2,6.8,21.2,18.7v30.8h-13.4v-2.6c-1.6,1.6-6.3,3.5-11.6,3.5c-9.7,0-17.8-5.6-17.8-15.7 c0-9.2,8.1-15.4,18.6-15.4c4.2,0,8.8,1.4,10.7,2.8V38z M312.7,51.5c-1.2-2.6-4.7-4.3-8.5-4.3c-4.2,0-8.5,1.8-8.5,6 c0,4.3,4.3,6,8.5,6c3.8,0,7.3-1.6,8.5-4.3V51.5z"></path></g></svg></span>
      <span class="cov-logo cov-logo--wordmark">HUMAN Security</span>
      <span class="cov-logo" data-h="22" aria-label="Okta"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 109.21 36"><path d="M98.97,23.67c-3.05,0-5.2-2.38-5.2-5.51s2.15-5.51,5.2-5.51,5.14,2.38,5.14,5.51-2.12,5.51-5.14,5.51Zm-.49,3.28c2.46,0,4.55-.96,5.87-2.97,.25,1.95,1.66,2.66,3.44,2.66h1.42v-3.09h-.61c-1.01,0-1.26-.49-1.26-1.64V9.69h-3.26v2.51c-1.11-1.76-3.2-2.82-5.6-2.82-4.28,0-8.21,3.59-8.21,8.78s3.94,8.78,8.21,8.78Zm-16.79-4.24c0,2.78,1.72,3.93,3.78,3.93h3.97v-3.09h-2.89c-1.2,0-1.45-.46-1.45-1.64V12.78h4.34v-3.09h-4.34V4h-3.41V22.71Zm-15.53,3.93h3.41v-7.27h1.14l5.81,7.27h4.31l-7.41-9.22,5.69-7.73h-3.84l-4.65,6.53h-1.05V4h-3.41V26.64Zm-11.07-17.26c-4.77,0-8.7,3.59-8.7,8.78s3.94,8.78,8.7,8.78,8.7-3.59,8.7-8.78-3.94-8.78-8.7-8.78Zm0,14.29c-3.05,0-5.2-2.38-5.2-5.51s2.15-5.51,5.2-5.51,5.2,2.38,5.2,5.51-2.15,5.51-5.2,5.51Z" fill="currentColor"></path><path d="M19.8,.26l-.74,9.12c-.35-.04-.7-.06-1.06-.06-.45,0-.89,.03-1.32,.1l-.42-4.42c-.01-.14,.1-.26,.24-.26h.75l-.36-4.47c-.01-.14,.1-.26,.23-.26h2.45c.14,0,.25,.12,.23,.26h0Zm-6.18,.45c-.04-.13-.18-.21-.31-.16l-2.3,.84c-.13,.05-.19,.2-.13,.32l1.87,4.08-.71,.26c-.13,.05-.19,.2-.13,.32l1.91,4.01c.69-.38,1.44-.67,2.23-.85L13.63,.71ZM7.98,3.25l5.29,7.46c-.67,.44-1.28,.96-1.8,1.56l-3.17-3.12c-.1-.1-.09-.26,.01-.35l.58-.48-3.15-3.19c-.1-.1-.09-.26,.02-.35l1.87-1.57c.11-.09,.26-.07,.34,.04ZM3.54,7.57c-.11-.08-.27-.04-.34,.08l-1.22,2.12c-.07,.12-.02,.27,.1,.33l4.06,1.92-.38,.65c-.07,.12-.02,.28,.11,.33l4.04,1.85c.29-.75,.68-1.45,1.16-2.08L3.54,7.57ZM.55,13.33c.02-.14,.16-.22,.29-.19l8.85,2.31c-.23,.75-.36,1.54-.38,2.36l-4.43-.36c-.14-.01-.24-.14-.21-.28l.13-.74-4.47-.42c-.14-.01-.23-.14-.21-.28l.42-2.41h0Zm-.33,5.98c-.14,.01-.23,.14-.21,.28l.43,2.41c.02,.14,.16,.22,.29,.19l4.34-1.13,.13,.74c.02,.14,.16,.22,.29,.19l4.28-1.18c-.25-.74-.41-1.53-.45-2.34L.21,19.31Zm1.42,6.34c-.07-.12-.02-.27,.1-.33l8.26-3.92c.31,.74,.73,1.43,1.23,2.05l-3.62,2.58c-.11,.08-.27,.05-.34-.07l-.38-.66-3.69,2.55c-.11,.08-.27,.04-.34-.08l-1.23-2.12Zm10.01-1.72l-6.43,6.51c-.1,.1-.09,.26,.02,.35l1.88,1.57c.11,.09,.26,.07,.34-.04l2.6-3.66,.58,.49c.11,.09,.27,.07,.35-.05l2.52-3.66c-.68-.42-1.31-.93-1.85-1.51Zm-1.27,10.45c-.13-.05-.19-.2-.13-.32l3.81-8.32c.7,.36,1.46,.63,2.25,.78l-1.12,4.3c-.03,.13-.18,.21-.31,.16l-.71-.26-1.19,4.33c-.04,.13-.18,.21-.31,.16l-2.3-.84h0Zm6.56-7.75l-.74,9.12c-.01,.14,.1,.26,.23,.26h2.45c.14,0,.25-.12,.23-.26l-.36-4.47h.75c.14,0,.25-.12,.24-.26l-.42-4.42c-.43,.07-.87,.1-1.32,.1-.36,0-.71-.02-1.06-.07h0ZM25.76,1.94c.06-.13,0-.27-.13-.32l-2.3-.84c-.13-.05-.27,.03-.31,.16l-1.19,4.33-.71-.26c-.13-.05-.27,.03-.31,.16l-1.12,4.3c.8,.16,1.55,.43,2.25,.78L25.76,1.94h0Zm5.02,3.63l-6.43,6.51c-.54-.58-1.16-1.09-1.85-1.51l2.52-3.66c.08-.11,.24-.14,.35-.05l.58,.49,2.6-3.66c.08-.11,.24-.13,.34-.04l1.88,1.57c.11,.09,.11,.25,.02,.35Zm3.48,5.12c.13-.06,.17-.21,.1-.33l-1.23-2.12c-.07-.12-.23-.15-.34-.08l-3.69,2.55-.38-.65c-.07-.12-.23-.16-.34-.07l-3.62,2.58c.5,.62,.91,1.31,1.23,2.05l8.26-3.92Zm1.3,3.32l.42,2.41c.02,.14-.07,.26-.21,.28l-9.11,.85c-.04-.82-.2-1.6-.45-2.34l4.28-1.18c.13-.04,.27,.05,.29,.19l.13,.74,4.34-1.13c.13-.03,.27,.05,.29,.19h0Zm-.41,8.85c.13,.03,.27-.05,.29-.19l.42-2.41c.02-.14-.07-.26-.21-.28l-4.47-.42,.13-.74c.02-.14-.07-.26-.21-.28l-4.43-.36c-.02,.82-.15,1.61-.38,2.36l8.85,2.31h0Zm-2.36,5.5c-.07,.12-.23,.15-.34,.08l-7.53-5.2c.48-.63,.87-1.33,1.16-2.08l4.04,1.85c.13,.06,.18,.21,.11,.33l-.38,.65,4.06,1.92c.12,.06,.17,.21,.1,.33l-1.22,2.12h0Zm-10.07-3.07l5.29,7.46c.08,.11,.24,.13,.34,.04l1.87-1.57c.11-.09,.11-.25,.02-.35l-3.15-3.19,.58-.48c.11-.09,.11-.25,.01-.35l-3.17-3.12c-.53,.6-1.13,1.13-1.8,1.56h0Zm-.05,10.16c-.13,.05-.27-.03-.31-.16l-2.42-8.82c.79-.18,1.54-.47,2.23-.85l1.91,4.01c.06,.13,0,.28-.13,.32l-.71,.26,1.87,4.08c.06,.13,0,.27-.13,.32l-2.3,.84h0Z" fill="currentColor" fill-rule="evenodd"></path></svg></span>
      <span class="cov-logo" data-h="22" aria-label="Auth0"><svg version="1.1" id="layer" x="0px" y="0px" viewBox="-153 -46 2235.4465 720" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:svg="http://www.w3.org/2000/svg"><style> .st0{fill:currentColor;} </style><path class="st0" d="M 360.33484,536.48447 288.0367,314 477.35347,176.48447 c 46.58386,142.73292 0,275.03106 -117.01863,360 z m 117.01863,-360 L 405.05534,-46 H 171.01807 l 71.92547,222.48447 c 0,0 234.40993,0 234.40993,0 z M 171.01807,-46 H -63.019202 L -134.94466,176.48447 H 99.092595 Z m -306.3354,222.48447 c -46.21118,142.73292 0,275.03106 117.018625,360 L 53.626761,314 Z m 117.018625,360 L 171.01807,674 360.33484,536.48447 171.01807,398.96894 Z" id="path4" style="stroke-width:3.72671" /><path d="m 824.68267,88.90683 c -30.18634,0 -56.64597,19.75156 -65.21739,48.81988 L 655.86279,494 h 68.19876 l 30.559,-103.22981 c 0.37268,-1.11802 1.11802,-1.86336 2.23603,-1.86336 h 136.77019 c 1.11801,0 1.86335,0.74534 2.23602,1.86336 L 925.67646,494 h 67.82609 L 889.52739,137.72671 C 881.32863,108.65839 854.869,88.90683 824.68267,88.90683 Z m 54.40993,248.57143 c -0.37267,0.74534 -1.11801,0.74534 -1.86335,0.74534 H 772.88142 c -0.74534,0 -1.49068,-0.37267 -1.86335,-0.74534 -0.37267,-0.74534 -0.37267,-1.49068 0,-2.23602 l 51.80124,-179.62733 c 0.37267,-1.11802 1.11802,-1.86336 2.23603,-1.86336 1.11801,0.37267 1.49068,1.11802 1.86335,1.86336 l 52.17391,179.62733 c 0,0.74534 0,1.49068 0,2.23602 z m 316.7701,-98.75776 h 65.5901 v 255.65217 h -51.4286 l -7.0807,-21.61491 c -0.3727,-0.74534 -0.7454,-1.49068 -1.4907,-1.86335 -0.7453,-0.37267 -1.4907,-0.37267 -2.236,0 -24.2236,18.26087 -53.2919,28.32298 -83.4783,28.69565 -34.2857,0 -65.59,-20.49689 -79.0062,-52.17391 -4.472,-10.43478 -6.7081,-21.24224 -6.7081,-32.42236 V 238.7205 h 65.5901 v 172.54658 c 0,20.4969 17.1429,37.26708 37.6397,37.26708 21.2423,-1.11801 42.1118,-6.70807 60.7454,-16.77018 0.7453,-0.37268 1.4907,-1.11802 1.118,-1.86336 z m 555.2795,79.00621 v 176.64596 h -65.2173 V 321.45342 c 0,-9.68944 -4.0994,-19.37889 -11.1802,-26.08696 -7.0807,-7.08075 -16.3975,-10.80745 -26.4596,-10.80745 -21.2422,1.11801 -42.1118,6.70807 -61.118,16.77018 -0.7454,0.37267 -1.118,1.11801 -1.118,2.23603 V 494.37267 H 1520.459 V 94.49689 h 65.5901 v 160.24845 c 0,0.74534 0.3726,1.86336 1.118,2.23603 0.7453,0.37267 1.8633,0.37267 2.6087,0 22.7329,-14.90684 49.1925,-23.10559 76.0248,-23.47826 46.5839,0.37267 84.2236,37.63975 84.5963,84.2236 z m -333.913,-79.00621 h 39.8758 v 50.68323 h -39.8758 c -0.7453,0 -1.118,0.37267 -1.8634,0.74534 -0.3726,0.37267 -0.7453,1.11801 -0.7453,1.86335 v 137.14286 c 0,10.80745 8.9441,19.75155 20.1242,19.75155 0,0 0,0 0,0 5.9628,0 14.5342,0 22.3603,-1.11801 V 494 c -13.0435,3.72671 -26.4597,5.96273 -39.8758,5.59006 -37.2671,0 -67.4534,-29.81366 -67.8261,-67.08074 V 291.63975 c 0,-1.49068 -1.118,-2.23602 -2.6087,-2.60869 h -39.1304 v -50.68323 h 39.8758 c 1.4906,0 2.236,-1.11802 2.6087,-2.6087 v -84.2236 h 65.59 v 84.2236 c -0.3727,1.49068 0.3727,2.6087 1.4907,2.98137 z m 626.4596,-92.79503 c -22.3602,-35.40373 -61.118,-56.64597 -102.8571,-56.64597 -41.7391,0 -80.4969,21.24224 -102.8572,56.64597 -24.9689,36.52173 -38.3851,87.95031 -38.3851,148.69565 -2.236,52.54658 11.5528,104.34782 38.7578,149.06832 22.3603,35.40373 61.118,56.64596 102.8572,56.64596 41.7391,0 80.4969,-21.24223 102.8571,-56.64596 25.3416,-36.89441 38.3851,-88.32298 38.3851,-148.69565 0,-60.37267 -13.4162,-112.54659 -38.3851,-149.06832 z m -53.6646,268.69565 c -12.6708,23.10559 -28.6956,34.28571 -48.8198,34.28571 -19.7516,0 -35.7764,-11.92546 -48.8199,-34.28571 -17.1429,-37.63975 -25.3416,-78.63354 -23.4783,-120 -1.8633,-41.36646 6.3354,-82.73292 23.4783,-120.74534 12.6708,-23.10559 28.6956,-34.28572 48.4472,-34.28572 19.7515,0 36.1491,11.18013 48.8199,34.28572 17.1428,37.63975 25.3416,78.63354 23.4782,120 2.236,41.73913 -5.59,83.10559 -23.1056,120.74534 z" id="path6" style="stroke-width:3.72671" /></svg></span>
      <span class="cov-logo" data-h="28" aria-label="Ory"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128"><path fill="currentColor" d="M64.162.066a.581.581 0 0 0-.26.063L33.754 15.043a.257.257 0 0 0-.152.246v12.766c-.004.035.015.066.046.086c.032.02.07.023.102.007l30.234-14.984a.34.34 0 0 1 .313 0l30.148 14.938c.11.054.164.02.164-.098c.063-4.074.067-8.149.016-12.227c-.008-.359.316-.527-.246-.804c-10.016-4.961-20-9.907-29.957-14.844a.581.581 0 0 0-.26-.063zm-.017 33.403C47.28 33.469 33.613 47.137 33.613 64s13.668 30.531 30.532 30.531c16.863 0 30.53-13.668 30.53-30.531s-13.667-30.531-30.53-30.531zM33.742 99.855c-.027-.015-.066-.011-.094.004a.098.098 0 0 0-.046.086v12.856c-.004.035.02.07.054.09l30.426 15.09a.092.092 0 0 0 .09 0l30.41-15.051a.104.104 0 0 0 .055-.09l.011-12.875a.098.098 0 0 0-.046-.086a.097.097 0 0 0-.098-.004l-30.305 15.004a.092.092 0 0 1-.09 0L33.742 99.855z"/></svg></span>
      <span class="cov-logo" data-h="18" aria-label="Forter"><svg xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 132.79791 25.596239" version="1.1" id="svg3497" ><g id="layer1" transform="translate(53.425737,-135.53521)"><g transform="translate(-426.59665,-197.06533)" id="g3449"><polygon transform="matrix(0.26458333,0,0,0.26458333,373.40633,332.83596)" id="polygon3385" points="275.389,91.567 300.106,91.567 307.856,25.407 334.609,25.407 337.099,4.185 258.872,4.185 256.386,25.407 283.142,25.407 " style="fill:currentColor" /><polygon transform="matrix(0.26458333,0,0,0.26458333,373.40633,332.83596)" id="polygon3387" points="333.476,91.567 405.84,91.567 408.254,70.969 360.351,70.969 361.974,57.114 404.782,57.114 407.021,38.013 364.213,38.013 365.764,24.782 413.029,24.782 415.443,4.185 343.716,4.185 " style="fill:currentColor" /><path id="path3389" d="m 498.7785,342.2332 -0.008,0.0661 c -0.19656,1.68418 -1.60177,2.74116 -3.82661,2.74116 h -4.3147 l 0.65091,-5.54837 h 4.28095 c 2.19093,0 3.431,0.92487 3.21738,2.74115 m 5.16123,-5.78022 c -1.39862,-1.58512 -3.78519,-2.50977 -7.39156,-2.50977 h -11.15777 l -2.70928,23.11976 h 6.53953 l 0.82058,-7.00186 h 2.86549 l 3.93254,7.00186 h 7.55005 l -4.68433,-8.05861 c 3.07573,-1.22232 5.27122,-3.56743 5.68617,-7.10162 l 0.008,-0.066 c 0.26643,-2.27861 -0.23278,-4.06256 -1.45918,-5.38372" style="fill:currentColor;stroke-width:0.26458332" /><path id="path3391" d="m 404.68561,353.22184 a 13.506598,13.506598 0 0 0 1.77984,-2.48244 9.6868693,9.6868693 0 0 0 1.02282,-2.68492 6.0645145,6.0645145 0 0 0 -0.0369,-2.96868 3.9539809,3.9539809 0 0 0 -1.91013,-2.33828 c -1.1615,-0.66502 -2.65803,-0.74907 -4.00448,-0.55047 a 12.431712,12.431712 0 0 0 -4.74966,1.84294 15.458763,15.458763 0 0 0 -1.2911,0.91987 0.94311522,0.94311522 0 0 0 -0.2635,0.4268 q -0.10557,0.57187 -0.16261,1.13759 c 0,0.005 0,0.009 2.2e-4,0.0164 0.004,0.13665 0.0358,0.60012 0.27352,0.37533 a 0.27486239,0.27486239 0 0 1 0.0367,-0.0289 12.155006,12.155006 0 0 1 1.93495,-1.53024 9.6745715,9.6745715 0 0 1 3.69132,-1.4323 c 1.04695,-0.15464 2.20961,-0.0888 3.11217,0.42817 a 3.0734,3.0734 0 0 1 1.48514,1.81674 4.7172059,4.7172059 0 0 1 0.0289,2.30753 7.5066021,7.5066021 0 0 1 -0.79508,2.08662 10.511663,10.511663 0 0 1 -1.38311,1.9297 11.870764,11.870764 0 0 1 -1.60289,1.48241 11.567268,11.567268 0 0 1 -1.67712,1.07337 9.7839926,9.7839926 0 0 1 -1.25535,0.54773 l -2.2e-4,6.9e-4 c 0,0 -0.45345,0.19495 -0.23208,0.43387 a 8.1650125,8.1650125 0 0 0 0.90826,0.59828 0.96689861,0.96689861 0 0 0 0.87068,-0.11956 14.990876,14.990876 0 0 0 2.1579,-1.3806 15.26322,15.26322 0 0 0 2.0618,-1.90761" style="fill:currentColor;stroke-width:0.26458332" /><path id="path3393" d="m 412.61564,334.17045 c -2.79083,-1.55345 -6.20271,-1.35646 -9.29551,0.21022 l -0.009,0.004 c -0.0232,0.0118 -0.0458,0.0255 -0.069,0.0374 -0.29198,0.17105 0.0731,0.16695 0.0731,0.16695 l 5.3e-4,4.5e-4 c 2.56284,-0.50492 5.05052,-0.72856 7.85659,0.50628 3.4071,1.60471 4.87357,5.16417 5.48597,8.03538 h 2.4e-4 c 0,0 0.32134,0.72083 0.54682,0.0264 0.0777,-3.83891 -1.5143,-7.27539 -4.59001,-8.98736" style="fill:currentColor;stroke-width:0.26458332" /><path id="path3395" d="m 410.28944,336.42224 c -2.51228,-1.33209 -6.50241,-0.89799 -9.51392,-0.16329 a 1.7481576,1.7481576 0 0 0 -0.63495,0.33844 q -0.42566,0.39012 -0.82968,0.8183 c -0.0449,0.0549 -0.31909,0.40402 0.0494,0.30586 0.008,-0.002 0.0132,-0.002 0.0205,-0.004 3.25861,-0.89482 7.24942,-1.22665 9.52735,-0.005 3.33923,1.79055 4.30213,4.97583 4.12746,8.39705 -0.17263,3.37931 -1.59969,6.79461 -3.55969,9.69451 l 0.002,2.3e-4 c 0,0 -0.14302,0.348 0.12436,0.20133 a 13.878719,13.878719 0 0 0 1.52452,-1.06085 10.729161,10.729161 0 0 0 0.6755,-0.84312 c 1.76345,-2.75028 2.96436,-5.93963 3.0468,-9.09121 0.0941,-3.58566 -1.0934,-6.74997 -4.56017,-8.58835" style="fill:currentColor;stroke-width:0.26458332" /><path id="path3397" d="m 411.14639,346.93808 a 8.6673213,8.6673213 0 0 0 -0.21842,-4.07371 5.7673583,5.7673583 0 0 0 -2.61728,-3.19164 c -1.56666,-0.94356 -3.60272,-1.15582 -5.46297,-0.98251 a 17.728467,17.728467 0 0 0 -5.68502,1.59627 c -0.0102,0.0173 -0.0209,0.034 -0.0312,0.0512 q -0.20667,0.35255 -0.39354,0.714 c -0.0109,0.0209 -0.0207,0.0419 -0.0314,0.0629 -0.0544,0.10658 -0.10317,0.21521 -0.15532,0.32248 -0.0503,0.13802 -0.0865,0.35917 0.29424,0.18357 0.008,-0.003 0.013,-0.004 0.0201,-0.007 a 15.838982,15.838982 0 0 1 5.05211,-1.5086 c 1.64093,-0.17718 3.4456,-0.0125 4.82732,0.82854 a 4.9980241,4.9980241 0 0 1 2.27383,2.86006 7.983376,7.983376 0 0 1 0.13574,3.687 13.291269,13.291269 0 0 1 -1.15673,3.52803 19.489618,19.489618 0 0 1 -2.20095,3.51323 23.231509,23.231509 0 0 1 -2.48313,2.70108 l 0.005,10e-4 c 0,0 -0.016,0.0121 -0.0396,0.031 -0.0674,0.0626 -0.13232,0.12776 -0.20065,0.18971 -0.0824,0.0984 -0.12025,0.19677 0.0237,0.22137 a 9.5125883,9.5125883 0 0 0 1.15194,0.0228 l 0.005,-0.0123 a 1.225505,1.225505 0 0 0 0.7026,-0.28583 24.92408,24.92408 0 0 0 2.51888,-2.72591 20.657724,20.657724 0 0 0 2.42188,-3.84868 14.077421,14.077421 0 0 0 1.24397,-3.87832" style="fill:currentColor;stroke-width:0.26458332" /><path id="path3399" d="m 397.73114,352.4523 a 1.6243829,1.6243829 0 0 1 -0.62859,-0.34323 1.4716416,1.4716416 0 0 1 -0.43682,-0.72194 2.4398684,2.4398684 0 0 1 0.0162,-1.10458 3.3015502,3.3015502 0 0 1 0.26896,-0.72104 4.4185416,4.4185416 0 0 1 0.45617,-0.73154 5.4778089,5.4778089 0 0 1 1.40908,-1.27493 4.4910824,4.4910824 0 0 1 1.71767,-0.66684 2.293022,2.293022 0 0 1 1.44825,0.19906 1.4325547,1.4325547 0 0 1 0.69098,0.84607 2.190705,2.190705 0 0 1 0.0141,1.07384 3.5075098,3.5075098 0 0 1 -0.37032,0.97042 4.8433143,4.8433143 0 0 1 -0.64384,0.89893 5.5550752,5.5550752 0 0 1 -0.74564,0.68938 5.4114646,5.4114646 0 0 1 -0.78004,0.49945 4.4550038,4.4550038 0 0 1 -0.80487,0.32705 3.4541354,3.4541354 0 0 1 -0.80986,0.14416 2.4323146,2.4323146 0 0 1 -0.80144,-0.0843 m 2.6487,0.78071 a 8.0313688,8.0313688 0 0 0 1.16425,-0.74496 8.2939757,8.2939757 0 0 0 1.11345,-1.03032 7.2196853,7.2196853 0 0 0 0.9604,-1.33962 5.2259282,5.2259282 0 0 0 0.55161,-1.4487 3.2716602,3.2716602 0 0 0 -0.0203,-1.60242 2.1338646,2.1338646 0 0 0 -1.03055,-1.26195 3.4233537,3.4233537 0 0 0 -2.16176,-0.29676 6.722864,6.722864 0 0 0 -2.56308,0.99435 8.1989082,8.1989082 0 0 0 -2.10234,1.90238 6.6320643,6.6320643 0 0 0 -0.68096,1.0909 5.1200235,5.1200235 0 0 0 -0.36007,0.92716 c -0.0139,0.0494 -0.0285,0.0973 -0.0412,0.14918 a 3.6520755,3.6520755 0 0 0 -0.0239,1.64843 2.2023176,2.2023176 0 0 0 0.65204,1.07792 2.3602976,2.3602976 0 0 0 0.72856,0.43796 c 0.0688,0.0264 0.13778,0.0521 0.2093,0.0733 a 3.6533878,3.6533878 0 0 0 1.19636,0.12685 5.156663,5.156663 0 0 0 1.20729,-0.21568 6.690016,6.690016 0 0 0 1.20091,-0.48806" style="fill:currentColor;stroke-width:0.26458332" /><path id="path3401" d="m 399.87322,350.75182 a 2.3913571,2.3913571 0 0 0 0.34822,-0.22252 2.5066625,2.5066625 0 0 0 0.33274,-0.30882 2.1334994,2.1334994 0 0 0 0.28719,-0.39969 1.5837164,1.5837164 0 0 0 0.16579,-0.43363 0.98295882,0.98295882 0 0 0 -0.007,-0.48056 0.63536512,0.63536512 0 0 0 -0.30815,-0.37669 0.91487624,0.91487624 0 0 0 -0.47188,-0.10317 1.4078691,1.4078691 0 0 0 -0.16217,0.0143 2.0055628,2.0055628 0 0 0 -0.76727,0.29723 2.4736848,2.4736848 0 0 0 -0.62926,0.56959 1.9444679,1.9444679 0 0 0 -0.20362,0.32614 1.5157556,1.5157556 0 0 0 -0.12069,0.32204 1.0975552,1.0975552 0 0 0 -0.006,0.4926 0.65972795,0.65972795 0 0 0 0.19473,0.32296 0.72171189,0.72171189 0 0 0 0.28058,0.1535 1.0847917,1.0847917 0 0 0 0.34754,0.0376 1.5396104,1.5396104 0 0 0 0.35963,-0.0645 1.9797183,1.9797183 0 0 0 0.35983,-0.14644" style="fill:currentColor;stroke-width:0.26458332" /><polygon transform="matrix(0.26458333,0,0,0.26458333,373.40633,332.83596)" id="polygon3403" points="33.469,25.407 80.097,25.407 82.584,4.184 11.238,4.184 1,91.567 25.716,91.567 29.373,60.36 71.543,60.36 73.897,40.261 31.726,40.261 " style="fill:currentColor" /><path id="path3405" d="m 433.64393,342.2332 -0.008,0.0661 c -0.19724,1.68418 -1.60197,2.74116 -3.82661,2.74116 h -4.31467 l 0.65021,-5.54837 h 4.28096 c 2.19116,0 3.43055,0.92487 3.21807,2.74115 m 5.16008,-5.78022 c -1.39861,-1.58512 -3.78472,-2.50977 -7.39109,-2.50977 H 420.2551 l -2.7086,23.11976 h 6.53953 l 0.81988,-7.00186 h 2.86575 l 3.93252,7.00186 h 7.55049 l -4.68497,-8.05861 c 3.07572,-1.22232 5.27189,-3.56743 5.68617,-7.10162 l 0.007,-0.066 c 0.26691,-2.27861 -0.23163,-4.06256 -1.45918,-5.38372" style="fill:currentColor;stroke-width:0.26458332" /></g></g></svg></span>
    </div>
    <div class="coverage-cta reveal">
      <a class="btn btn--secondary" href="https://kyapay.org" target="_blank" rel="noopener">
        Enable Agent Acceptance <span class="arr">→</span>
      </a>
    </div>
  </div>
</section>

<!-- ============ THREE PRODUCTS ============ -->
<section class="products">
  <div class="wrap">
    <div class="products-head">
      <div class="reveal">
        <div class="eyebrow">Product Stack</div>
        <h2>One unified trust stack.</h2>
      </div>
    </div>

    <div class="product-rows">
      <div class="product-row reveal">
        <div class="pr-num">01</div>
        <div class="pr-name"><span class="a">Know Your<br>Agent</span></div>
        <div class="pr-desc">Give your agents controlled access with a standardized open identity protocol designed to unblock websites, services and checkouts.</div>
        <a class="btn btn--primary" href="https://docs.skyfire.xyz/docs/kya-token" target="_blank" rel="noopener">Learn about KYA <span class="arr">→</span></a>
      </div>

      <div class="product-row reveal">
        <div class="pr-num">02</div>
        <div class="pr-name"><span class="t">Agentic<br>Wallet</span></div>
        <div class="pr-desc">Give your agents a secure wallet able to enroll user credit cards, manage stablecoins and collect user mandates.</div>
        <a class="btn btn--primary" href="https://skyfire.xyz/use-case/">See Use Cases <span class="arr">→</span></a>
      </div>

      <div class="product-row reveal">
        <div class="pr-num">03</div>
        <div class="pr-name"><span class="o">Buy<br>for Me</span></div>
        <div class="pr-desc">A complete agentic purchase experience on behalf of users with secure transactions leveraging existing referal links for checkout.</div>
        <a class="btn btn--primary" href="https://skyfire.xyz/use-case/">See Use Cases <span class="arr">→</span></a>
      </div>
    </div>
  </div>
</section>

<!-- ============ ACCESS CARD ============ -->
<section class="access-section">
  <div class="wrap">
    <div class="access-card reveal">
      <div>
        <div class="eyebrow">Access</div>
        <h3>Enable Agent Access<br>at Internet Scale</h3>
        <p>Teams that operate agents need reliable access to websites and applications. KYA tokens from Skyfire bind platform, agent, and human principal identities along with user mandates to allow seamless access at scale, across the open web.</p>
        <a class="btn btn--secondary" href="https://docs.skyfire.xyz/docs/kya-token" target="_blank" rel="noopener">
          Enable Agent Access <span class="arr">→</span>
        </a>
      </div>

      <div class="access-diagram">
        <svg class="access-svg" viewBox="0 0 480 540" fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <marker id="ah2" markerWidth="7" markerHeight="7" refX="5" refY="3.5" orient="auto">
              <path d="M0,0.5 L0,6.5 L6,3.5 z" fill="rgba(255,255,255,0.6)"/>
            </marker>
            <marker id="ah2-teal" markerWidth="7" markerHeight="7" refX="5" refY="3.5" orient="auto">
              <path d="M0,0.5 L0,6.5 L6,3.5 z" fill="#59AD9E"/>
            </marker>
            <marker id="ah2-soft" markerWidth="7" markerHeight="7" refX="5" refY="3.5" orient="auto">
              <path d="M0,0.5 L0,6.5 L6,3.5 z" fill="rgba(255,255,255,0.3)"/>
            </marker>
            <filter id="skyfire-glow-2" x="-60%" y="-60%" width="220%" height="220%">
              <feGaussianBlur in="SourceGraphic" stdDeviation="10"/>
            </filter>
            <linearGradient id="bar-grad-2" x1="0" x2="1" y1="0" y2="0">
              <stop offset="0%"  stop-color="rgba(255,255,255,0.10)"/>
              <stop offset="50%" stop-color="rgba(89,173,158,0.14)"/>
              <stop offset="100%" stop-color="rgba(255,255,255,0.10)"/>
            </linearGradient>
            <radialGradient id="dest-grad-2" cx="50%" cy="40%" r="70%">
              <stop offset="0%"  stop-color="rgba(255,255,255,0.14)"/>
              <stop offset="100%" stop-color="rgba(255,255,255,0.04)"/>
            </radialGradient>
            <clipPath id="bar-clip-2">
              <rect x="40" y="276" width="400" height="76" rx="14"/>
            </clipPath>
          </defs>

          <!-- Skyfire teal glow halo (top-right) -->
          <rect x="260" y="0" width="160" height="112" rx="22" fill="#1B7A69" opacity="0.42" filter="url(#skyfire-glow-2)"/>

          <!-- User box (top-left) -->
          <rect x="70" y="14" width="120" height="60" rx="14" fill="rgba(255,255,255,0.06)" stroke="rgba(255,255,255,0.3)" stroke-width="1.8"/>
          <g transform="translate(119.000 45.000) scale(0.02292)"><path d="M367-527q-47-47-47-113t47-113q47-47 113-47t113 47q47 47 47 113t-47 113q-47 47-113 47t-113-47ZM160-160v-112q0-34 17.5-62.5T224-378q62-31 126-46.5T480-440q66 0 130 15.5T736-378q29 15 46.5 43.5T800-272v112H160Zm80-80h480v-32q0-11-5.5-20T700-306q-54-27-109-40.5T480-360q-56 0-111 13.5T260-306q-9 5-14.5 14t-5.5 20v32Zm296.5-343.5Q560-607 560-640t-23.5-56.5Q513-720 480-720t-56.5 23.5Q400-673 400-640t23.5 56.5Q447-560 480-560t56.5-23.5ZM480-640Zm0 400Z" fill="rgba(255,255,255,0.9)"/></g>
          <text x="130" y="62" text-anchor="middle" fill="white" font-size="14" font-family="Geist,Inter,sans-serif" font-weight="500" letter-spacing="-0.3">User</text>

          <!-- Skyfire box (top-right) with logo -->
          <rect class="skyfire-node" x="280" y="14" width="120" height="80" rx="16" fill="#1B7A69" stroke="rgba(89,173,158,0.7)" stroke-width="2"/>
          <image class="sf-logo-mark" href="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTA4IiBoZWlnaHQ9IjI3IiB2aWV3Qm94PSIwIDAgMTA4IDI3IiBmaWxsPSJub25lIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgo8cGF0aCBkPSJNNzcuMjg5MyAyLjUyMTI0SDc0LjI5OTVDNzIuNzggMi41MjEyNCA3MS42NTU4IDIuODg2OTkgNzAuOTM5IDMuNjEzNThDNzAuMjIyMiA0LjM0MDE2IDY5Ljg2MTQgNS4zNzM1OSA2OS44NjE0IDYuNzEzODVWMjAuMDI4MUM2OS44NjE0IDIwLjM5MTQgNzAuMTUzNSAyMC42ODEgNzAuNTE0MyAyMC42ODFINzIuOTY5QzczLjMzMjMgMjAuNjgxIDczLjYyMiAyMC4zODg5IDczLjYyMiAyMC4wMjgxVjExLjU1Mkg3Ni42MjlDNzYuOTkyMiAxMS41NTIgNzcuMjgxOSAxMS4yNTk5IDc3LjI4MTkgMTAuODk5MVY5LjE4ODE3Qzc3LjI4MTkgOC44MjQ4OCA3Ni45ODk4IDguNTM1MjMgNzYuNjI5IDguNTM1MjNINzMuNjIyVjcuMTEzOTZDNzMuNjIyIDYuNTk2MDIgNzMuNzM5OCA2LjIxMzA5IDczLjk3MDUgNS45NTI4OUM3NC4yMDYyIDUuNjkwMjQgNzQuNTg0MiA1LjU2MjYgNzUuMTAyMSA1LjU2MjZINzYuNzIyMkM3Ny4wMDQ1IDUuNTYyNiA3Ny4yNTQ5IDUuMzgwOTUgNzcuMzQzMyA1LjExMzM5TDc3LjkxMjggMy4zODI4NEM3OC4wNTAyIDIuOTYwNjMgNzcuNzM4NSAyLjUyMzY5IDc3LjI5MTcgMi41MjM2OUw3Ny4yODkzIDIuNTIxMjRaTTczLjk4MDMgNS45NDA2MkM3My45ODAzIDUuOTQwNjIgNzMuOTc1NCA1Ljk0Nzk4IDczLjk3MyA1Ljk1MDQ0TDczLjk4MDMgNS45NDA2MlpNNjcuOTYxNSA3LjI0NjUxSDY1LjU1NTlDNjUuMjc4NSA3LjI0NjUxIDY1LjAzNTUgNy40MjA4IDY0LjkzOTcgNy42ODA5OUw2MS41MDA3IDE3LjIzOTVMNTcuOTkzIDcuNjgzNDVDNTcuODk3MiA3LjQyNTcxIDU3LjY1NDIgNy4yNTM4OCA1Ny4zNzkzIDcuMjUzODhINTAuNzMyQzUwLjUwMzcgNy4yNTM4OCA1MC4yOTAyIDcuMzc0MTYgNTAuMTcyMyA3LjU3MDUzTDQ2LjM0NzkgMTMuOTA4NUw1MC4xNzIzIDIwLjI0NjVDNTAuMjkwMiAyMC40NDI5IDUwLjUwMTMgMjAuNTYzMiA1MC43MzIgMjAuNTYzMkg1My40OTExQzU0LjAwMTYgMjAuNTYzMiA1NC4zMTU4IDIwLjAwNiA1NC4wNTA3IDE5LjU3MTVMNTAuNjM2MyAxMy45MDg1TDUzLjU1IDkuMDg1MDhDNTMuODM0NyA4LjYxMzc4IDU0LjUzNDMgOC42ODI1MSA1NC43MjMzIDkuMTk3OTlMNTguNzcxMSAyMC4yMTQ2QzU4Ljg0NzIgMjAuNDIwOCA1OS4wNDM2IDIwLjU1ODMgNTkuMjYyIDIwLjU1ODNINTkuNTc2MkM1OS45MzQ2IDIwLjU1ODMgNjAuMTkyNCAyMC45MTQyIDYwLjA3MjEgMjEuMjUwNUM1OS43Mjg0IDIyLjIxNzcgNTguODA1NSAyMi44NjgyIDU3Ljc4NjggMjIuODY4Mkg1NC44NDYxQzU0LjQ4MjggMjIuODY4MiA1NC4xOTMxIDIzLjE2MDMgNTQuMTkzMSAyMy41MjExVjI1Ljc4NjhDNTQuMTkzMSAyNi4xNTAxIDU0LjQ4NTIgMjYuNDM5NyA1NC44NDYxIDI2LjQzOTdINTcuNzg2OEM2MC4zMDUzIDI2LjQzOTcgNjIuNTYxMSAyNC44NDQyIDYzLjQyMDMgMjIuNDYwN0w2OC41NzUxIDguMTIwMzhDNjguNzI3MyA3LjY5MzI3IDY4LjQxMzEgNy4yNDY1MSA2Ny45NTkgNy4yNDY1MUg2Ny45NjE1Wk00NC43ODY3IDIuOTIzODFINDIuMzg4NUM0Mi4wMjUyIDIuOTIzODEgNDEuNzM1NiAzLjIxNTkyIDQxLjczNTYgMy41NzY3NlYxOS44OTA2QzQxLjczNTYgMjAuMjUzOSA0Mi4wMjc3IDIwLjU0MzYgNDIuMzg4NSAyMC41NDM2SDQ0Ljc4NjdDNDUuMTUgMjAuNTQzNiA0NS40Mzk3IDIwLjI1MTUgNDUuNDM5NyAxOS44OTA2VjMuNTc2NzZDNDUuNDM5NyAzLjIxMzQ2IDQ1LjE0NzYgMi45MjM4MSA0NC43ODY3IDIuOTIzODFaTTM3LjA2NDMgMTEuNDQ4OVYxMS40MzE4QzM2LjEyMTcgMTAuOTIxMiAzNC44MzA1IDEwLjUwMzkgMzMuMTkzMyAxMC4xNzVDMzIuMjQwOCA5Ljk3NjEzIDMxLjUwMiA5Ljc2NTAzIDMwLjk4MTYgOS41NTE0N0MzMC40NjEyIDkuMzM3OTEgMzAuMDkzIDkuMDg1MDggMjkuODcyMSA4Ljc5NTQyQzI5LjY0MzggOC41MTA2OCAyOS41NDMxIDguMTQ3MzkgMjkuNTQzMSA3LjcxMjkxQzI5LjU0MzEgNy4xMDY2IDI5Ljc4ODYgNi42MDA5MyAzMC4yNzQ2IDYuMjMwMjdDMzAuNzYwNyA1Ljg0MjQzIDMxLjQzMDggNS42NTU4OCAzMi4yODk5IDUuNjU1ODhDMzIuOTY1IDUuNjU1ODggMzMuNTQ2NyA1Ljc3NjE2IDM0LjAyMjkgNi4wMjY1NEMzNC40OTQyIDYuMjc2OTEgMzQuODgyMSA2LjYyNTQ4IDM1LjE1NDYgNy4wODQ1MUMzNS4zNDg1IDcuMzkzOCAzNS40ODM1IDcuNzQ0ODIgMzUuNTY2OSA4LjEzMjY2QzM1LjYzMzIgOC40NDY4NiAzNS45MjA0IDguNjY1MzIgMzYuMjM5NSA4LjY0ODE0TDM4LjY5NDIgOC41MTgwNEMzOS4wOTY4IDguNDk4NDEgMzkuMzc5MSA4LjEyMjg0IDM5LjMwMDUgNy43MzAwOUMzOS4xMzExIDYuODcwOTUgMzguODI5MiA2LjA5NTI3IDM4LjM4OTggNS40MDMwNEMzNy44MTU0IDQuNTAyMTcgMzcuMDI3NSAzLjgwNzUgMzYuMDI4NCAzLjI5NjkyQzM1LjAyOTQgMi43ODM4OSAzMy44MDQ1IDIuNTMxMDYgMzIuMzQ2NCAyLjUzMTA2QzMwLjk3NjcgMi41MzEwNiAyOS43OTYgMi43NDk1MyAyOC43OTY5IDMuMjA4NTVDMjcuODE1IDMuNjUwNCAyNy4wNDkyIDQuMjczODkgMjYuNTQxMSA1LjA3NDEyQzI2LjAyMDcgNS44NjIwNyAyNS43NjA1IDYuNzkyNCAyNS43NjA1IDcuODUyODJDMjUuNzYwNSA4Ljg0NDUyIDI1Ljk2NjcgOS42NjkyOSAyNi4zODQgMTAuMzI0N0MyNi43OTE0IDEwLjk3NzYgMjcuNDYxNiAxMS41MjUgMjguMzcyMiAxMS45NDk3QzI5LjI4MjkgMTIuMzc2OCAzMC40ODgyIDEyLjc2NDcgMzEuOTkwNSAxMy4xMjA2QzMzLjA3NTQgMTMuMzcxIDMzLjkwMDIgMTMuNjE2NCAzNC40NjIzIDEzLjg3NjZDMzUuMDE5NSAxNC4xMjcgMzUuNCAxNC40MTQyIDM1LjU5MzkgMTQuNzIxQzM1Ljc5MjggMTUuMDI3OSAzNS44OTEgMTUuMzgzOCAzNS44OTEgMTUuODAzNkMzNS44OTEgMTYuMjQ3OSAzNS43NzA3IDE2LjYyMzQgMzUuNTQ0OCAxNi45MzI3QzM1LjMxNjYgMTcuMjM5NSAzNC45ODAzIDE3LjQ3MDMgMzQuNTQ1OCAxNy42MTc2QzM0LjExMTMgMTcuNzY0OSAzMy41NzYyIDE3Ljg0NTkgMzIuOTU1MiAxNy44NDU5QzMyLjIwMTYgMTcuODQ1OSAzMS41NjMzIDE3LjcyNTYgMzEuMDQ1NCAxNy40NzUyQzMwLjUyNSAxNy4yMjQ4IDMwLjExNzUgMTYuODU5MSAyOS44MTA3IDE2LjM3MDZDMjkuNTgyNCAxNi4wMDczIDI5LjQxMDYgMTUuNTg3NSAyOS4yOTc3IDE1LjExMTNDMjkuMjI2NSAxNC44MDk0IDI4Ljk0NDIgMTQuNjA1NyAyOC42MzQ5IDE0LjYyMDRMMjYuMTE2NCAxNC43MzU4QzI1LjczMSAxNC43NTU0IDI1LjQzODkgMTUuMDk5MSAyNS40OTc4IDE1LjQ3OTVDMjUuNjUgMTYuNDM5MyAyNS45NjkxIDE3LjI5MzYgMjYuNDU1MSAxOC4wNDIyQzI3LjA2MTQgMTguOTY1MiAyNy45MTA4IDE5LjY5MTggMjguOTk4MiAyMC4xOTVDMzAuMDgzMiAyMC43MDggMzEuMzc5MiAyMC45NjA5IDMyLjkwMTEgMjAuOTYwOUMzNC4yODggMjAuOTYwOSAzNS40ODEgMjAuNzQ3MyAzNi40OTQ4IDIwLjMyMjZDMzcuNTExMSAxOS44OTU1IDM4LjI4OTIgMTkuMjgxOSAzOC44NDY0IDE4LjQ3NDNDMzkuMzk2MyAxNy42NjkxIDM5LjY3MzYgMTYuNzI0MSAzOS42NzM2IDE1LjYzNDJDMzkuNjczNiAxNC43MzMzIDM5LjQ3NDggMTMuOTQ3OCAzOS4wNzcxIDEzLjI1MzFDMzguNjg0NCAxMi41NTg1IDM4LjAwOTQgMTEuOTU5NSAzNy4wNjE4IDExLjQ1NjNMMzcuMDY0MyAxMS40NDg5Wk05My45MDc1IDcuMjA3MjRIOTIuOTAxMUM5MS45MzE1IDcuMjA3MjQgOTEuMTgwMyA3LjUxNDA4IDkwLjYyOCA4LjExNTQ3TDkwLjYxODIgOC4xMDU2NkM5MC4yMjU1IDguNTM3NjggODkuOTI2IDkuMTYzNjMgODkuNjk3NyA5Ljk3ODU4TDg5LjYzMTQgNy44MzMxOUM4OS42MTkyIDcuNDc5NzEgODkuMzMyIDcuMTk5ODggODguOTc4NSA3LjE5OTg4SDg2LjcxMjhDODYuMzQ5NSA3LjE5OTg4IDg2LjA1OTkgNy40OTE5OCA4Ni4wNTk5IDcuODUyODJWMjAuMDIzMkM4Ni4wNTk5IDIwLjM4NjUgODYuMzUyIDIwLjY3NjEgODYuNzEyOCAyMC42NzYxSDg5LjE2NzVDODkuNTMwOCAyMC42NzYxIDg5LjgyMDQgMjAuMzg0IDg5LjgyMDQgMjAuMDIzMlYxMy4xMTA4Qzg5LjgyMDQgMTIuNDI1OSA4OS45NDA3IDExLjg3ODUgOTAuMTU5MiAxMS40NzU5QzkwLjM3NzcgMTEuMDczNCA5MC43MjM4IDEwLjc4MTMgOTEuMTc1NCAxMC41OTk2QzkxLjYyOTYgMTAuNDE4IDkyLjE5NjYgMTAuMzIyMiA5Mi45MDg0IDEwLjMyMjJIOTMuOTE0OUM5NC4yNzgyIDEwLjMyMjIgOTQuNTY3OCAxMC4wMzAxIDk0LjU2NzggOS42NjkyOVY3Ljg2MDE5Qzk0LjU2NzggNy40OTY4OSA5NC4yNzU3IDcuMjA3MjQgOTMuOTE0OSA3LjIwNzI0TDkzLjkxIDcuMjAyMzNMOTMuOTA3NSA3LjIwNzI0Wk04Mi45NTIyIDIuNTMxMDZIODAuMzgyMkM4MC4wMTg5IDIuNTMxMDYgNzkuNzI5MiAyLjgyMzE3IDc5LjcyOTIgMy4xODQwMVY0Ljg5MDAxQzc5LjcyOTIgNS4yNTMzMSA4MC4wMjEzIDUuNTQyOTYgODAuMzgyMiA1LjU0Mjk2SDgyLjk1MjJDODMuMzE1NSA1LjU0Mjk2IDgzLjYwNTIgNS4yNTA4NSA4My42MDUyIDQuODkwMDFWMy4xODQwMUM4My42MDUyIDIuODIwNzEgODMuMzEzMSAyLjUzMTA2IDgyLjk1MjIgMi41MzEwNlpNODIuOTE1NCA3LjIwMjMzSDgwLjQ2MDdDODAuMDk3NCA3LjIwMjMzIDc5LjgwNzggNy40OTQ0NCA3OS44MDc4IDcuODU1MjhWMjAuMDI1NkM3OS44MDc4IDIwLjM4ODkgODAuMDk5OSAyMC42Nzg2IDgwLjQ2MDcgMjAuNjc4Nkg4Mi45MTU0QzgzLjI3ODcgMjAuNjc4NiA4My41Njg0IDIwLjM4NjUgODMuNTY4NCAyMC4wMjU2VjcuODU1MjhDODMuNTY4NCA3LjQ5MTk4IDgzLjI3NjIgNy4yMDIzMyA4Mi45MTU0IDcuMjAyMzNaTTEwNy4yIDEwLjI5NTJDMTA2LjY1NSA5LjIxMjcyIDEwNS44ODYgOC4zNjgzMSAxMDQuOTAyIDcuNzg2NTVDMTAzLjkyIDcuMjAyMzMgMTAyLjc5MyA2LjkxMDIyIDEwMS40MjYgNi45MTAyMkMxMDAuMDU5IDYuOTEwMjIgOTguODY4NCA3LjIwMjMzIDk3Ljg2OTQgNy43ODY1NUM5Ni44NzAzIDguMzcwNzYgOTYuMDgyNCA5LjE5MDYzIDk1LjUyNTEgMTAuMjMxNEM5NC45Njc5IDExLjI3MjIgOTQuNjgzMiAxMi41MTQzIDk0LjY4MzIgMTMuOTQwNEM5NC42ODMyIDE1LjM2NjYgOTQuOTYwNiAxNi42MDg3IDk1LjUyNTEgMTcuNjY0MkM5Ni4wODI0IDE4LjcyMjIgOTYuODcwMyAxOS41MzIyIDk3Ljg3NjcgMjAuMTA5MUM5OC44ODMyIDIwLjY4MzUgMTAwLjA3MSAyMC45NzU2IDEwMS40NTEgMjAuOTc1NkMxMDUuMjQ4IDIwLjk3NTYgMTA2Ljg4MyAxOC43MjQ2IDEwNy41MTQgMTcuNDA0QzEwNy43MjIgMTYuOTY5NSAxMDcuNDAzIDE2LjQ2ODggMTA2LjkyMiAxNi40Njg4SDEwNC40NjVDMTA0LjIxMiAxNi40Njg4IDEwMy45ODYgMTYuNjIxIDEwMy44NzEgMTYuODQ2OEMxMDMuNjg1IDE3LjIxMjUgMTAzLjQyOSAxNy40OTczIDEwMy4xMSAxNy43MDFDMTAyLjY4NSAxNy45Njg2IDEwMi4xNTMgMTguMTAzNiAxMDEuNTE5IDE4LjEwMzZDMTAwLjY0NiAxOC4xMDM2IDk5Ljk1NTggMTcuODQzNCA5OS40MjU2IDE3LjMyMDZDOTguOTA1MiAxNi44MDAyIDk4LjYxNTYgMTYuMDAyNCA5OC41NjE2IDE0LjkyNzJIMTA4LjAwMlYxNC4xNzEyTDEwOC4wMSAxNC4xODg0QzEwOC4wMSAxMi42ODM2IDEwNy43MzIgMTEuMzkyNSAxMDcuMiAxMC4yOTI4SDEwNy4xOTVMMTA3LjIgMTAuMjk1MlpNOTguNTczOSAxMi42NDE5Qzk4LjY3NyAxMS43MDE4IDk4Ljk4MTMgMTAuOTc1MiA5OS40OTQ0IDEwLjQ2NDZDMTAwLjAwNyA5Ljk1MTU4IDEwMC42NTEgOS42OTg3NSAxMDEuNDM2IDkuNjk4NzVDMTAyLjIyMiA5LjY5ODc1IDEwMi44NiA5Ljk0NDIyIDEwMy4zNTYgMTAuNDM1MkMxMDMuODUxIDEwLjkyNjEgMTA0LjExOSAxMS42NTc2IDEwNC4xNjYgMTIuNjQ0NEg5OC41NjlMOTguNTczOSAxMi42NDE5WiIgZmlsbD0iIzI4MTcxQiIvPgo8cGF0aCBkPSJNNi4zOTIxNyAxNC45NjkySDkuMjAyNzlDMTEuMDQzOCAxNC45NjkyIDEyLjUzNjMgMTMuNDc2NyAxMi41MzYzIDExLjYzNTdWOC44MzczN0MxMi41MzYzIDcuNDE4NTYgMTQuMjUyMSA2LjcwOTE1IDE1LjI1MzYgNy43MTA2NkwxNy42MTAxIDEwLjA2NzJDMTcuOTA5NiAxMC4zNjY2IDE4LjA3NjUgMTAuNzcxNyAxOC4wNzY1IDExLjE5MzlWMTguOTE2M0MxOC4wNzY1IDE5Ljc5NTEgMTcuMzY0NiAyMC41MDk0IDE2LjQ4MzQgMjAuNTA5NEg4Ljc1ODQ5QzguMzM2MjkgMjAuNTA5NCA3LjkzMzcyIDIwLjM0MjUgNy42MzQyNSAyMC4wNDU1TDUuMjY3OTMgMTcuNjg5QzQuMjYxNSAxNi42ODc1IDQuOTcwOTEgMTQuOTY5MiA2LjM5MjE3IDE0Ljk2OTJaIiBmaWxsPSIjMjgxNzFCIi8+CjxwYXRoIGQ9Ik0xMi4wMTczIDYuMTAyNzRIOS4yMDY3MUM3LjM2NTY5IDYuMTAyNzQgNS44NzMyNCA3LjU5NTE5IDUuODczMjQgOS40MzYyMVYxMi4yMzQ2QzUuODczMjQgMTMuNjUzNCA0LjE1NzQxIDE0LjM2MjggMy4xNTU5IDEzLjM2MTNMMC43OTkzOTkgMTAuOTk5OEMwLjQ5OTkyNyAxMC43MDA0IDAuMzMzMDA4IDEwLjI5NTMgMC4zMzMwMDggOS44NzMxNFYyLjE1MzE1QzAuMzMzMDA4IDEuMjcxOTIgMS4wNDQ4NyAwLjU2MDA1OSAxLjkyNjEgMC41NjAwNTlIOS42NTFDMTAuMDczMiAwLjU2MDA1OSAxMC40NzU4IDAuNzI2OTc3IDEwLjc3NTMgMS4wMjM5OUwxMy4xNDE2IDMuMzgwNDlDMTQuMTQ4IDQuMzgyMDEgMTMuNDM4NiA2LjEwMDI5IDEyLjAxNzMgNi4xMDAyOVY2LjEwMjc0WiIgZmlsbD0iIzI4MTcxQiIvPgo8L3N2Zz4K" x="298" y="32" width="84" height="22"/>
          <text x="340" y="74" text-anchor="middle" fill="rgba(255,255,255,0.9)" font-size="11" font-family="Inter,sans-serif" font-weight="400" letter-spacing="0.3">Agent Wallet</text>

          <!-- User → Agent (delegation, dashed diagonal) -->
          <line x1="155" y1="74" x2="215" y2="140" stroke="rgba(255,255,255,0.34)" stroke-width="1.6" stroke-dasharray="3 4" marker-end="url(#ah2-soft)"/>

          <!-- Skyfire → Agent (KYA, diagonal) -->
          <line class="kf" x1="320" y1="94" x2="265" y2="140" stroke="rgba(89,173,158,0.75)" stroke-width="1.8" marker-end="url(#ah2-teal)"/>
          <rect x="272" y="105" width="40" height="18" rx="9" fill="rgba(201,60,9,0.95)"/>
          <text x="292" y="118" text-anchor="middle" fill="white" font-size="10" font-family="Inter,sans-serif" font-weight="600" letter-spacing="0.8">KYA</text>

          <!-- Agent box (middle-center) -->
          <rect x="200" y="142" width="80" height="60" rx="14" fill="rgba(255,255,255,0.07)" stroke="rgba(255,255,255,0.34)" stroke-width="2"/>
          <g transform="translate(229.000 176.000) scale(0.02292)"><path d="M280-80 240-200l-120-40 120-40 40-120 40 120 120 40-120 40-40 120Zm480 0-40-120-120-40 120-40 40-120 40 120 120 40-120 40-40 120ZM480-280l-60-180-180-60 180-60 60-180 60 180 180 60-180 60-60 180Z" fill="rgba(255,255,255,0.9)"/></g>
          <text x="240" y="192" text-anchor="middle" fill="white" font-size="14" font-family="Geist,Inter,sans-serif" font-weight="500" letter-spacing="-0.3">Agent</text>

          <!-- Agent → Security KYA arrow (vertical down) -->
          <line class="kf5" x1="240" y1="202" x2="240" y2="268" stroke="rgba(255,255,255,0.55)" stroke-width="1.8" marker-end="url(#ah2)"/>
          <rect x="220" y="222" width="40" height="18" rx="9" fill="rgba(201,60,9,0.95)"/>
          <text x="240" y="235" text-anchor="middle" fill="white" font-size="10" font-family="Inter,sans-serif" font-weight="600" letter-spacing="0.8">KYA</text>

          <!-- Security bar (horizontal) -->
          <rect x="40" y="276" width="400" height="76" rx="14" fill="url(#bar-grad-2)" stroke="rgba(255,255,255,0.24)" stroke-width="1.2"/>
          <text x="56" y="268" fill="rgba(255,255,255,0.5)" font-size="9" font-family="Inter,sans-serif" font-weight="600" letter-spacing="1.8">SECURITY</text>

          <!-- Cycling brand logos inside the security bar (horizontal scroll) -->
          <g clip-path="url(#bar-clip-2)">
            <g class="logo-reel">
              <image href="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+CjwhLS0gQ3JlYXRlZCB3aXRoIElua3NjYXBlIChodHRwOi8vd3d3Lmlua3NjYXBlLm9yZy8pIC0tPgoKPHN2ZwogICB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iCiAgIHhtbG5zOmNjPSJodHRwOi8vY3JlYXRpdmVjb21tb25zLm9yZy9ucyMiCiAgIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyIKICAgeG1sbnM6c3ZnPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIKICAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogICB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIKICAgeG1sbnM6c29kaXBvZGk9Imh0dHA6Ly9zb2RpcG9kaS5zb3VyY2Vmb3JnZS5uZXQvRFREL3NvZGlwb2RpLTAuZHRkIgogICB4bWxuczppbmtzY2FwZT0iaHR0cDovL3d3dy5pbmtzY2FwZS5vcmcvbmFtZXNwYWNlcy9pbmtzY2FwZSIKICAgdmVyc2lvbj0iMS4xIgogICBpZD0ic3ZnODM0IgogICB4bWw6c3BhY2U9InByZXNlcnZlIgogICB3aWR0aD0iNDA5LjMzMjkyIgogICBoZWlnaHQ9IjE2Ni43NTA1OCIKICAgdmlld0JveD0iMCAwIDQwOS4zMzI5MiAxNjYuNzUwNTgiCiAgIHNvZGlwb2RpOmRvY25hbWU9IlBoYXNlZFJlbGVhc2UtQ1Muc3ZnIgogICBpbmtzY2FwZTp2ZXJzaW9uPSIwLjkyLjIgNWMzZTgwZCwgMjAxNy0wOC0wNiI+PG1ldGFkYXRhCiAgICAgaWQ9Im1ldGFkYXRhODQwIj48cmRmOlJERj48Y2M6V29yawogICAgICAgICByZGY6YWJvdXQ9IiI+PGRjOmZvcm1hdD5pbWFnZS9zdmcreG1sPC9kYzpmb3JtYXQ+PGRjOnR5cGUKICAgICAgICAgICByZGY6cmVzb3VyY2U9Imh0dHA6Ly9wdXJsLm9yZy9kYy9kY21pdHlwZS9TdGlsbEltYWdlIiAvPjxkYzp0aXRsZT48L2RjOnRpdGxlPjwvY2M6V29yaz48L3JkZjpSREY+PC9tZXRhZGF0YT48ZGVmcwogICAgIGlkPSJkZWZzODM4Ij48Y2xpcFBhdGgKICAgICAgIGNsaXBQYXRoVW5pdHM9InVzZXJTcGFjZU9uVXNlIgogICAgICAgaWQ9ImNsaXBQYXRoODUyIj48cGF0aAogICAgICAgICBkPSJNIDAsMCBIIDYxMiBWIDc5MiBIIDAgWiIKICAgICAgICAgaWQ9InBhdGg4NTAiCiAgICAgICAgIGlua3NjYXBlOmNvbm5lY3Rvci1jdXJ2YXR1cmU9IjAiIC8+PC9jbGlwUGF0aD48Y2xpcFBhdGgKICAgICAgIGNsaXBQYXRoVW5pdHM9InVzZXJTcGFjZU9uVXNlIgogICAgICAgaWQ9ImNsaXBQYXRoODYwIj48cGF0aAogICAgICAgICBkPSJtIC03NDkuMzY5LC00NS40MzkzIGggMiB2IC01OC43ODQ3IGggLTIgeiIKICAgICAgICAgaWQ9InBhdGg4NTgiCiAgICAgICAgIGlua3NjYXBlOmNvbm5lY3Rvci1jdXJ2YXR1cmU9IjAiIC8+PC9jbGlwUGF0aD48Y2xpcFBhdGgKICAgICAgIGNsaXBQYXRoVW5pdHM9InVzZXJTcGFjZU9uVXNlIgogICAgICAgaWQ9ImNsaXBQYXRoMTI1NiI+PHBhdGgKICAgICAgICAgZD0iTSAzNiwzOTEuNTIgSCAzMDQuMjI5IFYgMjcxLjQ3NSBIIDM2IFoiCiAgICAgICAgIGlkPSJwYXRoMTI1NCIKICAgICAgICAgaW5rc2NhcGU6Y29ubmVjdG9yLWN1cnZhdHVyZT0iMCIgLz48L2NsaXBQYXRoPjxjbGlwUGF0aAogICAgICAgY2xpcFBhdGhVbml0cz0idXNlclNwYWNlT25Vc2UiCiAgICAgICBpZD0iY2xpcFBhdGgxMzY4Ij48cGF0aAogICAgICAgICBkPSJNIDAsMCBIIDYxMiBWIDc5MiBIIDAgWiIKICAgICAgICAgaWQ9InBhdGgxMzY2IgogICAgICAgICBpbmtzY2FwZTpjb25uZWN0b3ItY3VydmF0dXJlPSIwIiAvPjwvY2xpcFBhdGg+PGNsaXBQYXRoCiAgICAgICBjbGlwUGF0aFVuaXRzPSJ1c2VyU3BhY2VPblVzZSIKICAgICAgIGlkPSJjbGlwUGF0aDEzOTYiPjxwYXRoCiAgICAgICAgIGQ9Ik0gMCwwIEggNjEyIFYgNzkyIEggMCBaIgogICAgICAgICBpZD0icGF0aDEzOTQiCiAgICAgICAgIGlua3NjYXBlOmNvbm5lY3Rvci1jdXJ2YXR1cmU9IjAiIC8+PC9jbGlwUGF0aD48Y2xpcFBhdGgKICAgICAgIGNsaXBQYXRoVW5pdHM9InVzZXJTcGFjZU9uVXNlIgogICAgICAgaWQ9ImNsaXBQYXRoMTQzMiI+PHBhdGgKICAgICAgICAgZD0iTSAwLDAgSCA2MTIgViA3OTIgSCAwIFoiCiAgICAgICAgIGlkPSJwYXRoMTQzMCIKICAgICAgICAgaW5rc2NhcGU6Y29ubmVjdG9yLWN1cnZhdHVyZT0iMCIgLz48L2NsaXBQYXRoPjwvZGVmcz48c29kaXBvZGk6bmFtZWR2aWV3CiAgICAgcGFnZWNvbG9yPSIjZmZmZmZmIgogICAgIGJvcmRlcmNvbG9yPSIjNjY2NjY2IgogICAgIGJvcmRlcm9wYWNpdHk9IjEiCiAgICAgb2JqZWN0dG9sZXJhbmNlPSIxMCIKICAgICBncmlkdG9sZXJhbmNlPSIxMCIKICAgICBndWlkZXRvbGVyYW5jZT0iMTAiCiAgICAgaW5rc2NhcGU6cGFnZW9wYWNpdHk9IjAiCiAgICAgaW5rc2NhcGU6cGFnZXNoYWRvdz0iMiIKICAgICBpbmtzY2FwZTp3aW5kb3ctd2lkdGg9IjEzODIiCiAgICAgaW5rc2NhcGU6d2luZG93LWhlaWdodD0iOTQ1IgogICAgIGlkPSJuYW1lZHZpZXc4MzYiCiAgICAgc2hvd2dyaWQ9ImZhbHNlIgogICAgIGZpdC1tYXJnaW4tdG9wPSIwIgogICAgIGZpdC1tYXJnaW4tbGVmdD0iMCIKICAgICBmaXQtbWFyZ2luLXJpZ2h0PSIwIgogICAgIGZpdC1tYXJnaW4tYm90dG9tPSIwIgogICAgIGlua3NjYXBlOnpvb209IjEiCiAgICAgaW5rc2NhcGU6Y3g9IjIyNC4xNzAxIgogICAgIGlua3NjYXBlOmN5PSIxNzEuNzEwOTciCiAgICAgaW5rc2NhcGU6d2luZG93LXg9IjE2OCIKICAgICBpbmtzY2FwZTp3aW5kb3cteT0iMjAiCiAgICAgaW5rc2NhcGU6d2luZG93LW1heGltaXplZD0iMCIKICAgICBpbmtzY2FwZTpjdXJyZW50LWxheWVyPSJnMTUxOCIgLz48ZwogICAgIGlkPSJnODQyIgogICAgIGlua3NjYXBlOmdyb3VwbW9kZT0ibGF5ZXIiCiAgICAgaW5rc2NhcGU6bGFiZWw9IlBoYXNlZFJlbGVhc2UtQ1MiCiAgICAgdHJhbnNmb3JtPSJtYXRyaXgoMS4zMzMzMzMzLDAsMCwtMS4zMzMzMzMzLC0yMzcuMDk1OTcsMTAwMi40MzQzKSI+PGcKICAgICAgIGlkPSJnMTUxOCIKICAgICAgIHRyYW5zZm9ybT0ibWF0cml4KDQuMjA1NDkyNywwLDAsNC4yMDU0OTI3LC0xOTM3Ljg0NDksLTI0MTkuMTAyNykiPjxnCiAgICAgICAgIGlkPSJnMTM5MiIKICAgICAgICAgY2xpcC1wYXRoPSJ1cmwoI2NsaXBQYXRoMTM5NikiCiAgICAgICAgIHN0eWxlPSJmaWxsOndoaXRlIiAvPjxnCiAgICAgICAgIGlkPSJnMTU1NyI+PGcKICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZTtmaWxsLW9wYWNpdHk6MSIKICAgICAgICAgICB0cmFuc2Zvcm09InRyYW5zbGF0ZSg1MTguMTc2Myw3MjQuOTE4OSkiCiAgICAgICAgICAgaWQ9ImcxNDAyIj48cGF0aAogICAgICAgICAgICAgaW5rc2NhcGU6Y29ubmVjdG9yLWN1cnZhdHVyZT0iMCIKICAgICAgICAgICAgIGlkPSJwYXRoMTQwNCIKICAgICAgICAgICAgIHN0eWxlPSJmaWxsOndoaXRlO2ZpbGwtb3BhY2l0eToxO2ZpbGwtcnVsZTpub256ZXJvO3N0cm9rZTpub25lIgogICAgICAgICAgICAgZD0ibSAwLDAgYyAtNi4xMjcsMS44NjIgLTEwLjU4LDcuNTE3IC0xMC41OCwxNC4yMDkgMCw2Ljc2MyA0LjU0OCwxMi40NjUgMTAuNzY4LDE0LjI3OSAwLjYzNywwLjE4OSAwLjQ3MiwwLjU5IC0wLjMwNiwwLjU5IC04LjI3MSwwIC0xNC45ODYsLTYuNjY5IC0xNC45ODYsLTE0Ljg2OSAwLC04LjIgNi43MTUsLTE0Ljg2OSAxNC45ODYsLTE0Ljg2OSBDIDAuNjYsLTAuNjYgMC43MDcsLTAuMjEyIDAsMCIgLz48L2c+PGcKICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZSIKICAgICAgICAgICB0cmFuc2Zvcm09InRyYW5zbGF0ZSg1MTAuNDQ3NCw3MzUuNjYzOSkiCiAgICAgICAgICAgaWQ9ImcxNDA2Ij48cGF0aAogICAgICAgICAgICAgaW5rc2NhcGU6Y29ubmVjdG9yLWN1cnZhdHVyZT0iMCIKICAgICAgICAgICAgIGlkPSJwYXRoMTQwOCIKICAgICAgICAgICAgIHN0eWxlPSJmaWxsOndoaXRlO2ZpbGwtb3BhY2l0eToxO2ZpbGwtcnVsZTpub256ZXJvO3N0cm9rZTpub25lIgogICAgICAgICAgICAgZD0ibSAwLDAgYyAtMC4wNDcsMC40MDEgLTAuMDcxLDAuODAxIC0wLjA3MSwxLjIwMiAwLDYuNTI3IDUuMjc5LDExLjgwNSAxMS44MDYsMTEuODA1IDYuMTczLDAgOC4wMTEsLTIuNzU3IDguMjQ3LC0yLjU2OCAwLjI1OSwwLjE4OCAtMi4yMzksNS42NTUgLTkuNDczLDUuNjU1IC02LjUyNywwIC0xMS44MDUsLTUuMjc4IC0xMS44MDUsLTExLjgwNSAwLC0xLjUwOCAwLjI4MywtMi45NDYgMC44MDEsLTQuMjY1IEMgLTAuMjgzLC0wLjU0MiAwLjA0NywtMC41NDIgMCwwIiAvPjwvZz48ZwogICAgICAgICAgIHN0eWxlPSJmaWxsOndoaXRlO2ZpbGwtb3BhY2l0eToxIgogICAgICAgICAgIHRyYW5zZm9ybT0idHJhbnNsYXRlKDUxNS4zOTU4LDc0NC4xNzA0KSIKICAgICAgICAgICBpZD0iZzE0MTAiPjxwYXRoCiAgICAgICAgICAgICBpbmtzY2FwZTpjb25uZWN0b3ItY3VydmF0dXJlPSIwIgogICAgICAgICAgICAgaWQ9InBhdGgxNDEyIgogICAgICAgICAgICAgc3R5bGU9ImZpbGw6d2hpdGU7ZmlsbC1vcGFjaXR5OjE7ZmlsbC1ydWxlOm5vbnplcm87c3Ryb2tlOm5vbmUiCiAgICAgICAgICAgICBkPSJtIDAsMCBjIDMuMDYzLDEuMzQzIDYuOTI4LDEuMzkgMTAuNzIxLDAuMDQ3IDIuNTQ1LC0wLjg5NSA0LjAzLC0yLjE2OCA0LjE0OCwtMi4wOTcgMC4yMTIsMC4wOTQgLTEuNDg1LDIuNzU3IC00LjUyNSwzLjkxMiBDIDYuNjY4LDMuMjUyIDIuNzEsMi41MjEgLTAuMTY1LDAuMjU5IC0wLjQ5NSwwIC0wLjM3NywtMC4xNjUgMCwwIiAvPjwvZz48ZwogICAgICAgICAgIHN0eWxlPSJmaWxsOndoaXRlO2ZpbGwtb3BhY2l0eToxIgogICAgICAgICAgIHRyYW5zZm9ybT0idHJhbnNsYXRlKDU3Ni4wNzIsNzM4LjYwOTQpIgogICAgICAgICAgIGlkPSJnMTQxNCI+PHBhdGgKICAgICAgICAgICAgIGlua3NjYXBlOmNvbm5lY3Rvci1jdXJ2YXR1cmU9IjAiCiAgICAgICAgICAgICBpZD0icGF0aDE0MTYiCiAgICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZTtmaWxsLW9wYWNpdHk6MTtmaWxsLXJ1bGU6bm9uemVybztzdHJva2U6bm9uZSIKICAgICAgICAgICAgIGQ9Im0gMCwwIGMgMCwtMC44NDggLTAuNzA3LC0xLjU1NSAtMS41NTUsLTEuNTU1IC0wLjg0OSwwIC0xLjU1NSwwLjY4MyAtMS41NTUsMS41NTUgMCwwLjg0OCAwLjY4MywxLjU1NSAxLjU1NSwxLjU1NSBDIC0wLjY4MywxLjU1NSAwLDAuODcyIDAsMCIgLz48L2c+PHBhdGgKICAgICAgICAgICBpbmtzY2FwZTpjb25uZWN0b3ItY3VydmF0dXJlPSIwIgogICAgICAgICAgIGlkPSJwYXRoMTQyMCIKICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZTtmaWxsLW9wYWNpdHk6MTtmaWxsLXJ1bGU6bm9uemVybztzdHJva2U6bm9uZSIKICAgICAgICAgICBkPSJtIDUyNS40NTc0LDcyOS45MTQ0IDAuMTg4LC0yLjA3NCBoIDMuMjc2IGwgLTEuMTA4LDEyLjA0MSBoIC00Ljg3NyBsIC02LjE3NCwtMTIuMDQxIGggMy4zNDYgbCAxLjAzNywyLjA3NCB6IG0gLTAuMTY1LDIuMzMzIGggLTIuOTkzIGwgMi41NjksNS4yMDcgaCAwLjAyMyB6IiAvPjxwYXRoCiAgICAgICAgICAgaW5rc2NhcGU6Y29ubmVjdG9yLWN1cnZhdHVyZT0iMCIKICAgICAgICAgICBpZD0icGF0aDE0MjQiCiAgICAgICAgICAgc3R5bGU9ImZpbGw6d2hpdGU7ZmlsbC1vcGFjaXR5OjE7ZmlsbC1ydWxlOm5vbnplcm87c3Ryb2tlOm5vbmUiCiAgICAgICAgICAgZD0ibSA1MzMuNDY5LDczMy4wOTU2IGggMC40OTUgbCAyLjMzMywzLjE4MSBoIDMuMDM5IGwgLTMuMjI4LC00LjA1MyAxLjk4LC00LjM4MyBoIC0zLjIyOSBsIC0xLjI5NiwzLjQxNyBoIC0wLjQ3MSBsIC0wLjczLC0zLjQxNyBoIC0yLjc1NyBsIDIuNTQ0LDEyLjA0MSBoIDIuNzU3IHoiIC8+PGcKICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZTtmaWxsLW9wYWNpdHk6MSIKICAgICAgICAgICBjbGlwLXBhdGg9InVybCgjY2xpcFBhdGgxNDMyKSIKICAgICAgICAgICBpZD0iZzE0MjgiPjxnCiAgICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZTtmaWxsLW9wYWNpdHk6MSIKICAgICAgICAgICAgIHRyYW5zZm9ybT0idHJhbnNsYXRlKDU0My42NDg1LDcyNy44NDA4KSIKICAgICAgICAgICAgIGlkPSJnMTQzNCI+PHBhdGgKICAgICAgICAgICAgICAgaW5rc2NhcGU6Y29ubmVjdG9yLWN1cnZhdHVyZT0iMCIKICAgICAgICAgICAgICAgaWQ9InBhdGgxNDM2IgogICAgICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZTtmaWxsLW9wYWNpdHk6MTtmaWxsLXJ1bGU6bm9uemVybztzdHJva2U6bm9uZSIKICAgICAgICAgICAgICAgZD0iTSAwLDAgSCAyLjc1NyBMIDMuODY0LDUuMjU1IEMgNC40NzcsOC4xNTMgMy4zNyw4LjUwNiAwLjU0Miw4LjUwNiBjIC0xLjk3OSwwIC0zLjg4OCwwLjAyNCAtNC40MywtMi41OTEgaCAyLjc1NyBjIDAuMTY1LDAuNzU0IDAuNjM2LDAuOTE4IDEuMzIsMC45MTggMS4yMDEsMCAxLjE1NCwtMC40OTQgMC45ODksLTEuMjcyIEwgMC44OTUsNC4yMTggSCAwLjc3OCBDIDAuNjgzLDUuMTg0IC0wLjU0Miw1LjE2IC0xLjMyLDUuMTYgYyAtMi4wMDIsMCAtMy4xODEsLTAuNjM2IC0zLjYwNSwtMi42NjIgLTAuNDQ3LC0yLjE0NCAwLjU2NiwtMi42MTYgMi40OTgsLTIuNjE2IDAuOTY2LDAgMi4yNjIsMC4xODkgMi43MSwxLjM0MyBIIDAuMzc3IFogTSAtMC43NzgsMy40ODcgQyAwLjExOCwzLjQ4NyAwLjcwNywzLjQxNyAwLjU2NSwyLjcxIDAuMzc3LDEuODM4IDAsMS42NzMgLTEuMTU1LDEuNjczIGMgLTAuNDI0LDAgLTEuMjAxLDAgLTEuMDEzLDAuOTE5IDAuMTY1LDAuNzc4IDAuNzA3LDAuODk1IDEuMzksMC44OTUiIC8+PC9nPjxnCiAgICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZTtmaWxsLW9wYWNpdHk6MSIKICAgICAgICAgICAgIHRyYW5zZm9ybT0idHJhbnNsYXRlKDU1MS45OSw3MzYuMjc2NikiCiAgICAgICAgICAgICBpZD0iZzE0MzgiPjxwYXRoCiAgICAgICAgICAgICAgIGlua3NjYXBlOmNvbm5lY3Rvci1jdXJ2YXR1cmU9IjAiCiAgICAgICAgICAgICAgIGlkPSJwYXRoMTQ0MCIKICAgICAgICAgICAgICAgc3R5bGU9ImZpbGw6d2hpdGU7ZmlsbC1vcGFjaXR5OjE7ZmlsbC1ydWxlOm5vbnplcm87c3Ryb2tlOm5vbmUiCiAgICAgICAgICAgICAgIGQ9Im0gMCwwIC0wLjI1OSwtMS4xNzggaCAwLjExOCBjIDAuNTQyLDAuOTkgMS42NDksMS4yNzIgMi41OTIsMS4yNzIgMS4xNzgsMCAyLjM1NiwtMC4yMTIgMi4xOTEsLTEuNjQ5IEggNC43NiBjIDAuNCwxLjIwMiAxLjYyNiwxLjY0OSAyLjY4NiwxLjY0OSAxLjk1NiwwIDIuNzgxLC0wLjgwMSAyLjM1NiwtMi43NTcgTCA4LjU3NywtOC40MzYgSCA1LjgyIGwgMS4wMzcsNC44NzggYyAwLjE0MSwwLjg3MiAwLjI4MywxLjUzMiAtMC43NzgsMS41MzIgLTEuMDg0LDAgLTEuNDM3LC0wLjcwNyAtMS42MjYsLTEuNjI2IEwgMy40NCwtOC40MzYgSCAwLjY4MyBsIDEuMDg0LDUuMTE0IGMgMC4xNDIsMC43NzcgMC4xODksMS4yOTYgLTAuNzc3LDEuMjk2IC0xLjEzMSwwIC0xLjQ4NSwtMC42MTMgLTEuNjk3LC0xLjYyNiBMIC0xLjcyLC04LjQzNiBIIC00LjQ3NyBMIC0yLjY4NiwwIFoiIC8+PC9nPjxnCiAgICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZTtmaWxsLW9wYWNpdHk6MSIKICAgICAgICAgICAgIHRyYW5zZm9ybT0idHJhbnNsYXRlKDU2Ni45MDU4LDcyNy44NDA4KSIKICAgICAgICAgICAgIGlkPSJnMTQ0MiI+PHBhdGgKICAgICAgICAgICAgICAgaW5rc2NhcGU6Y29ubmVjdG9yLWN1cnZhdHVyZT0iMCIKICAgICAgICAgICAgICAgaWQ9InBhdGgxNDQ0IgogICAgICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZTtmaWxsLW9wYWNpdHk6MTtmaWxsLXJ1bGU6bm9uemVybztzdHJva2U6bm9uZSIKICAgICAgICAgICAgICAgZD0ibSAwLDAgaCAyLjc1NyBsIDEuMTMxLDUuMjU1IGMgMC42MTMsMi44OTggLTAuNDk1LDMuMjUxIC0zLjMyMiwzLjI1MSAtMS45OCwwIC0zLjg4OSwwLjAyNCAtNC40MywtMi41OTEgaCAyLjc1NyBjIDAuMTY0LDAuNzU0IDAuNjM2LDAuOTE4IDEuMzE5LDAuOTE4IDEuMjAyLDAgMS4xNTUsLTAuNDk0IDAuOTksLTEuMjcyIEwgMC45MTksNC4yMTggSCAwLjgwMSBDIDAuNzA3LDUuMTg0IC0wLjUxOCw1LjE2IC0xLjI5Niw1LjE2IGMgLTIuMDAzLDAgLTMuMTgxLC0wLjYzNiAtMy42MDUsLTIuNjYyIC0wLjQ0OCwtMi4xNDQgMC41NjUsLTIuNjE2IDIuNDk3LC0yLjYxNiAwLjk2NywwIDIuMjYzLDAuMTg5IDIuNzEsMS4zNDMgSCAwLjQwMSBaIE0gLTAuNzU0LDMuNDg3IEMgMC4xNDEsMy40ODcgMC43MywzLjQxNyAwLjU4OSwyLjcxIDAuNDAxLDEuODM4IDAuMDI0LDEuNjczIC0xLjEzMSwxLjY3MyBjIC0wLjQyNCwwIC0xLjIwMiwwIC0xLjAxMywwLjkxOSAwLjE2NSwwLjc3OCAwLjcwNywwLjg5NSAxLjM5LDAuODk1IiAvPjwvZz48L2c+PHBhdGgKICAgICAgICAgICBpbmtzY2FwZTpjb25uZWN0b3ItY3VydmF0dXJlPSIwIgogICAgICAgICAgIGlkPSJwYXRoMTQ0OCIKICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZTtmaWxsLW9wYWNpdHk6MTtmaWxsLXJ1bGU6bm9uemVybztzdHJva2U6bm9uZSIKICAgICAgICAgICBkPSJtIDU3My42Njg1LDcyNy44NDA4IGggLTIuNzU3IGwgMS43NjcsOC40MzYgaCAyLjc4MSB6IiAvPjwvZz48L2c+PC9nPjwvc3ZnPg=="              x="55"  y="300" width="76" height="31"/>
              <image href="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDA5NiIgaGVpZ2h0PSI1MjgiIHZpZXdCb3g9IjAgMCA0MDk2IDUyOCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGcgY2xpcC1wYXRoPSJ1cmwoI2NsaXAwXzNfNjcpIj4KPHBhdGggZD0iTTI5MzQuMTEgMTI0LjY0M0MyODIxLjcyIDEyNC42NDMgMjc0My4yMiAyMDcuNTU3IDI3NDMuMjIgMzI2LjMwM0MyNzQzLjIyIDQ0NS4wNDggMjgyMS43MiA1MjcuOTYyIDI5MzQuMTEgNTI3Ljk2MkMyOTg4LjM1IDUyNy45NjIgMzAzNy4xNyA1MDcuNDk4IDMwNzEuNjEgNDcwLjMxOUMzMTA1LjU3IDQzMy42NTEgMzEyNC4yOCAzODIuMjM0IDMxMjQuMjggMzI1LjUzOEMzMTI0LjI4IDIwNy4yMyAzMDQ2LjA3IDEyNC42MDcgMjkzNC4xMSAxMjQuNjA3VjEyNC42NDNaTTI5MzQuMTEgNDQ2LjkwNUMyODczLjg4IDQ0Ni45MDUgMjgzMS44MiAzOTcuMzEgMjgzMS44MiAzMjYuMzM5QzI4MzEuODIgMjU1LjM2OSAyODczLjg4IDIwNS43NzMgMjkzNC4xMSAyMDUuNzczQzI5OTQuMzQgMjA1Ljc3MyAzMDM1LjY4IDI1NS4wNDEgMzAzNS42OCAzMjUuNjExQzMwMzUuNjggMzk2LjE4MSAyOTkzLjkxIDQ0Ni45NDIgMjkzNC4xMSA0NDYuOTQyVjQ0Ni45MDVaIiBmaWxsPSJ3aGl0ZSIvPgo8cGF0aCBkPSJNMTc3MS44MiAzMy43NTM4SDE2ODIuNDlWMTM2LjY1OUgxNjExLjg0VjIxNy43NTNIMTY4Mi40OVY1MTYuNzFIMTc3MS44MlYyMTcuNzUzSDE4NDMuMTZWMTM2LjY1OUgxNzcxLjgyVjMzLjc1MzhaIiBmaWxsPSJ3aGl0ZSIvPgo8cGF0aCBkPSJNNDA0OS44MiAxNzcuNjI2QzQwMTkuMDIgMTQyLjk2IDM5NzQuMDggMTI0LjY0NCAzOTE5Ljg4IDEyNC42NDRDMzgxMC41NCAxMjQuNjQ0IDM3MzQuMTUgMjA3Ljg4NSAzNzM0LjE1IDMyNy4wNjhDMzczNC4xNSA0NDYuMjUgMzgxMC41NCA1MjcuOTk5IDM5MTkuODggNTI3Ljk5OUMzOTk2LjMxIDUyNy45OTkgNDA1Ni4xNCA0OTAuNjc1IDQwODguMzYgNDIyLjg3Mkw0MDg5LjYzIDQyMC4xNzhMNDAwOS4wNiAzOTMuNzA1TDQwMDguMDUgMzk1LjU2MkMzOTg5LjIzIDQyOS42NDUgMzk1OS4yMiA0NDcuNjM0IDM5MjEuMzMgNDQ3LjYzNEMzODY5Ljc5IDQ0Ny42MzQgMzgzMC45MiA0MTAuODkyIDM4MjEuNjYgMzUzLjcyM0g0MDk0LjMyTDQwOTQuNzIgMzQ3Ljg5NkM0MDk1LjM3IDMzOC4yMSA0MDk1Ljk5IDMyOS4wMzQgNDA5NS45OSAzMTguODM4QzQwOTUuOTkgMjYwLjQ2NyA0MDgwLjAxIDIxMS42MzYgNDA0OS44MiAxNzcuNjYyVjE3Ny42MjZaTTM4MjQuOTYgMjgzLjE1M0MzODM4LjY2IDIzMy42NjYgMzg3My45MyAyMDQuMjQ0IDM5MTkuODUgMjA0LjI0NEMzOTY4LjA5IDIwNC4yNDQgMzk5OS45NCAyMzIuMjQ2IDQwMDkuNzkgMjgzLjE1M0gzODI0Ljk2WiIgZmlsbD0id2hpdGUiLz4KPHBhdGggZD0iTTU1NC41NDggNDQ5LjI3NEM1OTIuMTEgNDA2LjQ1MSA2MTEuMTgxIDM0Mi4zMjYgNjExLjE4MSAyNTguNjQ3VjI1OC4wMjhDNjExLjE4MSAxNzQuMzUgNTkyLjExIDExMC4xODggNTU0LjU0OCA2Ny40MDIzQzUxNi4yMjQgMjMuNzA1NyA0NzkuOTcxIDAuMDM2NzQzMiAzOTguMTI4IDAuMDM2NzQzMkgyMjIuMDkxQzIzMS41MzYgOS43OTU2NCAyNTMuNDQgMzIuNDgxNCAyNjAuNzQyIDM5Ljk4MjdDMjY0LjE5MyA0My41MTQ4IDI2Ni45OSA0Ni4yNDU4IDI2OS4xMzMgNDguMzIxNEwyNjkuNDI0IDQ4LjYxMjdDMjcwLjYyMyA0OS43NzggMjcxLjYwMyA1MC43MjQ3IDI3Mi4yOTQgNTEuNDg5NEMyNzMuMDU3IDUyLjI1NDEgMjczLjU2NSA1Mi44MDAzIDI3My44OTIgNTMuMDkxNkMyODguNDIzIDY3LjY5MzYgMzA1LjM1MSA3My41OTI2IDMzMi40NSA3My41OTI2QzMzMy40NjcgNzMuNTkyNiAzMzUuNDY1IDczLjU5MjYgMzM4LjIyNiA3My41OTI2QzM0NC43MjggNzMuNTU2MiAzNTcuNzMzIDczLjU5MjYgMzcxLjc1NSA3My41OTI2QzM4MC42NTUgNzMuNTkyNiAzODkuOTkxIDczLjU5MjYgMzk4LjM0NiA3My41OTI2QzQ3MC45MjUgNzMuNTkyNiA0OTIuNjEyIDExNi4zNDIgNDk2LjM1NCAxMjUuMjI3QzQ5OS45ODYgMTMwLjMyNSA1MDMuMDAyIDEzNi4wNzkgNTA1LjMyNiAxNDIuMzQyQzUxOC40NCAxNzcuMzcyIDUyNS4xNjEgMjE3LjUzNiA1MjQuNzk3IDI1OC40MjlDNTI1LjE2MSAyOTguNTkzIDUxOC40NCAzMzguNjg1IDUwNS4zMjYgMzc0LjI2MUM0ODIuNDc3IDQzNi4zMSA0MjQuNDY0IDQ0My4wMTEgNDAwLjU2MiA0NDMuMDExSDMzMi40NUMzMDYuMzMxIDQ0My4wMTEgMjgwLjg2NyA0NTQuOTU0IDI2MC43NDIgNDc2LjYyQzI1MS4xMTUgNDg2Ljk5OCAyMzEuNjgxIDUwNy40NjMgMjIzLjAzNSA1MTYuNTY2SDM5OC4wMTlDNDc5LjkzNCA1MTYuNTY2IDUxNi4yMjQgNDkyLjg5NyA1NTQuNTQ4IDQ0OS4yMzdWNDQ5LjI3NFoiIGZpbGw9IndoaXRlIi8+CjxwYXRoIGQ9Ik0zMzkuMTA1IDI1OC4zOTlDMzM5LjEwNSAyNTguMzk5IDMzOS4xMDUgMjU4LjM5OSAzMzkuMTA1IDI1OC4zNjJDMzM5LjEwNSAyNTguMzYyIDMzOS4xMDUgMjU4LjM2MiAzMzkuMTA1IDI1OC4zMjZDMzM5LjEwNSAyNTguMzI2IDMzOS4xMDUgMjU4LjMyNiAzMzkuMTA1IDI1OC4yODlDMzM5Ljc1OSAyMjAuMjM3IDMzMi40NTggMTg2LjcgMzI2LjYwOSAxNjguMzExQzMxOS40MTcgMTQ1LjYyNSAzMTIuMjk3IDEzNy4wNjggMzEwLjA0NCAxMzQuMTkxQzI3NS4yMDggODkuMTEwOSAyMzQuODg1IDEwOC41NTYgMjAwLjM3NSA4NC45OTYxQzE2NS45MDIgNjEuNDcyOCAxNjAuMTI2IDQzLjYzMDEgMTQ3Ljg0OCAzMS4xNDAxQzE0NS43NDEgMjguOTkxNyAxNDEuMDkxIDI0LjI1NzkgMTMzLjg5OCAxOS4zMDU2QzEzMy44OTggMTkuMzA1NiAxMjIuNjM3IDExLjU0OTUgMTA2Ljk4MSA2LjY3MDA1QzkwLjAxNjQgMS4zMTcyMyAzOC44NjkxIC0wLjA2NjQ5NzIgMCAwLjA0Mjc0NDFWNzguMjIzMkgxMTUuOTE3QzEyOS43OTQgNzcuOTMxOCAxNjMuNTQxIDc5LjI0MjcgMTkzLjI5MiAxMDIuNzNDMjA4LjgzOSAxMTUuMDAxIDIxNy4wNDkgMTI4LjM2NSAyMjIuMDk5IDEzNi43MDRDMjQ2LjAwMSAxNzYuMzk1IDI0Ni43MjggMjI0LjY0MyAyNDcuMiAyNTguMjE3VjI1OC4zOTlDMjQ2LjcyOCAyOTEuOTcyIDI0Ni4wMDEgMzQwLjIyIDIyMi4wOTkgMzc5LjkxMUMyMTcuMDg2IDM4OC4yNSAyMDguODM5IDQwMS42NSAxOTMuMjkyIDQxMy44ODZDMTYzLjUwNCA0MzcuMzcyIDEyOS43OTQgNDM4LjY4MyAxMTUuOTE3IDQzOC4zOTJIMFY1MTYuNTcyQzM4Ljg2OTEgNTE2LjcxOCA5MC4wMTY0IDUxNS4yOTggMTA2Ljk4MSA1MDkuOTgxQzEyMi42MzcgNTA1LjA2NiAxMzMuODk4IDQ5Ny4zNDYgMTMzLjg5OCA0OTcuMzQ2QzE0MS4wOTEgNDkyLjM5NCAxNDUuNzQxIDQ4Ny42NiAxNDcuODQ4IDQ4NS41MTFDMTYwLjEyNiA0NzMuMDIxIDE2NS45MDIgNDU1LjIxNSAyMDAuMzc1IDQzMS42NTVDMjM0Ljg0OSA0MDguMTMyIDI3NS4yMDggNDI3LjU3NyAzMTAuMDQ0IDM4Mi40NkMzMTIuMjk3IDM3OS41ODQgMzE5LjQxNyAzNzEuMDI2IDMyNi42MDkgMzQ4LjM0MUMzMzIuNDIxIDMyOS45NTIgMzM5Ljc1OSAyOTYuNDE1IDMzOS4xMDUgMjU4LjM2MlYyNTguMzk5WiIgZmlsbD0id2hpdGUiLz4KPHBhdGggZD0iTTI3MTUuMzkgMjU4LjM5MkMyNzEzLjQ3IDk4Ljc1NDIgMjY1Mi44OCAwIDI0NjQuNzQgMEgyMzEyLjA2SDIzMTIuMUwyMjg0LjE2IDAuMDM2NDEzOFYyNTguMzkyVjUxNi43NDhIMjMxMi4xSDIzMTIuMDZMMjQ2NC43NCA1MTYuNzg0QzI2NTIuODggNTE2Ljc4NCAyNzEzLjQ3IDQxOC4wMyAyNzE1LjM5IDI1OC4zOTJaTTI0NjUuNDcgNDMxLjE3NkgyMzc3Ljg5VjI1OC4zOTJWODUuNjA4OEgyNDY1LjQ3QzI0OTEuNTUgODUuOTM2NSAyNTQ1Ljg5IDg1LjQyNjggMjU3Ny41MyAxMTkuNzI5QzI2MDQuNjMgMTQ5LjA3OCAyNjEzLjQzIDIwNS43NzQgMjYxNC41OSAyNTguMzkyQzI2MTQuNTkgMzE4LjAwMiAyNjA0LjYgMzY3LjcwNiAyNTc3LjUzIDM5Ny4wNTZDMjU0NS44OSA0MzEuMzU4IDI0OTEuNTUgNDMwLjg0OCAyNDY1LjQ3IDQzMS4xNzZaIiBmaWxsPSJ3aGl0ZSIvPgo8cGF0aCBkPSJNMTE3Mi4xOCAyNTguMzkyQzExNzAuMjEgOTguNzU0MiAxMTA5LjY2IDAgOTIxLjQ4OCAwSDc2OC44MDlINzY4Ljg0NUw3NDAuOTEgMC4wMzY0MTM4VjI1OC4zOTJWNTE2Ljc0OEg3NjguODQ1SDc2OC44MDlMOTIxLjQ4OCA1MTYuNzg0QzExMDkuNjIgNTE2Ljc4NCAxMTcwLjIxIDQxOC4wMyAxMTcyLjE0IDI1OC4zOTJIMTE3Mi4xOFpNOTIyLjI1MSA0MzEuMTc2SDgzNC42NjhWMjU4LjM5MlY4NS42MDg4SDkyMi4yNTFDOTQ4LjMzMyA4NS45MzY1IDEwMDIuNjggODUuNDI2OCAxMDM0LjMyIDExOS43MjlDMTA2MS40MiAxNDkuMDc4IDEwNzAuMjEgMjA1Ljc3NCAxMDcxLjM3IDI1OC4zOTJDMTA3MS4zNyAzMTguMDAyIDEwNjEuMzggMzY3LjcwNiAxMDM0LjMyIDM5Ny4wNTZDMTAwMi42OCA0MzEuMzU4IDk0OC4zMzMgNDMwLjg0OCA5MjIuMjUxIDQzMS4xNzZaIiBmaWxsPSJ3aGl0ZSIvPgo8cGF0aCBkPSJNMzU3Ny42NSAxMjYuNjQ4QzM1MjguMjEgMTI2LjY0OCAzNDg3LjIgMTUwLjc5IDM0NjIuMjEgMTk0LjYzM0MzNDYxLjA4IDE5Ni41OTkgMzQ1Ny44NSAxOTYuMzA4IDM0NTcuMDUgMTk0LjE5NkMzNDQwLjc0IDE1MC42NDUgMzQwMy45MSAxMjYuNjg0IDMzNTMuMyAxMjYuNjg0QzMzMDguOTkgMTI2LjY4NCAzMjcyLjg0IDE0Ny42OTUgMzI0OC43NiAxODcuNDk1QzMyNDcuNzggMTg5LjA5OCAzMjQ1Ljg5IDE4OS44MjYgMzI0NC4xNCAxODkuMjQzQzMyNDIuNTQgMTg4LjY5NyAzMjQxLjQ1IDE4Ny4yMDQgMzI0MS40NSAxODUuNTI5VjEzNS43NTFIMzE1My40NFY1MTguNjc5SDMyNDIuOTRWMjk2Ljg0NkMzMjQyLjk0IDI0NC4xNTUgMzI3My43NSAyMDcuMzc3IDMzMTcuODkgMjA3LjM3N0MzMzYyLjAyIDIwNy4zNzcgMzM4Ni4wNyAyNDAuMjU5IDMzODYuMDcgMjk1LjM1M1Y1MTguNjc5SDM0NzQuODVWMjgyLjM1M0MzNDc0Ljg1IDI0MS41MzMgMzUwNy4yNSAyMDcuODg3IDM1NDcuMDcgMjA3LjM3N0MzNTY2LjU0IDIwNy4wODYgMzU4Mi41MiAyMTIuODc2IDM1OTQuMjYgMjI0LjQ5MkMzNjA5LjI5IDIzOS4zNDkgMzYxNy4yMSAyNjMuODU1IDM2MTcuMjEgMjk1LjM1M1Y1MTguNjc5SDM3MDYuNzJWMjgwLjI0MUMzNzA2LjcyIDE4MS4yMzIgMzY2MC44OCAxMjYuNjg0IDM1NzcuNjUgMTI2LjY4NFYxMjYuNjQ4WiIgZmlsbD0id2hpdGUiLz4KPHBhdGggZD0iTTE0OTAuMTQgMTM2LjA3OFYxMzcuOTM1QzE0OTAuMTQgMTQ4Ljg5NiAxNDkwLjE0IDE1Ni44MzQgMTQ5MC4xNCAxNjQuNzM2VjE4NS45MjlDMTQ5MC4xNCAxODcuODk1IDE0ODguNjUgMTg5LjUzNCAxNDg2LjcyIDE4OS42MDdDMTQ4NS40MiAxODkuNjQzIDE0ODQuMjkgMTg5LjAyNCAxNDgzLjYgMTg3Ljk2OEMxNDU3LjIzIDE0Ny40NzYgMTQyMC4xNyAxMjcuODEyIDEzNzAuMzMgMTI3LjgxMkMxMjcxLjA5IDEyNy44MTIgMTIwMS43NCAyMDkuNTYxIDEyMDEuNzQgMzI2LjU5NUMxMjAxLjc0IDQ0My42MjkgMTI3MS4wOSA1MjUuMzc4IDEzNzAuMzMgNTI1LjM3OEMxNDIwLjE0IDUyNS4zNzggMTQ1Ny4xOSA1MDUuNzE1IDE0ODMuNiA0NjUuMjIzQzE0ODQuMjkgNDY0LjE2NyAxNDg1LjQyIDQ2My41MTEgMTQ4Ni43MiA0NjMuNTg0QzE0ODguNjUgNDYzLjY1NyAxNDkwLjE3IDQ2NS4yOTUgMTQ5MC4xNCA0NjcuMjYyVjQ4OC40NTVDMTQ5MC4xIDQ5Ni4zNTYgMTQ5MC4wNyA1MDQuMjk1IDE0OTAuMDcgNTE1LjI1NVY1MTcuMTEySDE1NzYuN1YzMjYuNjMyVjEzNi4xMTVIMTQ5MC4wN0wxNDkwLjE0IDEzNi4wNzhaTTE0OTEuNjMgMzI2LjU5NUMxNDkxLjYzIDMyNi44NSAxNDkxLjYzIDMyNy4wNjkgMTQ5MS42MyAzMjcuMzI0QzE0OTEuNjMgMzk4LjAwMyAxNDUwLjM2IDQ0NS40ODYgMTM4OC45MyA0NDUuNDg2QzEzMjcuNTEgNDQ1LjQ4NiAxMjg5LjIyIDM5Ni41ODMgMTI4OS4yMiAzMjYuNTk1QzEyODkuMjIgMjU2LjYwOCAxMzMwLjIzIDIwNy43MDQgMTM4OC45MyAyMDcuNzA0QzE0NDcuNjQgMjA3LjcwNCAxNDkxLjYzIDI1NS4xODggMTQ5MS42MyAzMjUuODY3QzE0OTEuNjMgMzI2LjEyMiAxNDkxLjYzIDMyNi4zNCAxNDkxLjYzIDMyNi41OTVaIiBmaWxsPSJ3aGl0ZSIvPgo8cGF0aCBkPSJNMjE0NC44OCAxMzYuMDc4VjEzNy45MzVDMjE0NC44OCAxNDguODk2IDIxNDQuODggMTU2LjgzNCAyMTQ0Ljg4IDE2NC43MzZWMTg1LjkyOUMyMTQ0Ljg4IDE4Ny44OTUgMjE0My4zOSAxODkuNTM0IDIxNDEuNDcgMTg5LjYwN0MyMTQwLjE2IDE4OS42NDMgMjEzOS4wMyAxODkuMDI0IDIxMzguMzQgMTg3Ljk2OEMyMTExLjk3IDE0Ny40NzYgMjA3NC45MiAxMjcuODEyIDIwMjUuMDggMTI3LjgxMkMxOTI1LjgzIDEyNy44MTIgMTg1Ni40OSAyMDkuNTYxIDE4NTYuNDkgMzI2LjU5NUMxODU2LjQ5IDQ0My42MjkgMTkyNS44MyA1MjUuMzc4IDIwMjUuMDggNTI1LjM3OEMyMDc0Ljg4IDUyNS4zNzggMjExMS45MyA1MDUuNzE1IDIxMzguMzQgNDY1LjIyM0MyMTM5LjAzIDQ2NC4xNjcgMjE0MC4xNiA0NjMuNTExIDIxNDEuNDcgNDYzLjU4NEMyMTQzLjM5IDQ2My42NTcgMjE0NC45MiA0NjUuMjk1IDIxNDQuODggNDY3LjI2MlY0ODguNDU1QzIxNDQuODUgNDk2LjM1NiAyMTQ0LjgxIDUwNC4yOTUgMjE0NC44MSA1MTUuMjU1VjUxNy4xMTJIMjIzMS40NVYzMjYuNjMyVjEzNi4xMTVIMjE0NC44MUwyMTQ0Ljg4IDEzNi4wNzhaTTIxNDYuMzQgMzI2LjU5NUMyMTQ2LjM0IDMyNi44NSAyMTQ2LjM0IDMyNy4wNjkgMjE0Ni4zNCAzMjcuMzI0QzIxNDYuMzQgMzk4LjAwMyAyMTA1LjA3IDQ0NS40ODYgMjA0My42NCA0NDUuNDg2QzE5ODIuMjEgNDQ1LjQ4NiAxOTQzLjkzIDM5Ni41ODMgMTk0My45MyAzMjYuNTk1QzE5NDMuOTMgMjU2LjYwOCAxOTg0Ljk0IDIwNy43MDQgMjA0My42NCAyMDcuNzA0QzIxMDIuMzQgMjA3LjcwNCAyMTQ2LjM0IDI1NS4xODggMjE0Ni4zNCAzMjUuODY3QzIxNDYuMzQgMzI2LjEyMiAyMTQ2LjM0IDMyNi4zNCAyMTQ2LjM0IDMyNi41OTVaIiBmaWxsPSJ3aGl0ZSIvPgo8L2c+CjxkZWZzPgo8Y2xpcFBhdGggaWQ9ImNsaXAwXzNfNjciPgo8cmVjdCB3aWR0aD0iNDA5NiIgaGVpZ2h0PSI1MjgiIGZpbGw9IndoaXRlIi8+CjwvY2xpcFBhdGg+CjwvZGVmcz4KPC9zdmc+Cg==" x="150" y="309" width="80" height="10"/>
              <image href="data:image/svg+xml;base64,PHN2ZyB2ZXJzaW9uPSIxLjEiIGlkPSJMYXllcl8xIiB4bWxuczp4PSJuc19leHRlbmQ7IiB4bWxuczppPSJuc19haTsiIHhtbG5zOmdyYXBoPSJuc19ncmFwaHM7IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB4PSIwcHgiIHk9IjBweCIgdmlld0JveD0iMCAwIDMyNiA4OCIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzI2IDg4OyIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSI+CiA8c3R5bGU+CiAgLnN0MHtmaWxsOndoaXRlO30KIDwvc3R5bGU+CiA8bWV0YWRhdGE+CiAgPHNmdyB4bWxucz0ibnNfc2Z3OyI+CiAgIDxzbGljZXM+CiAgIDwvc2xpY2VzPgogICA8c2xpY2VTb3VyY2VCb3VuZHMgYm90dG9tTGVmdE9yaWdpbj0idHJ1ZSIgaGVpZ2h0PSI4OCIgd2lkdGg9IjMyNiIgeD0iLTE3Ny44IiB5PSIwIj4KICAgPC9zbGljZVNvdXJjZUJvdW5kcz4KICA8L3Nmdz4KIDwvbWV0YWRhdGE+CiA8Zz4KICA8cGF0aCBjbGFzcz0ic3QwIiBkPSJNMTMuNCwwSDYuN0gwdjEzLjVoMTMuNFYweiBNMzI1LjksNzQuNWgtNi43aC02LjdWODhoMTMuNFY3NC41eiI+CiAgPC9wYXRoPgogIDxwYXRoIGNsYXNzPSJzdDAiIGQ9Ik0xMy40LDY4LjJIMFYxOS44aDYuN2g2LjdWNjguMnogTTc1LDE4LjhjOS45LDAsMTUuOCw2LjksMTUuOCwxNy45djMxLjVINzcuNVYzOS40YzAtNS4yLTIuMy04LjYtNi45LTguNgoJCWMtMy41LDAtNi42LDIuMi03LjQsNi4zdjMxLjJINDkuN1YzOS40YzAtNS4yLTIuMi04LjYtNi44LTguNmMtMy41LDAtNi43LDIuMi03LjUsNi4zdjMxLjJIMjIuMVYxOS44aDEzLjR2NAoJCWMyLjQtMyw2LjgtNS4xLDEyLjEtNS4xYzUuNywwLDEwLjMsMi42LDEyLjksNi4yQzYzLjYsMjEuNCw2OC4yLDE4LjgsNzUsMTguOHogTTExMi44LDg4SDk5LjRWMTkuOGgxMy40djRjMi4yLTIuNiw2LjktNS4xLDEyLTUuMQoJCWMxNCwwLDIxLjksMTEuNywyMS45LDI1LjNzLTgsMjUuMi0yMS45LDI1LjJjLTUuMiwwLTkuOS0yLjUtMTItNS4xVjg4eiBNMTEyLjgsNTJjMS42LDMuMyw1LjIsNS42LDksNS42YzcuMiwwLDExLjUtNS45LDExLjUtMTMuNQoJCWMwLTcuOC00LjMtMTMuNi0xMS41LTEzLjZjLTQsMC03LjQsMi40LTksNS42VjUyeiBNMTY0LjYsNDcuMWMxLDcuOSw2LjgsMTEuMiwxMy44LDExLjJjNS4zLDAsOS0xLjIsMTMuNy00LjN2MTEuMQoJCWMtNCwyLjktOS4zLDQuMy0xNS44LDQuM2MtMTQuNiwwLTI0LjctOS42LTI0LjctMjQuOWMwLTE1LjIsOS41LTI1LjcsMjIuNi0yNS43YzE0LDAsMjEuMiw5LjgsMjEuMiwyNC4xdjQuNEwxNjQuNiw0Ny4xCgkJTDE2NC42LDQ3LjF6IE0xNjUuMSwzOC40aDE4LjJjLTAuMy01LjItMy4yLTguOS04LjUtOC45QzE3MC40LDI5LjUsMTY2LjYsMzIuMywxNjUuMSwzOC40eiBNMjMxLjksMzMuMWMtMS44LTEtNC4yLTEuNi02LjctMS42CgkJYy00LjUsMC04LjIsMi40LTkuMSw2Ljh2MjkuOWgtMTMuNFYxOS44aDEzLjR2NC43YzIuMS0zLjUsNi01LjksMTAuNy01LjljMi4zLDAsNC4zLDAuNSw1LjEsMC45VjMzLjF6IE0yNTIuNyw2OC4ybC0xOC4yLTQ4LjQKCQloMTMuOWwxMS4xLDMyLjFsMTAuOC0zMi4xaDEzLjVsLTE4LjMsNDguNEgyNTIuN3ogTTMxMi43LDM4YzAtNC42LTQtNy42LTEwLjctNy42Yy00LjgsMC05LjMsMS40LTEzLjEsMy45VjIyLjcKCQljMy41LTIuMiw5LjctNCwxNi00YzEzLjMsMCwyMS4yLDYuOCwyMS4yLDE4Ljd2MzAuOGgtMTMuNHYtMi42Yy0xLjYsMS42LTYuMywzLjUtMTEuNiwzLjVjLTkuNywwLTE3LjgtNS42LTE3LjgtMTUuNwoJCWMwLTkuMiw4LjEtMTUuNCwxOC42LTE1LjRjNC4yLDAsOC44LDEuNCwxMC43LDIuOFYzOHogTTMxMi43LDUxLjVjLTEuMi0yLjYtNC43LTQuMy04LjUtNC4zYy00LjIsMC04LjUsMS44LTguNSw2CgkJYzAsNC4zLDQuMyw2LDguNSw2YzMuOCwwLDcuMy0xLjYsOC41LTQuM1Y1MS41eiI+CiAgPC9wYXRoPgogPC9nPgo8L3N2Zz4="     x="245" y="304" width="76" height="20"/>
              <image href="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAxMDkuMjEgMzYiPgogICAgICAgICAgPHBhdGggZD0iTTk4Ljk3LDIzLjY3Yy0zLjA1LDAtNS4yLTIuMzgtNS4yLTUuNTFzMi4xNS01LjUxLDUuMi01LjUxLDUuMTQsMi4zOCw1LjE0LDUuNTEtMi4xMiw1LjUxLTUuMTQsNS41MVptLS40OSwzLjI4YzIuNDYsMCw0LjU1LS45Niw1Ljg3LTIuOTcsLjI1LDEuOTUsMS42NiwyLjY2LDMuNDQsMi42NmgxLjQydi0zLjA5aC0uNjFjLTEuMDEsMC0xLjI2LS40OS0xLjI2LTEuNjRWOS42OWgtMy4yNnYyLjUxYy0xLjExLTEuNzYtMy4yLTIuODItNS42LTIuODItNC4yOCwwLTguMjEsMy41OS04LjIxLDguNzhzMy45NCw4Ljc4LDguMjEsOC43OFptLTE2Ljc5LTQuMjRjMCwyLjc4LDEuNzIsMy45MywzLjc4LDMuOTNoMy45N3YtMy4wOWgtMi44OWMtMS4yLDAtMS40NS0uNDYtMS40NS0xLjY0VjEyLjc4aDQuMzR2LTMuMDloLTQuMzRWNGgtMy40MVYyMi43MVptLTE1LjUzLDMuOTNoMy40MXYtNy4yN2gxLjE0bDUuODEsNy4yN2g0LjMxbC03LjQxLTkuMjIsNS42OS03LjczaC0zLjg0bC00LjY1LDYuNTNoLTEuMDVWNGgtMy40MVYyNi42NFptLTExLjA3LTE3LjI2Yy00Ljc3LDAtOC43LDMuNTktOC43LDguNzhzMy45NCw4Ljc4LDguNyw4Ljc4LDguNy0zLjU5LDguNy04Ljc4LTMuOTQtOC43OC04LjctOC43OFptMCwxNC4yOWMtMy4wNSwwLTUuMi0yLjM4LTUuMi01LjUxczIuMTUtNS41MSw1LjItNS41MSw1LjIsMi4zOCw1LjIsNS41MS0yLjE1LDUuNTEtNS4yLDUuNTFaIiBmaWxsPSJ3aGl0ZSI+PC9wYXRoPgogICAgICAgICAgPHBhdGggZD0iTTE5LjgsLjI2bC0uNzQsOS4xMmMtLjM1LS4wNC0uNy0uMDYtMS4wNi0uMDYtLjQ1LDAtLjg5LC4wMy0xLjMyLC4xbC0uNDItNC40MmMtLjAxLS4xNCwuMS0uMjYsLjI0LS4yNmguNzVsLS4zNi00LjQ3Yy0uMDEtLjE0LC4xLS4yNiwuMjMtLjI2aDIuNDVjLjE0LDAsLjI1LC4xMiwuMjMsLjI2aDBabS02LjE4LC40NWMtLjA0LS4xMy0uMTgtLjIxLS4zMS0uMTZsLTIuMywuODRjLS4xMywuMDUtLjE5LC4yLS4xMywuMzJsMS44Nyw0LjA4LS43MSwuMjZjLS4xMywuMDUtLjE5LC4yLS4xMywuMzJsMS45MSw0LjAxYy42OS0uMzgsMS40NC0uNjcsMi4yMy0uODVMMTMuNjMsLjcxWk03Ljk4LDMuMjVsNS4yOSw3LjQ2Yy0uNjcsLjQ0LTEuMjgsLjk2LTEuOCwxLjU2bC0zLjE3LTMuMTJjLS4xLS4xLS4wOS0uMjYsLjAxLS4zNWwuNTgtLjQ4LTMuMTUtMy4xOWMtLjEtLjEtLjA5LS4yNiwuMDItLjM1bDEuODctMS41N2MuMTEtLjA5LC4yNi0uMDcsLjM0LC4wNFpNMy41NCw3LjU3Yy0uMTEtLjA4LS4yNy0uMDQtLjM0LC4wOGwtMS4yMiwyLjEyYy0uMDcsLjEyLS4wMiwuMjcsLjEsLjMzbDQuMDYsMS45Mi0uMzgsLjY1Yy0uMDcsLjEyLS4wMiwuMjgsLjExLC4zM2w0LjA0LDEuODVjLjI5LS43NSwuNjgtMS40NSwxLjE2LTIuMDhMMy41NCw3LjU3Wk0uNTUsMTMuMzNjLjAyLS4xNCwuMTYtLjIyLC4yOS0uMTlsOC44NSwyLjMxYy0uMjMsLjc1LS4zNiwxLjU0LS4zOCwyLjM2bC00LjQzLS4zNmMtLjE0LS4wMS0uMjQtLjE0LS4yMS0uMjhsLjEzLS43NC00LjQ3LS40MmMtLjE0LS4wMS0uMjMtLjE0LS4yMS0uMjhsLjQyLTIuNDFoMFptLS4zMyw1Ljk4Yy0uMTQsLjAxLS4yMywuMTQtLjIxLC4yOGwuNDMsMi40MWMuMDIsLjE0LC4xNiwuMjIsLjI5LC4xOWw0LjM0LTEuMTMsLjEzLC43NGMuMDIsLjE0LC4xNiwuMjIsLjI5LC4xOWw0LjI4LTEuMThjLS4yNS0uNzQtLjQxLTEuNTMtLjQ1LTIuMzRMLjIxLDE5LjMxWm0xLjQyLDYuMzRjLS4wNy0uMTItLjAyLS4yNywuMS0uMzNsOC4yNi0zLjkyYy4zMSwuNzQsLjczLDEuNDMsMS4yMywyLjA1bC0zLjYyLDIuNThjLS4xMSwuMDgtLjI3LC4wNS0uMzQtLjA3bC0uMzgtLjY2LTMuNjksMi41NWMtLjExLC4wOC0uMjcsLjA0LS4zNC0uMDhsLTEuMjMtMi4xMlptMTAuMDEtMS43MmwtNi40Myw2LjUxYy0uMSwuMS0uMDksLjI2LC4wMiwuMzVsMS44OCwxLjU3Yy4xMSwuMDksLjI2LC4wNywuMzQtLjA0bDIuNi0zLjY2LC41OCwuNDljLjExLC4wOSwuMjcsLjA3LC4zNS0uMDVsMi41Mi0zLjY2Yy0uNjgtLjQyLTEuMzEtLjkzLTEuODUtMS41MVptLTEuMjcsMTAuNDVjLS4xMy0uMDUtLjE5LS4yLS4xMy0uMzJsMy44MS04LjMyYy43LC4zNiwxLjQ2LC42MywyLjI1LC43OGwtMS4xMiw0LjNjLS4wMywuMTMtLjE4LC4yMS0uMzEsLjE2bC0uNzEtLjI2LTEuMTksNC4zM2MtLjA0LC4xMy0uMTgsLjIxLS4zMSwuMTZsLTIuMy0uODRoMFptNi41Ni03Ljc1bC0uNzQsOS4xMmMtLjAxLC4xNCwuMSwuMjYsLjIzLC4yNmgyLjQ1Yy4xNCwwLC4yNS0uMTIsLjIzLS4yNmwtLjM2LTQuNDdoLjc1Yy4xNCwwLC4yNS0uMTIsLjI0LS4yNmwtLjQyLTQuNDJjLS40MywuMDctLjg3LC4xLTEuMzIsLjEtLjM2LDAtLjcxLS4wMi0xLjA2LS4wN2gwWk0yNS43NiwxLjk0Yy4wNi0uMTMsMC0uMjctLjEzLS4zMmwtMi4zLS44NGMtLjEzLS4wNS0uMjcsLjAzLS4zMSwuMTZsLTEuMTksNC4zMy0uNzEtLjI2Yy0uMTMtLjA1LS4yNywuMDMtLjMxLC4xNmwtMS4xMiw0LjNjLjgsLjE2LDEuNTUsLjQzLDIuMjUsLjc4TDI1Ljc2LDEuOTRoMFptNS4wMiwzLjYzbC02LjQzLDYuNTFjLS41NC0uNTgtMS4xNi0xLjA5LTEuODUtMS41MWwyLjUyLTMuNjZjLjA4LS4xMSwuMjQtLjE0LC4zNS0uMDVsLjU4LC40OSwyLjYtMy42NmMuMDgtLjExLC4yNC0uMTMsLjM0LS4wNGwxLjg4LDEuNTdjLjExLC4wOSwuMTEsLjI1LC4wMiwuMzVabTMuNDgsNS4xMmMuMTMtLjA2LC4xNy0uMjEsLjEtLjMzbC0xLjIzLTIuMTJjLS4wNy0uMTItLjIzLS4xNS0uMzQtLjA4bC0zLjY5LDIuNTUtLjM4LS42NWMtLjA3LS4xMi0uMjMtLjE2LS4zNC0uMDdsLTMuNjIsMi41OGMuNSwuNjIsLjkxLDEuMzEsMS4yMywyLjA1bDguMjYtMy45MlptMS4zLDMuMzJsLjQyLDIuNDFjLjAyLC4xNC0uMDcsLjI2LS4yMSwuMjhsLTkuMTEsLjg1Yy0uMDQtLjgyLS4yLTEuNi0uNDUtMi4zNGw0LjI4LTEuMThjLjEzLS4wNCwuMjcsLjA1LC4yOSwuMTlsLjEzLC43NCw0LjM0LTEuMTNjLjEzLS4wMywuMjcsLjA1LC4yOSwuMTloMFptLS40MSw4Ljg1Yy4xMywuMDMsLjI3LS4wNSwuMjktLjE5bC40Mi0yLjQxYy4wMi0uMTQtLjA3LS4yNi0uMjEtLjI4bC00LjQ3LS40MiwuMTMtLjc0Yy4wMi0uMTQtLjA3LS4yNi0uMjEtLjI4bC00LjQzLS4zNmMtLjAyLC44Mi0uMTUsMS42MS0uMzgsMi4zNmw4Ljg1LDIuMzFoMFptLTIuMzYsNS41Yy0uMDcsLjEyLS4yMywuMTUtLjM0LC4wOGwtNy41My01LjJjLjQ4LS42MywuODctMS4zMywxLjE2LTIuMDhsNC4wNCwxLjg1Yy4xMywuMDYsLjE4LC4yMSwuMTEsLjMzbC0uMzgsLjY1LDQuMDYsMS45MmMuMTIsLjA2LC4xNywuMjEsLjEsLjMzbC0xLjIyLDIuMTJoMFptLTEwLjA3LTMuMDdsNS4yOSw3LjQ2Yy4wOCwuMTEsLjI0LC4xMywuMzQsLjA0bDEuODctMS41N2MuMTEtLjA5LC4xMS0uMjUsLjAyLS4zNWwtMy4xNS0zLjE5LC41OC0uNDhjLjExLS4wOSwuMTEtLjI1LC4wMS0uMzVsLTMuMTctMy4xMmMtLjUzLC42LTEuMTMsMS4xMy0xLjgsMS41NmgwWm0tLjA1LDEwLjE2Yy0uMTMsLjA1LS4yNy0uMDMtLjMxLS4xNmwtMi40Mi04LjgyYy43OS0uMTgsMS41NC0uNDcsMi4yMy0uODVsMS45MSw0LjAxYy4wNiwuMTMsMCwuMjgtLjEzLC4zMmwtLjcxLC4yNiwxLjg3LDQuMDhjLjA2LC4xMywwLC4yNy0uMTMsLjMybC0yLjMsLjg0aDBaIiBmaWxsPSJ3aGl0ZSIgZmlsbC1ydWxlPSJldmVub2RkIj48L3BhdGg+CiAgICAgICAgPC9zdmc+"         x="340" y="302" width="72" height="24"/>
              <image href="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+CjwhLS0gR2VuZXJhdG9yOiBBZG9iZSBJbGx1c3RyYXRvciAxOS4wLjAsIFNWRyBFeHBvcnQgUGx1Zy1JbiAuIFNWRyBWZXJzaW9uOiA2LjAwIEJ1aWxkIDApICAtLT4KCjxzdmcKICAgdmVyc2lvbj0iMS4xIgogICBpZD0ibGF5ZXIiCiAgIHg9IjBweCIKICAgeT0iMHB4IgogICB2aWV3Qm94PSItMTUzIC00NiAyMjM1LjQ0NjUgNzIwIgogICB4bWw6c3BhY2U9InByZXNlcnZlIgogICBzb2RpcG9kaTpkb2NuYW1lPSJhdXRoMC1pbmMtbG9nby12ZWN0b3Iuc3ZnIgogICB3aWR0aD0iMjIzNS40NDY1IgogICBoZWlnaHQ9IjcyMCIKICAgaW5rc2NhcGU6dmVyc2lvbj0iMS4xIChjNjhlMjJjMzg3LCAyMDIxLTA1LTIzKSIKICAgeG1sbnM6aW5rc2NhcGU9Imh0dHA6Ly93d3cuaW5rc2NhcGUub3JnL25hbWVzcGFjZXMvaW5rc2NhcGUiCiAgIHhtbG5zOnNvZGlwb2RpPSJodHRwOi8vc29kaXBvZGkuc291cmNlZm9yZ2UubmV0L0RURC9zb2RpcG9kaS0wLmR0ZCIKICAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogICB4bWxuczpzdmc9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZGVmcwogICBpZD0iZGVmczExIiAvPjxzb2RpcG9kaTpuYW1lZHZpZXcKICAgaWQ9Im5hbWVkdmlldzkiCiAgIHBhZ2Vjb2xvcj0iI2ZmZmZmZiIKICAgYm9yZGVyY29sb3I9IiM2NjY2NjYiCiAgIGJvcmRlcm9wYWNpdHk9IjEuMCIKICAgaW5rc2NhcGU6cGFnZXNoYWRvdz0iMiIKICAgaW5rc2NhcGU6cGFnZW9wYWNpdHk9IjAuMCIKICAgaW5rc2NhcGU6cGFnZWNoZWNrZXJib2FyZD0iMCIKICAgc2hvd2dyaWQ9ImZhbHNlIgogICBmaXQtbWFyZ2luLXRvcD0iMCIKICAgZml0LW1hcmdpbi1sZWZ0PSIwIgogICBmaXQtbWFyZ2luLXJpZ2h0PSIwIgogICBmaXQtbWFyZ2luLWJvdHRvbT0iMCIKICAgaW5rc2NhcGU6em9vbT0iMC4zMTkwMTg0MSIKICAgaW5rc2NhcGU6Y3g9IjczNS4wNjczMSIKICAgaW5rc2NhcGU6Y3k9IjM2Mi4wNDgwOCIKICAgaW5rc2NhcGU6d2luZG93LXdpZHRoPSIxOTIwIgogICBpbmtzY2FwZTp3aW5kb3ctaGVpZ2h0PSIxMDE3IgogICBpbmtzY2FwZTp3aW5kb3cteD0iMTkxMiIKICAgaW5rc2NhcGU6d2luZG93LXk9Ii04IgogICBpbmtzY2FwZTp3aW5kb3ctbWF4aW1pemVkPSIxIgogICBpbmtzY2FwZTpjdXJyZW50LWxheWVyPSJsYXllciIgLz4KPHN0eWxlPgoJLnN0MHtmaWxsOndoaXRlO30KPC9zdHlsZT4KPHBhdGgKICAgY2xhc3M9InN0MCIKICAgZD0iTSAzNjAuMzM0ODQsNTM2LjQ4NDQ3IDI4OC4wMzY3LDMxNCA0NzcuMzUzNDcsMTc2LjQ4NDQ3IGMgNDYuNTgzODYsMTQyLjczMjkyIDAsMjc1LjAzMTA2IC0xMTcuMDE4NjMsMzYwIHogbSAxMTcuMDE4NjMsLTM2MCBMIDQwNS4wNTUzNCwtNDYgSCAxNzEuMDE4MDcgbCA3MS45MjU0NywyMjIuNDg0NDcgYyAwLDAgMjM0LjQwOTkzLDAgMjM0LjQwOTkzLDAgeiBNIDE3MS4wMTgwNywtNDYgSCAtNjMuMDE5MjAyIEwgLTEzNC45NDQ2NiwxNzYuNDg0NDcgSCA5OS4wOTI1OTUgWiBtIC0zMDYuMzM1NCwyMjIuNDg0NDcgYyAtNDYuMjExMTgsMTQyLjczMjkyIDAsMjc1LjAzMTA2IDExNy4wMTg2MjUsMzYwIEwgNTMuNjI2NzYxLDMxNCBaIG0gMTE3LjAxODYyNSwzNjAgTCAxNzEuMDE4MDcsNjc0IDM2MC4zMzQ4NCw1MzYuNDg0NDcgMTcxLjAxODA3LDM5OC45Njg5NCBaIgogICBpZD0icGF0aDQiCiAgIHN0eWxlPSJzdHJva2Utd2lkdGg6My43MjY3MSIgLz4KPHBhdGgKICAgZD0ibSA4MjQuNjgyNjcsODguOTA2ODMgYyAtMzAuMTg2MzQsMCAtNTYuNjQ1OTcsMTkuNzUxNTYgLTY1LjIxNzM5LDQ4LjgxOTg4IEwgNjU1Ljg2Mjc5LDQ5NCBoIDY4LjE5ODc2IGwgMzAuNTU5LC0xMDMuMjI5ODEgYyAwLjM3MjY4LC0xLjExODAyIDEuMTE4MDIsLTEuODYzMzYgMi4yMzYwMywtMS44NjMzNiBoIDEzNi43NzAxOSBjIDEuMTE4MDEsMCAxLjg2MzM1LDAuNzQ1MzQgMi4yMzYwMiwxLjg2MzM2IEwgOTI1LjY3NjQ2LDQ5NCBoIDY3LjgyNjA5IEwgODg5LjUyNzM5LDEzNy43MjY3MSBDIDg4MS4zMjg2MywxMDguNjU4MzkgODU0Ljg2OSw4OC45MDY4MyA4MjQuNjgyNjcsODguOTA2ODMgWiBtIDU0LjQwOTkzLDI0OC41NzE0MyBjIC0wLjM3MjY3LDAuNzQ1MzQgLTEuMTE4MDEsMC43NDUzNCAtMS44NjMzNSwwLjc0NTM0IEggNzcyLjg4MTQyIGMgLTAuNzQ1MzQsMCAtMS40OTA2OCwtMC4zNzI2NyAtMS44NjMzNSwtMC43NDUzNCAtMC4zNzI2NywtMC43NDUzNCAtMC4zNzI2NywtMS40OTA2OCAwLC0yLjIzNjAyIGwgNTEuODAxMjQsLTE3OS42MjczMyBjIDAuMzcyNjcsLTEuMTE4MDIgMS4xMTgwMiwtMS44NjMzNiAyLjIzNjAzLC0xLjg2MzM2IDEuMTE4MDEsMC4zNzI2NyAxLjQ5MDY4LDEuMTE4MDIgMS44NjMzNSwxLjg2MzM2IGwgNTIuMTczOTEsMTc5LjYyNzMzIGMgMCwwLjc0NTM0IDAsMS40OTA2OCAwLDIuMjM2MDIgeiBtIDMxNi43NzAxLC05OC43NTc3NiBoIDY1LjU5MDEgdiAyNTUuNjUyMTcgaCAtNTEuNDI4NiBsIC03LjA4MDcsLTIxLjYxNDkxIGMgLTAuMzcyNywtMC43NDUzNCAtMC43NDU0LC0xLjQ5MDY4IC0xLjQ5MDcsLTEuODYzMzUgLTAuNzQ1MywtMC4zNzI2NyAtMS40OTA3LC0wLjM3MjY3IC0yLjIzNiwwIC0yNC4yMjM2LDE4LjI2MDg3IC01My4yOTE5LDI4LjMyMjk4IC04My40NzgzLDI4LjY5NTY1IC0zNC4yODU3LDAgLTY1LjU5LC0yMC40OTY4OSAtNzkuMDA2MiwtNTIuMTczOTEgLTQuNDcyLC0xMC40MzQ3OCAtNi43MDgxLC0yMS4yNDIyNCAtNi43MDgxLC0zMi40MjIzNiBWIDIzOC43MjA1IGggNjUuNTkwMSB2IDE3Mi41NDY1OCBjIDAsMjAuNDk2OSAxNy4xNDI5LDM3LjI2NzA4IDM3LjYzOTcsMzcuMjY3MDggMjEuMjQyMywtMS4xMTgwMSA0Mi4xMTE4LC02LjcwODA3IDYwLjc0NTQsLTE2Ljc3MDE4IDAuNzQ1MywtMC4zNzI2OCAxLjQ5MDcsLTEuMTE4MDIgMS4xMTgsLTEuODYzMzYgeiBtIDU1NS4yNzk1LDc5LjAwNjIxIHYgMTc2LjY0NTk2IGggLTY1LjIxNzMgViAzMjEuNDUzNDIgYyAwLC05LjY4OTQ0IC00LjA5OTQsLTE5LjM3ODg5IC0xMS4xODAyLC0yNi4wODY5NiAtNy4wODA3LC03LjA4MDc1IC0xNi4zOTc1LC0xMC44MDc0NSAtMjYuNDU5NiwtMTAuODA3NDUgLTIxLjI0MjIsMS4xMTgwMSAtNDIuMTExOCw2LjcwODA3IC02MS4xMTgsMTYuNzcwMTggLTAuNzQ1NCwwLjM3MjY3IC0xLjExOCwxLjExODAxIC0xLjExOCwyLjIzNjAzIFYgNDk0LjM3MjY3IEggMTUyMC40NTkgViA5NC40OTY4OSBoIDY1LjU5MDEgdiAxNjAuMjQ4NDUgYyAwLDAuNzQ1MzQgMC4zNzI2LDEuODYzMzYgMS4xMTgsMi4yMzYwMyAwLjc0NTMsMC4zNzI2NyAxLjg2MzMsMC4zNzI2NyAyLjYwODcsMCAyMi43MzI5LC0xNC45MDY4NCA0OS4xOTI1LC0yMy4xMDU1OSA3Ni4wMjQ4LC0yMy40NzgyNiA0Ni41ODM5LDAuMzcyNjcgODQuMjIzNiwzNy42Mzk3NSA4NC41OTYzLDg0LjIyMzYgeiBtIC0zMzMuOTEzLC03OS4wMDYyMSBoIDM5Ljg3NTggdiA1MC42ODMyMyBoIC0zOS44NzU4IGMgLTAuNzQ1MywwIC0xLjExOCwwLjM3MjY3IC0xLjg2MzQsMC43NDUzNCAtMC4zNzI2LDAuMzcyNjcgLTAuNzQ1MywxLjExODAxIC0wLjc0NTMsMS44NjMzNSB2IDEzNy4xNDI4NiBjIDAsMTAuODA3NDUgOC45NDQxLDE5Ljc1MTU1IDIwLjEyNDIsMTkuNzUxNTUgMCwwIDAsMCAwLDAgNS45NjI4LDAgMTQuNTM0MiwwIDIyLjM2MDMsLTEuMTE4MDEgViA0OTQgYyAtMTMuMDQzNSwzLjcyNjcxIC0yNi40NTk3LDUuOTYyNzMgLTM5Ljg3NTgsNS41OTAwNiAtMzcuMjY3MSwwIC02Ny40NTM0LC0yOS44MTM2NiAtNjcuODI2MSwtNjcuMDgwNzQgViAyOTEuNjM5NzUgYyAwLC0xLjQ5MDY4IC0xLjExOCwtMi4yMzYwMiAtMi42MDg3LC0yLjYwODY5IGggLTM5LjEzMDQgdiAtNTAuNjgzMjMgaCAzOS44NzU4IGMgMS40OTA2LDAgMi4yMzYsLTEuMTE4MDIgMi42MDg3LC0yLjYwODcgdiAtODQuMjIzNiBoIDY1LjU5IHYgODQuMjIzNiBjIC0wLjM3MjcsMS40OTA2OCAwLjM3MjcsMi42MDg3IDEuNDkwNywyLjk4MTM3IHogbSA2MjYuNDU5NiwtOTIuNzk1MDMgYyAtMjIuMzYwMiwtMzUuNDAzNzMgLTYxLjExOCwtNTYuNjQ1OTcgLTEwMi44NTcxLC01Ni42NDU5NyAtNDEuNzM5MSwwIC04MC40OTY5LDIxLjI0MjI0IC0xMDIuODU3Miw1Ni42NDU5NyAtMjQuOTY4OSwzNi41MjE3MyAtMzguMzg1MSw4Ny45NTAzMSAtMzguMzg1MSwxNDguNjk1NjUgLTIuMjM2LDUyLjU0NjU4IDExLjU1MjgsMTA0LjM0NzgyIDM4Ljc1NzgsMTQ5LjA2ODMyIDIyLjM2MDMsMzUuNDAzNzMgNjEuMTE4LDU2LjY0NTk2IDEwMi44NTcyLDU2LjY0NTk2IDQxLjczOTEsMCA4MC40OTY5LC0yMS4yNDIyMyAxMDIuODU3MSwtNTYuNjQ1OTYgMjUuMzQxNiwtMzYuODk0NDEgMzguMzg1MSwtODguMzIyOTggMzguMzg1MSwtMTQ4LjY5NTY1IDAsLTYwLjM3MjY3IC0xMy40MTYyLC0xMTIuNTQ2NTkgLTM4LjM4NTEsLTE0OS4wNjgzMiB6IG0gLTUzLjY2NDYsMjY4LjY5NTY1IGMgLTEyLjY3MDgsMjMuMTA1NTkgLTI4LjY5NTYsMzQuMjg1NzEgLTQ4LjgxOTgsMzQuMjg1NzEgLTE5Ljc1MTYsMCAtMzUuNzc2NCwtMTEuOTI1NDYgLTQ4LjgxOTksLTM0LjI4NTcxIC0xNy4xNDI5LC0zNy42Mzk3NSAtMjUuMzQxNiwtNzguNjMzNTQgLTIzLjQ3ODMsLTEyMCAtMS44NjMzLC00MS4zNjY0NiA2LjMzNTQsLTgyLjczMjkyIDIzLjQ3ODMsLTEyMC43NDUzNCAxMi42NzA4LC0yMy4xMDU1OSAyOC42OTU2LC0zNC4yODU3MiA0OC40NDcyLC0zNC4yODU3MiAxOS43NTE1LDAgMzYuMTQ5MSwxMS4xODAxMyA0OC44MTk5LDM0LjI4NTcyIDE3LjE0MjgsMzcuNjM5NzUgMjUuMzQxNiw3OC42MzM1NCAyMy40NzgyLDEyMCAyLjIzNiw0MS43MzkxMyAtNS41OSw4My4xMDU1OSAtMjMuMTA1NiwxMjAuNzQ1MzQgeiIKICAgaWQ9InBhdGg2IgogICBzdHlsZT0ic3Ryb2tlLXdpZHRoOjMuNzI2NzEiIC8+Cjwvc3ZnPgo="            x="435" y="303" width="72" height="23"/>
              <image href="data:image/svg+xml;base64,PHN2ZyBhcmlhLWhpZGRlbj0idHJ1ZSIgZmlsbD0ibm9uZSIgaGVpZ2h0PSIyNCIgc3R5bGU9Im1hcmdpbi1ib3R0b206MHJlbSIgdmlld0JveD0iMCAwIDEyMyAyNCIgd2lkdGg9IjEyMyIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik05LjM0MzA0IDEzLjE0MjhIMC4yMDAxOTVDMC43NzU2OTEgMTkuMjM0MiA1LjkwNDUyIDI0IDEyLjE0NjUgMjRDMTMuNzY1MSAyNCAxNS4zMDg5IDIzLjY3OTUgMTYuNzE3OSAyMy4wOTg1QzEyLjY5MzUgMjEuNDM5MSA5Ljc2OTMgMTcuNjU0NiA5LjM0MzA0IDEzLjE0MjhaIiBmaWxsPSJ3aGl0ZSIgZmlsbC1ydWxlPSJldmVub2RkIj48L3BhdGg+PHBhdGggZD0iTTkuMzQzMDQgMTAuODU3MUM5Ljc2OTMgNi4zNDU0IDEyLjY5MzUgMi41NjA4NyAxNi43MTc5IDAuOTAxNDU5QzE1LjMwODkgMC4zMjA0ODQgMTMuNzY1MSAwIDEyLjE0NjUgMEM1LjkwNDUyIDAgMC43NzU2OTEgNC43NjU3OSAwLjIwMDE5NSAxMC44NTcxSDkuMzQzMDRaIiBmaWxsPSJ3aGl0ZSI+PC9wYXRoPjxwYXRoIGNsaXAtcnVsZT0iZXZlbm9kZCIgZD0iTTE0LjY2MTUgMTQuODU3MkMxMy43NDc0IDE4LjU5OTggMTEuMDc4IDIxLjY1NDIgNy41NzUyIDIzLjA5ODZDOC45ODQxNSAyMy42Nzk1IDEwLjUyOCAyNCAxMi4xNDY2IDI0QzE3Ljc4OTQgMjQgMjIuNTIyNiAyMC4xMDUyIDIzLjgwNDQgMTQuODU3MkgxNC42NjE1WiIgZmlsbD0id2hpdGUiIGZpbGwtcnVsZT0iZXZlbm9kZCI+PC9wYXRoPjxwYXRoIGQ9Ik0yMy43ODY4IDkuMTQyODZIMTQuNjQ0QzEzLjcyOTkgNS40MDAyNSAxMS4wNjA1IDIuMzQ1ODMgNy41NTc2MiAwLjkwMTQ1OUM4Ljk2NjU4IDAuMzIwNDgzIDEwLjUxMDQgMCAxMi4xMjkgMEMxNy43NzE5IDAgMjIuNTA1IDMuODk0ODQgMjMuNzg2OCA5LjE0Mjg2WiIgZmlsbD0id2hpdGUiPjwvcGF0aD48cGF0aCBkPSJNNDYuMDk2NCA5LjgwODc3QzQ1LjY5MTMgNi40NDk0IDQzLjE0NzQgNC41MTc1OCAzOS43NzkxIDQuNTE3NThDMzUuOTM0OCA0LjUxNzU4IDMzIDcuMjMwNjUgMzMgMTEuOTg5MkMzMyAxNi43MzM1IDM1Ljg4NSAxOS40NjA4IDM5Ljc3OTEgMTkuNDYwOEM0My41MDk4IDE5LjQ2MDggNDUuNzYyNCAxNi45ODIxIDQ2LjA5NjQgMTQuMzA0NUw0Mi45ODQgMTQuMjkwM0M0Mi42OTI2IDE1Ljg0NTcgNDEuNDcwNCAxNi43NDA2IDM5LjgyODkgMTYuNzQwNkMzNy42MTg5IDE2Ljc0MDYgMzYuMTE5NSAxNS4xIDM2LjExOTUgMTEuOTg5MkMzNi4xMTk1IDguOTYzNiAzNy41OTc2IDcuMjM3NzUgMzkuODUwMiA3LjIzNzc1QzQxLjUzNDMgNy4yMzc3NSA0Mi43NDk1IDguMjEwNzYgNDIuOTg0IDkuODA4NzdINDYuMDk2NFoiIGZpbGw9ImN1cnJlbnRDb2xvciI+PC9wYXRoPjxwYXRoIGQ9Ik01Mi4yMTAxIDE5LjQ3NUM1NC45MTA0IDE5LjQ3NSA1Ni43Mjk1IDE4LjE2MSA1Ny4xNTU5IDE2LjEzNjlMNTQuMzU2MSAxNS45NTIyQzU0LjA1MDYgMTYuNzgzMiA1My4yNjg5IDE3LjIxNjQgNTIuMjU5OSAxNy4yMTY0QzUwLjc0NjMgMTcuMjE2NCA0OS43ODcgMTYuMjE1IDQ5Ljc4NyAxNC41ODg2VjE0LjU4MTVINTcuMjE5OFYxMy43NTA1QzU3LjIxOTggMTAuMDQzMSA1NC45NzQzIDguMjEwNzYgNTIuMDg5MyA4LjIxMDc2QzQ4Ljg3NzQgOC4yMTA3NiA0Ni43OTUzIDEwLjQ5MDYgNDYuNzk1MyAxMy44NTcxQzQ2Ljc5NTMgMTcuMzE1OSA0OC44NDkgMTkuNDc1IDUyLjIxMDEgMTkuNDc1Wk00OS43ODcgMTIuNzA2NUM0OS44NTA5IDExLjQ2MzYgNTAuNzk2IDEwLjQ2OTMgNTIuMTM5IDEwLjQ2OTNDNTMuNDUzNyAxMC40NjkzIDU0LjM2MzIgMTEuNDA2OCA1NC4zNzAzIDEyLjcwNjVINDkuNzg3WiIgZmlsbD0iY3VycmVudENvbG9yIj48L3BhdGg+PHBhdGggZD0iTTY4LjUyMDMgMjMuMzUyOFY4LjM1MjgxSDY1LjUzNThWMTAuMTg1Mkg2NS40MDA4QzY0Ljk5NTcgOS4yOTc0MSA2NC4xMjE3IDguMjEwNzYgNjIuMjk1NSA4LjIxMDc2QzU5LjkwMDcgOC4yMTA3NiA1Ny44NzU1IDEwLjA3MTYgNTcuODc1NSAxMy44MjE2QzU3Ljg3NTUgMTcuNDcyMSA1OS44MTU1IDE5LjQzOTUgNjIuMzAyNiAxOS40Mzk1QzY0LjA2NDggMTkuNDM5NSA2NC45ODE1IDE4LjQyMzggNjUuNDAwOCAxNy41MTQ3SDY1LjQ5MzJWMjMuMzUyOEg2OC41MjAzWk02NS41NTcxIDEzLjgwNzRDNjUuNTU3MSAxNS43NTM0IDY0LjcxODYgMTcuMDMxOCA2My4yNjE5IDE3LjAzMThDNjEuNzc2NyAxNy4wMzE4IDYwLjk2NjYgMTUuNzEwOCA2MC45NjY2IDEzLjgwNzRDNjAuOTY2NiAxMS45MTgxIDYxLjc2MjUgMTAuNjE4NCA2My4yNjE5IDEwLjYxODRDNjQuNzMyOCAxMC42MTg0IDY1LjU1NzEgMTEuODYxMyA2NS41NTcxIDEzLjgwNzRaIiBmaWxsPSJjdXJyZW50Q29sb3IiPjwvcGF0aD48cGF0aCBkPSJNNzYuNTA0IDE0LjYxN0M3Ni41MTEyIDE2LjA4MDEgNzUuNTA5MiAxNi44NDcxIDc0LjQyMiAxNi44NDcxQzczLjI3NzkgMTYuODQ3MSA3Mi41Mzg5IDE2LjA0NDYgNzIuNTMxOCAxNC43NTkxVjguMzUyODFINjkuNTA0NlYxNS4yOTg4QzY5LjUxMTcgMTcuODQ4NSA3MS4wMDQgMTkuNDAzOSA3My4xOTk4IDE5LjQwMzlDNzQuODQxMiAxOS40MDM5IDc2LjAyMDggMTguNTU4OCA3Ni41MTEyIDE3LjI4MDRINzYuNjI0OVYxOS4yNjE5SDc5LjUzMTJWOC4zNTI4MUg3Ni41MDRWMTQuNjE3WiIgZmlsbD0iY3VycmVudENvbG9yIj48L3BhdGg+PHBhdGggZD0iTTg1LjYzMDkgMTkuNDc1Qzg4LjMzMTIgMTkuNDc1IDkwLjE1MDMgMTguMTYxIDkwLjU3NjcgMTYuMTM2OUw4Ny43NzY5IDE1Ljk1MjJDODcuNDcxMyAxNi43ODMyIDg2LjY4OTcgMTcuMjE2NCA4NS42ODA2IDE3LjIxNjRDODQuMTY3IDE3LjIxNjQgODMuMjA3NyAxNi4yMTUgODMuMjA3NyAxNC41ODg2VjE0LjU4MTVIOTAuNjQwNlYxMy43NTA1QzkwLjY0MDYgMTAuMDQzMSA4OC4zOTUxIDguMjEwNzYgODUuNTEwMSA4LjIxMDc2QzgyLjI5ODIgOC4yMTA3NiA4MC4yMTYxIDEwLjQ5MDYgODAuMjE2MSAxMy44NTcxQzgwLjIxNjEgMTcuMzE1OSA4Mi4yNjk3IDE5LjQ3NSA4NS42MzA5IDE5LjQ3NVpNODMuMjA3NyAxMi43MDY1QzgzLjI3MTcgMTEuNDYzNiA4NC4yMTY4IDEwLjQ2OTMgODUuNTU5OCAxMC40NjkzQzg2Ljg3NDQgMTAuNDY5MyA4Ny43ODQgMTEuNDA2OCA4Ny43OTExIDEyLjcwNjVIODMuMjA3N1oiIGZpbGw9ImN1cnJlbnRDb2xvciI+PC9wYXRoPjxwYXRoIGQ9Ik05NC40NDI2IDEyLjk1NTFDOTQuNDQ5NyAxMS41NDg4IDk1LjI4ODIgMTAuNzI1IDk2LjUxMDUgMTAuNzI1Qzk3LjcyNTYgMTAuNzI1IDk4LjQ1NzUgMTEuNTIwNCA5OC40NTA0IDEyLjg1NTZWMTkuMjYxOUgxMDEuNDc4VjEyLjMxNTlDMTAxLjQ3OCA5Ljc3MzI2IDk5Ljk4NTMgOC4yMTA3NiA5Ny43MTE0IDguMjEwNzZDOTYuMDkxMiA4LjIxMDc2IDk0LjkxODcgOS4wMDYyMSA5NC40Mjg0IDEwLjI3NzVIOTQuMzAwNVY4LjM1MjgxSDkxLjQxNTVWMTkuMjYxOUg5NC40NDI2VjEyLjk1NTFaIiBmaWxsPSJjdXJyZW50Q29sb3IiPjwvcGF0aD48cGF0aCBkPSJNMTA3LjQwNCAxOS40NzVDMTEwLjMxIDE5LjQ3NSAxMTIuMTM2IDE3Ljc3MDQgMTEyLjI3OSAxNS4yNjMzSDEwOS40MjJDMTA5LjI0NCAxNi40MjgxIDEwOC40NzcgMTcuMDgxNSAxMDcuNDM5IDE3LjA4MTVDMTA2LjAyNSAxNy4wODE1IDEwNS4xMDkgMTUuODk1NCAxMDUuMTA5IDEzLjgwNzRDMTA1LjEwOSAxMS43NDc3IDEwNi4wMzIgMTAuNTY4NyAxMDcuNDM5IDEwLjU2ODdDMTA4LjU0OCAxMC41Njg3IDEwOS4yNTggMTEuMzAwMiAxMDkuNDIyIDEyLjM4NjlIMTEyLjI3OUMxMTIuMTUxIDkuODY1NTkgMTEwLjIzOSA4LjIxMDc2IDEwNy4zOSA4LjIxMDc2QzEwNC4wNzggOC4yMTA3NiAxMDIuMDMyIDEwLjUwNDggMTAyLjAzMiAxMy44NUMxMDIuMDMyIDE3LjE2NjcgMTA0LjA0MyAxOS40NzUgMTA3LjQwNCAxOS40NzVaIiBmaWxsPSJjdXJyZW50Q29sb3IiPjwvcGF0aD48cGF0aCBkPSJNMTE3Ljk5IDE5LjQ3NUMxMjAuNjkxIDE5LjQ3NSAxMjIuNTEgMTguMTYxIDEyMi45MzYgMTYuMTM2OUwxMjAuMTM2IDE1Ljk1MjJDMTE5LjgzMSAxNi43ODMyIDExOS4wNDkgMTcuMjE2NCAxMTguMDQgMTcuMjE2NEMxMTYuNTI2IDE3LjIxNjQgMTE1LjU2NyAxNi4yMTUgMTE1LjU2NyAxNC41ODg2VjE0LjU4MTVIMTIzVjEzLjc1MDVDMTIzIDEwLjA0MzEgMTIwLjc1NCA4LjIxMDc2IDExNy44NjkgOC4yMTA3NkMxMTQuNjU4IDguMjEwNzYgMTEyLjU3NSAxMC40OTA2IDExMi41NzUgMTMuODU3MUMxMTIuNTc1IDE3LjMxNTkgMTE0LjYyOSAxOS40NzUgMTE3Ljk5IDE5LjQ3NVpNMTE1LjU2NyAxMi43MDY1QzExNS42MzEgMTEuNDYzNiAxMTYuNTc2IDEwLjQ2OTMgMTE3LjkxOSAxMC40NjkzQzExOS4yMzQgMTAuNDY5MyAxMjAuMTQzIDExLjQwNjggMTIwLjE1IDEyLjcwNjVIMTE1LjU2N1oiIGZpbGw9ImN1cnJlbnRDb2xvciI+PC9wYXRoPjxkZWZzPjxsaW5lYXJHcmFkaWVudCBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSIgaWQ9InBhaW50MF9saW5lYXIiIHgxPSI4LjQ5MjE5IiB4Mj0iOC40OTIxOSIgeTE9IjEzLjE0MjgiIHkyPSIyNCI+PHN0b3Agc3RvcC1jb2xvcj0iIzI5NzlGRiI+PC9zdG9wPjxzdG9wIG9mZnNldD0iMSIgc3RvcC1jb2xvcj0iIzQ0OEFGRiI+PC9zdG9wPjwvbGluZWFyR3JhZGllbnQ+PGxpbmVhckdyYWRpZW50IGdyYWRpZW50VW5pdHM9InVzZXJTcGFjZU9uVXNlIiBpZD0icGFpbnQxX2xpbmVhciIgeDE9IjE1LjY1MTciIHgyPSIxNS42NTE3IiB5MT0iMTQuODU3MiIgeTI9IjI0Ij48c3RvcCBzdG9wLWNvbG9yPSIjNDQ4QUZGIj48L3N0b3A+PHN0b3Agb2Zmc2V0PSIxIiBzdG9wLWNvbG9yPSIjMjk3OUZGIj48L3N0b3A+PC9saW5lYXJHcmFkaWVudD48L2RlZnM+PC9zdmc+"    x="530" y="307" width="76" height="15"/>
              <!-- Duplicate set (offset +570) for seamless loop -->
              <image href="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+CjwhLS0gQ3JlYXRlZCB3aXRoIElua3NjYXBlIChodHRwOi8vd3d3Lmlua3NjYXBlLm9yZy8pIC0tPgoKPHN2ZwogICB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iCiAgIHhtbG5zOmNjPSJodHRwOi8vY3JlYXRpdmVjb21tb25zLm9yZy9ucyMiCiAgIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyIKICAgeG1sbnM6c3ZnPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIKICAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogICB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIKICAgeG1sbnM6c29kaXBvZGk9Imh0dHA6Ly9zb2RpcG9kaS5zb3VyY2Vmb3JnZS5uZXQvRFREL3NvZGlwb2RpLTAuZHRkIgogICB4bWxuczppbmtzY2FwZT0iaHR0cDovL3d3dy5pbmtzY2FwZS5vcmcvbmFtZXNwYWNlcy9pbmtzY2FwZSIKICAgdmVyc2lvbj0iMS4xIgogICBpZD0ic3ZnODM0IgogICB4bWw6c3BhY2U9InByZXNlcnZlIgogICB3aWR0aD0iNDA5LjMzMjkyIgogICBoZWlnaHQ9IjE2Ni43NTA1OCIKICAgdmlld0JveD0iMCAwIDQwOS4zMzI5MiAxNjYuNzUwNTgiCiAgIHNvZGlwb2RpOmRvY25hbWU9IlBoYXNlZFJlbGVhc2UtQ1Muc3ZnIgogICBpbmtzY2FwZTp2ZXJzaW9uPSIwLjkyLjIgNWMzZTgwZCwgMjAxNy0wOC0wNiI+PG1ldGFkYXRhCiAgICAgaWQ9Im1ldGFkYXRhODQwIj48cmRmOlJERj48Y2M6V29yawogICAgICAgICByZGY6YWJvdXQ9IiI+PGRjOmZvcm1hdD5pbWFnZS9zdmcreG1sPC9kYzpmb3JtYXQ+PGRjOnR5cGUKICAgICAgICAgICByZGY6cmVzb3VyY2U9Imh0dHA6Ly9wdXJsLm9yZy9kYy9kY21pdHlwZS9TdGlsbEltYWdlIiAvPjxkYzp0aXRsZT48L2RjOnRpdGxlPjwvY2M6V29yaz48L3JkZjpSREY+PC9tZXRhZGF0YT48ZGVmcwogICAgIGlkPSJkZWZzODM4Ij48Y2xpcFBhdGgKICAgICAgIGNsaXBQYXRoVW5pdHM9InVzZXJTcGFjZU9uVXNlIgogICAgICAgaWQ9ImNsaXBQYXRoODUyIj48cGF0aAogICAgICAgICBkPSJNIDAsMCBIIDYxMiBWIDc5MiBIIDAgWiIKICAgICAgICAgaWQ9InBhdGg4NTAiCiAgICAgICAgIGlua3NjYXBlOmNvbm5lY3Rvci1jdXJ2YXR1cmU9IjAiIC8+PC9jbGlwUGF0aD48Y2xpcFBhdGgKICAgICAgIGNsaXBQYXRoVW5pdHM9InVzZXJTcGFjZU9uVXNlIgogICAgICAgaWQ9ImNsaXBQYXRoODYwIj48cGF0aAogICAgICAgICBkPSJtIC03NDkuMzY5LC00NS40MzkzIGggMiB2IC01OC43ODQ3IGggLTIgeiIKICAgICAgICAgaWQ9InBhdGg4NTgiCiAgICAgICAgIGlua3NjYXBlOmNvbm5lY3Rvci1jdXJ2YXR1cmU9IjAiIC8+PC9jbGlwUGF0aD48Y2xpcFBhdGgKICAgICAgIGNsaXBQYXRoVW5pdHM9InVzZXJTcGFjZU9uVXNlIgogICAgICAgaWQ9ImNsaXBQYXRoMTI1NiI+PHBhdGgKICAgICAgICAgZD0iTSAzNiwzOTEuNTIgSCAzMDQuMjI5IFYgMjcxLjQ3NSBIIDM2IFoiCiAgICAgICAgIGlkPSJwYXRoMTI1NCIKICAgICAgICAgaW5rc2NhcGU6Y29ubmVjdG9yLWN1cnZhdHVyZT0iMCIgLz48L2NsaXBQYXRoPjxjbGlwUGF0aAogICAgICAgY2xpcFBhdGhVbml0cz0idXNlclNwYWNlT25Vc2UiCiAgICAgICBpZD0iY2xpcFBhdGgxMzY4Ij48cGF0aAogICAgICAgICBkPSJNIDAsMCBIIDYxMiBWIDc5MiBIIDAgWiIKICAgICAgICAgaWQ9InBhdGgxMzY2IgogICAgICAgICBpbmtzY2FwZTpjb25uZWN0b3ItY3VydmF0dXJlPSIwIiAvPjwvY2xpcFBhdGg+PGNsaXBQYXRoCiAgICAgICBjbGlwUGF0aFVuaXRzPSJ1c2VyU3BhY2VPblVzZSIKICAgICAgIGlkPSJjbGlwUGF0aDEzOTYiPjxwYXRoCiAgICAgICAgIGQ9Ik0gMCwwIEggNjEyIFYgNzkyIEggMCBaIgogICAgICAgICBpZD0icGF0aDEzOTQiCiAgICAgICAgIGlua3NjYXBlOmNvbm5lY3Rvci1jdXJ2YXR1cmU9IjAiIC8+PC9jbGlwUGF0aD48Y2xpcFBhdGgKICAgICAgIGNsaXBQYXRoVW5pdHM9InVzZXJTcGFjZU9uVXNlIgogICAgICAgaWQ9ImNsaXBQYXRoMTQzMiI+PHBhdGgKICAgICAgICAgZD0iTSAwLDAgSCA2MTIgViA3OTIgSCAwIFoiCiAgICAgICAgIGlkPSJwYXRoMTQzMCIKICAgICAgICAgaW5rc2NhcGU6Y29ubmVjdG9yLWN1cnZhdHVyZT0iMCIgLz48L2NsaXBQYXRoPjwvZGVmcz48c29kaXBvZGk6bmFtZWR2aWV3CiAgICAgcGFnZWNvbG9yPSIjZmZmZmZmIgogICAgIGJvcmRlcmNvbG9yPSIjNjY2NjY2IgogICAgIGJvcmRlcm9wYWNpdHk9IjEiCiAgICAgb2JqZWN0dG9sZXJhbmNlPSIxMCIKICAgICBncmlkdG9sZXJhbmNlPSIxMCIKICAgICBndWlkZXRvbGVyYW5jZT0iMTAiCiAgICAgaW5rc2NhcGU6cGFnZW9wYWNpdHk9IjAiCiAgICAgaW5rc2NhcGU6cGFnZXNoYWRvdz0iMiIKICAgICBpbmtzY2FwZTp3aW5kb3ctd2lkdGg9IjEzODIiCiAgICAgaW5rc2NhcGU6d2luZG93LWhlaWdodD0iOTQ1IgogICAgIGlkPSJuYW1lZHZpZXc4MzYiCiAgICAgc2hvd2dyaWQ9ImZhbHNlIgogICAgIGZpdC1tYXJnaW4tdG9wPSIwIgogICAgIGZpdC1tYXJnaW4tbGVmdD0iMCIKICAgICBmaXQtbWFyZ2luLXJpZ2h0PSIwIgogICAgIGZpdC1tYXJnaW4tYm90dG9tPSIwIgogICAgIGlua3NjYXBlOnpvb209IjEiCiAgICAgaW5rc2NhcGU6Y3g9IjIyNC4xNzAxIgogICAgIGlua3NjYXBlOmN5PSIxNzEuNzEwOTciCiAgICAgaW5rc2NhcGU6d2luZG93LXg9IjE2OCIKICAgICBpbmtzY2FwZTp3aW5kb3cteT0iMjAiCiAgICAgaW5rc2NhcGU6d2luZG93LW1heGltaXplZD0iMCIKICAgICBpbmtzY2FwZTpjdXJyZW50LWxheWVyPSJnMTUxOCIgLz48ZwogICAgIGlkPSJnODQyIgogICAgIGlua3NjYXBlOmdyb3VwbW9kZT0ibGF5ZXIiCiAgICAgaW5rc2NhcGU6bGFiZWw9IlBoYXNlZFJlbGVhc2UtQ1MiCiAgICAgdHJhbnNmb3JtPSJtYXRyaXgoMS4zMzMzMzMzLDAsMCwtMS4zMzMzMzMzLC0yMzcuMDk1OTcsMTAwMi40MzQzKSI+PGcKICAgICAgIGlkPSJnMTUxOCIKICAgICAgIHRyYW5zZm9ybT0ibWF0cml4KDQuMjA1NDkyNywwLDAsNC4yMDU0OTI3LC0xOTM3Ljg0NDksLTI0MTkuMTAyNykiPjxnCiAgICAgICAgIGlkPSJnMTM5MiIKICAgICAgICAgY2xpcC1wYXRoPSJ1cmwoI2NsaXBQYXRoMTM5NikiCiAgICAgICAgIHN0eWxlPSJmaWxsOndoaXRlIiAvPjxnCiAgICAgICAgIGlkPSJnMTU1NyI+PGcKICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZTtmaWxsLW9wYWNpdHk6MSIKICAgICAgICAgICB0cmFuc2Zvcm09InRyYW5zbGF0ZSg1MTguMTc2Myw3MjQuOTE4OSkiCiAgICAgICAgICAgaWQ9ImcxNDAyIj48cGF0aAogICAgICAgICAgICAgaW5rc2NhcGU6Y29ubmVjdG9yLWN1cnZhdHVyZT0iMCIKICAgICAgICAgICAgIGlkPSJwYXRoMTQwNCIKICAgICAgICAgICAgIHN0eWxlPSJmaWxsOndoaXRlO2ZpbGwtb3BhY2l0eToxO2ZpbGwtcnVsZTpub256ZXJvO3N0cm9rZTpub25lIgogICAgICAgICAgICAgZD0ibSAwLDAgYyAtNi4xMjcsMS44NjIgLTEwLjU4LDcuNTE3IC0xMC41OCwxNC4yMDkgMCw2Ljc2MyA0LjU0OCwxMi40NjUgMTAuNzY4LDE0LjI3OSAwLjYzNywwLjE4OSAwLjQ3MiwwLjU5IC0wLjMwNiwwLjU5IC04LjI3MSwwIC0xNC45ODYsLTYuNjY5IC0xNC45ODYsLTE0Ljg2OSAwLC04LjIgNi43MTUsLTE0Ljg2OSAxNC45ODYsLTE0Ljg2OSBDIDAuNjYsLTAuNjYgMC43MDcsLTAuMjEyIDAsMCIgLz48L2c+PGcKICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZSIKICAgICAgICAgICB0cmFuc2Zvcm09InRyYW5zbGF0ZSg1MTAuNDQ3NCw3MzUuNjYzOSkiCiAgICAgICAgICAgaWQ9ImcxNDA2Ij48cGF0aAogICAgICAgICAgICAgaW5rc2NhcGU6Y29ubmVjdG9yLWN1cnZhdHVyZT0iMCIKICAgICAgICAgICAgIGlkPSJwYXRoMTQwOCIKICAgICAgICAgICAgIHN0eWxlPSJmaWxsOndoaXRlO2ZpbGwtb3BhY2l0eToxO2ZpbGwtcnVsZTpub256ZXJvO3N0cm9rZTpub25lIgogICAgICAgICAgICAgZD0ibSAwLDAgYyAtMC4wNDcsMC40MDEgLTAuMDcxLDAuODAxIC0wLjA3MSwxLjIwMiAwLDYuNTI3IDUuMjc5LDExLjgwNSAxMS44MDYsMTEuODA1IDYuMTczLDAgOC4wMTEsLTIuNzU3IDguMjQ3LC0yLjU2OCAwLjI1OSwwLjE4OCAtMi4yMzksNS42NTUgLTkuNDczLDUuNjU1IC02LjUyNywwIC0xMS44MDUsLTUuMjc4IC0xMS44MDUsLTExLjgwNSAwLC0xLjUwOCAwLjI4MywtMi45NDYgMC44MDEsLTQuMjY1IEMgLTAuMjgzLC0wLjU0MiAwLjA0NywtMC41NDIgMCwwIiAvPjwvZz48ZwogICAgICAgICAgIHN0eWxlPSJmaWxsOndoaXRlO2ZpbGwtb3BhY2l0eToxIgogICAgICAgICAgIHRyYW5zZm9ybT0idHJhbnNsYXRlKDUxNS4zOTU4LDc0NC4xNzA0KSIKICAgICAgICAgICBpZD0iZzE0MTAiPjxwYXRoCiAgICAgICAgICAgICBpbmtzY2FwZTpjb25uZWN0b3ItY3VydmF0dXJlPSIwIgogICAgICAgICAgICAgaWQ9InBhdGgxNDEyIgogICAgICAgICAgICAgc3R5bGU9ImZpbGw6d2hpdGU7ZmlsbC1vcGFjaXR5OjE7ZmlsbC1ydWxlOm5vbnplcm87c3Ryb2tlOm5vbmUiCiAgICAgICAgICAgICBkPSJtIDAsMCBjIDMuMDYzLDEuMzQzIDYuOTI4LDEuMzkgMTAuNzIxLDAuMDQ3IDIuNTQ1LC0wLjg5NSA0LjAzLC0yLjE2OCA0LjE0OCwtMi4wOTcgMC4yMTIsMC4wOTQgLTEuNDg1LDIuNzU3IC00LjUyNSwzLjkxMiBDIDYuNjY4LDMuMjUyIDIuNzEsMi41MjEgLTAuMTY1LDAuMjU5IC0wLjQ5NSwwIC0wLjM3NywtMC4xNjUgMCwwIiAvPjwvZz48ZwogICAgICAgICAgIHN0eWxlPSJmaWxsOndoaXRlO2ZpbGwtb3BhY2l0eToxIgogICAgICAgICAgIHRyYW5zZm9ybT0idHJhbnNsYXRlKDU3Ni4wNzIsNzM4LjYwOTQpIgogICAgICAgICAgIGlkPSJnMTQxNCI+PHBhdGgKICAgICAgICAgICAgIGlua3NjYXBlOmNvbm5lY3Rvci1jdXJ2YXR1cmU9IjAiCiAgICAgICAgICAgICBpZD0icGF0aDE0MTYiCiAgICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZTtmaWxsLW9wYWNpdHk6MTtmaWxsLXJ1bGU6bm9uemVybztzdHJva2U6bm9uZSIKICAgICAgICAgICAgIGQ9Im0gMCwwIGMgMCwtMC44NDggLTAuNzA3LC0xLjU1NSAtMS41NTUsLTEuNTU1IC0wLjg0OSwwIC0xLjU1NSwwLjY4MyAtMS41NTUsMS41NTUgMCwwLjg0OCAwLjY4MywxLjU1NSAxLjU1NSwxLjU1NSBDIC0wLjY4MywxLjU1NSAwLDAuODcyIDAsMCIgLz48L2c+PHBhdGgKICAgICAgICAgICBpbmtzY2FwZTpjb25uZWN0b3ItY3VydmF0dXJlPSIwIgogICAgICAgICAgIGlkPSJwYXRoMTQyMCIKICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZTtmaWxsLW9wYWNpdHk6MTtmaWxsLXJ1bGU6bm9uemVybztzdHJva2U6bm9uZSIKICAgICAgICAgICBkPSJtIDUyNS40NTc0LDcyOS45MTQ0IDAuMTg4LC0yLjA3NCBoIDMuMjc2IGwgLTEuMTA4LDEyLjA0MSBoIC00Ljg3NyBsIC02LjE3NCwtMTIuMDQxIGggMy4zNDYgbCAxLjAzNywyLjA3NCB6IG0gLTAuMTY1LDIuMzMzIGggLTIuOTkzIGwgMi41NjksNS4yMDcgaCAwLjAyMyB6IiAvPjxwYXRoCiAgICAgICAgICAgaW5rc2NhcGU6Y29ubmVjdG9yLWN1cnZhdHVyZT0iMCIKICAgICAgICAgICBpZD0icGF0aDE0MjQiCiAgICAgICAgICAgc3R5bGU9ImZpbGw6d2hpdGU7ZmlsbC1vcGFjaXR5OjE7ZmlsbC1ydWxlOm5vbnplcm87c3Ryb2tlOm5vbmUiCiAgICAgICAgICAgZD0ibSA1MzMuNDY5LDczMy4wOTU2IGggMC40OTUgbCAyLjMzMywzLjE4MSBoIDMuMDM5IGwgLTMuMjI4LC00LjA1MyAxLjk4LC00LjM4MyBoIC0zLjIyOSBsIC0xLjI5NiwzLjQxNyBoIC0wLjQ3MSBsIC0wLjczLC0zLjQxNyBoIC0yLjc1NyBsIDIuNTQ0LDEyLjA0MSBoIDIuNzU3IHoiIC8+PGcKICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZTtmaWxsLW9wYWNpdHk6MSIKICAgICAgICAgICBjbGlwLXBhdGg9InVybCgjY2xpcFBhdGgxNDMyKSIKICAgICAgICAgICBpZD0iZzE0MjgiPjxnCiAgICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZTtmaWxsLW9wYWNpdHk6MSIKICAgICAgICAgICAgIHRyYW5zZm9ybT0idHJhbnNsYXRlKDU0My42NDg1LDcyNy44NDA4KSIKICAgICAgICAgICAgIGlkPSJnMTQzNCI+PHBhdGgKICAgICAgICAgICAgICAgaW5rc2NhcGU6Y29ubmVjdG9yLWN1cnZhdHVyZT0iMCIKICAgICAgICAgICAgICAgaWQ9InBhdGgxNDM2IgogICAgICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZTtmaWxsLW9wYWNpdHk6MTtmaWxsLXJ1bGU6bm9uemVybztzdHJva2U6bm9uZSIKICAgICAgICAgICAgICAgZD0iTSAwLDAgSCAyLjc1NyBMIDMuODY0LDUuMjU1IEMgNC40NzcsOC4xNTMgMy4zNyw4LjUwNiAwLjU0Miw4LjUwNiBjIC0xLjk3OSwwIC0zLjg4OCwwLjAyNCAtNC40MywtMi41OTEgaCAyLjc1NyBjIDAuMTY1LDAuNzU0IDAuNjM2LDAuOTE4IDEuMzIsMC45MTggMS4yMDEsMCAxLjE1NCwtMC40OTQgMC45ODksLTEuMjcyIEwgMC44OTUsNC4yMTggSCAwLjc3OCBDIDAuNjgzLDUuMTg0IC0wLjU0Miw1LjE2IC0xLjMyLDUuMTYgYyAtMi4wMDIsMCAtMy4xODEsLTAuNjM2IC0zLjYwNSwtMi42NjIgLTAuNDQ3LC0yLjE0NCAwLjU2NiwtMi42MTYgMi40OTgsLTIuNjE2IDAuOTY2LDAgMi4yNjIsMC4xODkgMi43MSwxLjM0MyBIIDAuMzc3IFogTSAtMC43NzgsMy40ODcgQyAwLjExOCwzLjQ4NyAwLjcwNywzLjQxNyAwLjU2NSwyLjcxIDAuMzc3LDEuODM4IDAsMS42NzMgLTEuMTU1LDEuNjczIGMgLTAuNDI0LDAgLTEuMjAxLDAgLTEuMDEzLDAuOTE5IDAuMTY1LDAuNzc4IDAuNzA3LDAuODk1IDEuMzksMC44OTUiIC8+PC9nPjxnCiAgICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZTtmaWxsLW9wYWNpdHk6MSIKICAgICAgICAgICAgIHRyYW5zZm9ybT0idHJhbnNsYXRlKDU1MS45OSw3MzYuMjc2NikiCiAgICAgICAgICAgICBpZD0iZzE0MzgiPjxwYXRoCiAgICAgICAgICAgICAgIGlua3NjYXBlOmNvbm5lY3Rvci1jdXJ2YXR1cmU9IjAiCiAgICAgICAgICAgICAgIGlkPSJwYXRoMTQ0MCIKICAgICAgICAgICAgICAgc3R5bGU9ImZpbGw6d2hpdGU7ZmlsbC1vcGFjaXR5OjE7ZmlsbC1ydWxlOm5vbnplcm87c3Ryb2tlOm5vbmUiCiAgICAgICAgICAgICAgIGQ9Im0gMCwwIC0wLjI1OSwtMS4xNzggaCAwLjExOCBjIDAuNTQyLDAuOTkgMS42NDksMS4yNzIgMi41OTIsMS4yNzIgMS4xNzgsMCAyLjM1NiwtMC4yMTIgMi4xOTEsLTEuNjQ5IEggNC43NiBjIDAuNCwxLjIwMiAxLjYyNiwxLjY0OSAyLjY4NiwxLjY0OSAxLjk1NiwwIDIuNzgxLC0wLjgwMSAyLjM1NiwtMi43NTcgTCA4LjU3NywtOC40MzYgSCA1LjgyIGwgMS4wMzcsNC44NzggYyAwLjE0MSwwLjg3MiAwLjI4MywxLjUzMiAtMC43NzgsMS41MzIgLTEuMDg0LDAgLTEuNDM3LC0wLjcwNyAtMS42MjYsLTEuNjI2IEwgMy40NCwtOC40MzYgSCAwLjY4MyBsIDEuMDg0LDUuMTE0IGMgMC4xNDIsMC43NzcgMC4xODksMS4yOTYgLTAuNzc3LDEuMjk2IC0xLjEzMSwwIC0xLjQ4NSwtMC42MTMgLTEuNjk3LC0xLjYyNiBMIC0xLjcyLC04LjQzNiBIIC00LjQ3NyBMIC0yLjY4NiwwIFoiIC8+PC9nPjxnCiAgICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZTtmaWxsLW9wYWNpdHk6MSIKICAgICAgICAgICAgIHRyYW5zZm9ybT0idHJhbnNsYXRlKDU2Ni45MDU4LDcyNy44NDA4KSIKICAgICAgICAgICAgIGlkPSJnMTQ0MiI+PHBhdGgKICAgICAgICAgICAgICAgaW5rc2NhcGU6Y29ubmVjdG9yLWN1cnZhdHVyZT0iMCIKICAgICAgICAgICAgICAgaWQ9InBhdGgxNDQ0IgogICAgICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZTtmaWxsLW9wYWNpdHk6MTtmaWxsLXJ1bGU6bm9uemVybztzdHJva2U6bm9uZSIKICAgICAgICAgICAgICAgZD0ibSAwLDAgaCAyLjc1NyBsIDEuMTMxLDUuMjU1IGMgMC42MTMsMi44OTggLTAuNDk1LDMuMjUxIC0zLjMyMiwzLjI1MSAtMS45OCwwIC0zLjg4OSwwLjAyNCAtNC40MywtMi41OTEgaCAyLjc1NyBjIDAuMTY0LDAuNzU0IDAuNjM2LDAuOTE4IDEuMzE5LDAuOTE4IDEuMjAyLDAgMS4xNTUsLTAuNDk0IDAuOTksLTEuMjcyIEwgMC45MTksNC4yMTggSCAwLjgwMSBDIDAuNzA3LDUuMTg0IC0wLjUxOCw1LjE2IC0xLjI5Niw1LjE2IGMgLTIuMDAzLDAgLTMuMTgxLC0wLjYzNiAtMy42MDUsLTIuNjYyIC0wLjQ0OCwtMi4xNDQgMC41NjUsLTIuNjE2IDIuNDk3LC0yLjYxNiAwLjk2NywwIDIuMjYzLDAuMTg5IDIuNzEsMS4zNDMgSCAwLjQwMSBaIE0gLTAuNzU0LDMuNDg3IEMgMC4xNDEsMy40ODcgMC43MywzLjQxNyAwLjU4OSwyLjcxIDAuNDAxLDEuODM4IDAuMDI0LDEuNjczIC0xLjEzMSwxLjY3MyBjIC0wLjQyNCwwIC0xLjIwMiwwIC0xLjAxMywwLjkxOSAwLjE2NSwwLjc3OCAwLjcwNywwLjg5NSAxLjM5LDAuODk1IiAvPjwvZz48L2c+PHBhdGgKICAgICAgICAgICBpbmtzY2FwZTpjb25uZWN0b3ItY3VydmF0dXJlPSIwIgogICAgICAgICAgIGlkPSJwYXRoMTQ0OCIKICAgICAgICAgICBzdHlsZT0iZmlsbDp3aGl0ZTtmaWxsLW9wYWNpdHk6MTtmaWxsLXJ1bGU6bm9uemVybztzdHJva2U6bm9uZSIKICAgICAgICAgICBkPSJtIDU3My42Njg1LDcyNy44NDA4IGggLTIuNzU3IGwgMS43NjcsOC40MzYgaCAyLjc4MSB6IiAvPjwvZz48L2c+PC9nPjwvc3ZnPg=="              x="625"  y="300" width="76" height="31"/>
              <image href="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDA5NiIgaGVpZ2h0PSI1MjgiIHZpZXdCb3g9IjAgMCA0MDk2IDUyOCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGcgY2xpcC1wYXRoPSJ1cmwoI2NsaXAwXzNfNjcpIj4KPHBhdGggZD0iTTI5MzQuMTEgMTI0LjY0M0MyODIxLjcyIDEyNC42NDMgMjc0My4yMiAyMDcuNTU3IDI3NDMuMjIgMzI2LjMwM0MyNzQzLjIyIDQ0NS4wNDggMjgyMS43MiA1MjcuOTYyIDI5MzQuMTEgNTI3Ljk2MkMyOTg4LjM1IDUyNy45NjIgMzAzNy4xNyA1MDcuNDk4IDMwNzEuNjEgNDcwLjMxOUMzMTA1LjU3IDQzMy42NTEgMzEyNC4yOCAzODIuMjM0IDMxMjQuMjggMzI1LjUzOEMzMTI0LjI4IDIwNy4yMyAzMDQ2LjA3IDEyNC42MDcgMjkzNC4xMSAxMjQuNjA3VjEyNC42NDNaTTI5MzQuMTEgNDQ2LjkwNUMyODczLjg4IDQ0Ni45MDUgMjgzMS44MiAzOTcuMzEgMjgzMS44MiAzMjYuMzM5QzI4MzEuODIgMjU1LjM2OSAyODczLjg4IDIwNS43NzMgMjkzNC4xMSAyMDUuNzczQzI5OTQuMzQgMjA1Ljc3MyAzMDM1LjY4IDI1NS4wNDEgMzAzNS42OCAzMjUuNjExQzMwMzUuNjggMzk2LjE4MSAyOTkzLjkxIDQ0Ni45NDIgMjkzNC4xMSA0NDYuOTQyVjQ0Ni45MDVaIiBmaWxsPSJ3aGl0ZSIvPgo8cGF0aCBkPSJNMTc3MS44MiAzMy43NTM4SDE2ODIuNDlWMTM2LjY1OUgxNjExLjg0VjIxNy43NTNIMTY4Mi40OVY1MTYuNzFIMTc3MS44MlYyMTcuNzUzSDE4NDMuMTZWMTM2LjY1OUgxNzcxLjgyVjMzLjc1MzhaIiBmaWxsPSJ3aGl0ZSIvPgo8cGF0aCBkPSJNNDA0OS44MiAxNzcuNjI2QzQwMTkuMDIgMTQyLjk2IDM5NzQuMDggMTI0LjY0NCAzOTE5Ljg4IDEyNC42NDRDMzgxMC41NCAxMjQuNjQ0IDM3MzQuMTUgMjA3Ljg4NSAzNzM0LjE1IDMyNy4wNjhDMzczNC4xNSA0NDYuMjUgMzgxMC41NCA1MjcuOTk5IDM5MTkuODggNTI3Ljk5OUMzOTk2LjMxIDUyNy45OTkgNDA1Ni4xNCA0OTAuNjc1IDQwODguMzYgNDIyLjg3Mkw0MDg5LjYzIDQyMC4xNzhMNDAwOS4wNiAzOTMuNzA1TDQwMDguMDUgMzk1LjU2MkMzOTg5LjIzIDQyOS42NDUgMzk1OS4yMiA0NDcuNjM0IDM5MjEuMzMgNDQ3LjYzNEMzODY5Ljc5IDQ0Ny42MzQgMzgzMC45MiA0MTAuODkyIDM4MjEuNjYgMzUzLjcyM0g0MDk0LjMyTDQwOTQuNzIgMzQ3Ljg5NkM0MDk1LjM3IDMzOC4yMSA0MDk1Ljk5IDMyOS4wMzQgNDA5NS45OSAzMTguODM4QzQwOTUuOTkgMjYwLjQ2NyA0MDgwLjAxIDIxMS42MzYgNDA0OS44MiAxNzcuNjYyVjE3Ny42MjZaTTM4MjQuOTYgMjgzLjE1M0MzODM4LjY2IDIzMy42NjYgMzg3My45MyAyMDQuMjQ0IDM5MTkuODUgMjA0LjI0NEMzOTY4LjA5IDIwNC4yNDQgMzk5OS45NCAyMzIuMjQ2IDQwMDkuNzkgMjgzLjE1M0gzODI0Ljk2WiIgZmlsbD0id2hpdGUiLz4KPHBhdGggZD0iTTU1NC41NDggNDQ5LjI3NEM1OTIuMTEgNDA2LjQ1MSA2MTEuMTgxIDM0Mi4zMjYgNjExLjE4MSAyNTguNjQ3VjI1OC4wMjhDNjExLjE4MSAxNzQuMzUgNTkyLjExIDExMC4xODggNTU0LjU0OCA2Ny40MDIzQzUxNi4yMjQgMjMuNzA1NyA0NzkuOTcxIDAuMDM2NzQzMiAzOTguMTI4IDAuMDM2NzQzMkgyMjIuMDkxQzIzMS41MzYgOS43OTU2NCAyNTMuNDQgMzIuNDgxNCAyNjAuNzQyIDM5Ljk4MjdDMjY0LjE5MyA0My41MTQ4IDI2Ni45OSA0Ni4yNDU4IDI2OS4xMzMgNDguMzIxNEwyNjkuNDI0IDQ4LjYxMjdDMjcwLjYyMyA0OS43NzggMjcxLjYwMyA1MC43MjQ3IDI3Mi4yOTQgNTEuNDg5NEMyNzMuMDU3IDUyLjI1NDEgMjczLjU2NSA1Mi44MDAzIDI3My44OTIgNTMuMDkxNkMyODguNDIzIDY3LjY5MzYgMzA1LjM1MSA3My41OTI2IDMzMi40NSA3My41OTI2QzMzMy40NjcgNzMuNTkyNiAzMzUuNDY1IDczLjU5MjYgMzM4LjIyNiA3My41OTI2QzM0NC43MjggNzMuNTU2MiAzNTcuNzMzIDczLjU5MjYgMzcxLjc1NSA3My41OTI2QzM4MC42NTUgNzMuNTkyNiAzODkuOTkxIDczLjU5MjYgMzk4LjM0NiA3My41OTI2QzQ3MC45MjUgNzMuNTkyNiA0OTIuNjEyIDExNi4zNDIgNDk2LjM1NCAxMjUuMjI3QzQ5OS45ODYgMTMwLjMyNSA1MDMuMDAyIDEzNi4wNzkgNTA1LjMyNiAxNDIuMzQyQzUxOC40NCAxNzcuMzcyIDUyNS4xNjEgMjE3LjUzNiA1MjQuNzk3IDI1OC40MjlDNTI1LjE2MSAyOTguNTkzIDUxOC40NCAzMzguNjg1IDUwNS4zMjYgMzc0LjI2MUM0ODIuNDc3IDQzNi4zMSA0MjQuNDY0IDQ0My4wMTEgNDAwLjU2MiA0NDMuMDExSDMzMi40NUMzMDYuMzMxIDQ0My4wMTEgMjgwLjg2NyA0NTQuOTU0IDI2MC43NDIgNDc2LjYyQzI1MS4xMTUgNDg2Ljk5OCAyMzEuNjgxIDUwNy40NjMgMjIzLjAzNSA1MTYuNTY2SDM5OC4wMTlDNDc5LjkzNCA1MTYuNTY2IDUxNi4yMjQgNDkyLjg5NyA1NTQuNTQ4IDQ0OS4yMzdWNDQ5LjI3NFoiIGZpbGw9IndoaXRlIi8+CjxwYXRoIGQ9Ik0zMzkuMTA1IDI1OC4zOTlDMzM5LjEwNSAyNTguMzk5IDMzOS4xMDUgMjU4LjM5OSAzMzkuMTA1IDI1OC4zNjJDMzM5LjEwNSAyNTguMzYyIDMzOS4xMDUgMjU4LjM2MiAzMzkuMTA1IDI1OC4zMjZDMzM5LjEwNSAyNTguMzI2IDMzOS4xMDUgMjU4LjMyNiAzMzkuMTA1IDI1OC4yODlDMzM5Ljc1OSAyMjAuMjM3IDMzMi40NTggMTg2LjcgMzI2LjYwOSAxNjguMzExQzMxOS40MTcgMTQ1LjYyNSAzMTIuMjk3IDEzNy4wNjggMzEwLjA0NCAxMzQuMTkxQzI3NS4yMDggODkuMTEwOSAyMzQuODg1IDEwOC41NTYgMjAwLjM3NSA4NC45OTYxQzE2NS45MDIgNjEuNDcyOCAxNjAuMTI2IDQzLjYzMDEgMTQ3Ljg0OCAzMS4xNDAxQzE0NS43NDEgMjguOTkxNyAxNDEuMDkxIDI0LjI1NzkgMTMzLjg5OCAxOS4zMDU2QzEzMy44OTggMTkuMzA1NiAxMjIuNjM3IDExLjU0OTUgMTA2Ljk4MSA2LjY3MDA1QzkwLjAxNjQgMS4zMTcyMyAzOC44NjkxIC0wLjA2NjQ5NzIgMCAwLjA0Mjc0NDFWNzguMjIzMkgxMTUuOTE3QzEyOS43OTQgNzcuOTMxOCAxNjMuNTQxIDc5LjI0MjcgMTkzLjI5MiAxMDIuNzNDMjA4LjgzOSAxMTUuMDAxIDIxNy4wNDkgMTI4LjM2NSAyMjIuMDk5IDEzNi43MDRDMjQ2LjAwMSAxNzYuMzk1IDI0Ni43MjggMjI0LjY0MyAyNDcuMiAyNTguMjE3VjI1OC4zOTlDMjQ2LjcyOCAyOTEuOTcyIDI0Ni4wMDEgMzQwLjIyIDIyMi4wOTkgMzc5LjkxMUMyMTcuMDg2IDM4OC4yNSAyMDguODM5IDQwMS42NSAxOTMuMjkyIDQxMy44ODZDMTYzLjUwNCA0MzcuMzcyIDEyOS43OTQgNDM4LjY4MyAxMTUuOTE3IDQzOC4zOTJIMFY1MTYuNTcyQzM4Ljg2OTEgNTE2LjcxOCA5MC4wMTY0IDUxNS4yOTggMTA2Ljk4MSA1MDkuOTgxQzEyMi42MzcgNTA1LjA2NiAxMzMuODk4IDQ5Ny4zNDYgMTMzLjg5OCA0OTcuMzQ2QzE0MS4wOTEgNDkyLjM5NCAxNDUuNzQxIDQ4Ny42NiAxNDcuODQ4IDQ4NS41MTFDMTYwLjEyNiA0NzMuMDIxIDE2NS45MDIgNDU1LjIxNSAyMDAuMzc1IDQzMS42NTVDMjM0Ljg0OSA0MDguMTMyIDI3NS4yMDggNDI3LjU3NyAzMTAuMDQ0IDM4Mi40NkMzMTIuMjk3IDM3OS41ODQgMzE5LjQxNyAzNzEuMDI2IDMyNi42MDkgMzQ4LjM0MUMzMzIuNDIxIDMyOS45NTIgMzM5Ljc1OSAyOTYuNDE1IDMzOS4xMDUgMjU4LjM2MlYyNTguMzk5WiIgZmlsbD0id2hpdGUiLz4KPHBhdGggZD0iTTI3MTUuMzkgMjU4LjM5MkMyNzEzLjQ3IDk4Ljc1NDIgMjY1Mi44OCAwIDI0NjQuNzQgMEgyMzEyLjA2SDIzMTIuMUwyMjg0LjE2IDAuMDM2NDEzOFYyNTguMzkyVjUxNi43NDhIMjMxMi4xSDIzMTIuMDZMMjQ2NC43NCA1MTYuNzg0QzI2NTIuODggNTE2Ljc4NCAyNzEzLjQ3IDQxOC4wMyAyNzE1LjM5IDI1OC4zOTJaTTI0NjUuNDcgNDMxLjE3NkgyMzc3Ljg5VjI1OC4zOTJWODUuNjA4OEgyNDY1LjQ3QzI0OTEuNTUgODUuOTM2NSAyNTQ1Ljg5IDg1LjQyNjggMjU3Ny41MyAxMTkuNzI5QzI2MDQuNjMgMTQ5LjA3OCAyNjEzLjQzIDIwNS43NzQgMjYxNC41OSAyNTguMzkyQzI2MTQuNTkgMzE4LjAwMiAyNjA0LjYgMzY3LjcwNiAyNTc3LjUzIDM5Ny4wNTZDMjU0NS44OSA0MzEuMzU4IDI0OTEuNTUgNDMwLjg0OCAyNDY1LjQ3IDQzMS4xNzZaIiBmaWxsPSJ3aGl0ZSIvPgo8cGF0aCBkPSJNMTE3Mi4xOCAyNTguMzkyQzExNzAuMjEgOTguNzU0MiAxMTA5LjY2IDAgOTIxLjQ4OCAwSDc2OC44MDlINzY4Ljg0NUw3NDAuOTEgMC4wMzY0MTM4VjI1OC4zOTJWNTE2Ljc0OEg3NjguODQ1SDc2OC44MDlMOTIxLjQ4OCA1MTYuNzg0QzExMDkuNjIgNTE2Ljc4NCAxMTcwLjIxIDQxOC4wMyAxMTcyLjE0IDI1OC4zOTJIMTE3Mi4xOFpNOTIyLjI1MSA0MzEuMTc2SDgzNC42NjhWMjU4LjM5MlY4NS42MDg4SDkyMi4yNTFDOTQ4LjMzMyA4NS45MzY1IDEwMDIuNjggODUuNDI2OCAxMDM0LjMyIDExOS43MjlDMTA2MS40MiAxNDkuMDc4IDEwNzAuMjEgMjA1Ljc3NCAxMDcxLjM3IDI1OC4zOTJDMTA3MS4zNyAzMTguMDAyIDEwNjEuMzggMzY3LjcwNiAxMDM0LjMyIDM5Ny4wNTZDMTAwMi42OCA0MzEuMzU4IDk0OC4zMzMgNDMwLjg0OCA5MjIuMjUxIDQzMS4xNzZaIiBmaWxsPSJ3aGl0ZSIvPgo8cGF0aCBkPSJNMzU3Ny42NSAxMjYuNjQ4QzM1MjguMjEgMTI2LjY0OCAzNDg3LjIgMTUwLjc5IDM0NjIuMjEgMTk0LjYzM0MzNDYxLjA4IDE5Ni41OTkgMzQ1Ny44NSAxOTYuMzA4IDM0NTcuMDUgMTk0LjE5NkMzNDQwLjc0IDE1MC42NDUgMzQwMy45MSAxMjYuNjg0IDMzNTMuMyAxMjYuNjg0QzMzMDguOTkgMTI2LjY4NCAzMjcyLjg0IDE0Ny42OTUgMzI0OC43NiAxODcuNDk1QzMyNDcuNzggMTg5LjA5OCAzMjQ1Ljg5IDE4OS44MjYgMzI0NC4xNCAxODkuMjQzQzMyNDIuNTQgMTg4LjY5NyAzMjQxLjQ1IDE4Ny4yMDQgMzI0MS40NSAxODUuNTI5VjEzNS43NTFIMzE1My40NFY1MTguNjc5SDMyNDIuOTRWMjk2Ljg0NkMzMjQyLjk0IDI0NC4xNTUgMzI3My43NSAyMDcuMzc3IDMzMTcuODkgMjA3LjM3N0MzMzYyLjAyIDIwNy4zNzcgMzM4Ni4wNyAyNDAuMjU5IDMzODYuMDcgMjk1LjM1M1Y1MTguNjc5SDM0NzQuODVWMjgyLjM1M0MzNDc0Ljg1IDI0MS41MzMgMzUwNy4yNSAyMDcuODg3IDM1NDcuMDcgMjA3LjM3N0MzNTY2LjU0IDIwNy4wODYgMzU4Mi41MiAyMTIuODc2IDM1OTQuMjYgMjI0LjQ5MkMzNjA5LjI5IDIzOS4zNDkgMzYxNy4yMSAyNjMuODU1IDM2MTcuMjEgMjk1LjM1M1Y1MTguNjc5SDM3MDYuNzJWMjgwLjI0MUMzNzA2LjcyIDE4MS4yMzIgMzY2MC44OCAxMjYuNjg0IDM1NzcuNjUgMTI2LjY4NFYxMjYuNjQ4WiIgZmlsbD0id2hpdGUiLz4KPHBhdGggZD0iTTE0OTAuMTQgMTM2LjA3OFYxMzcuOTM1QzE0OTAuMTQgMTQ4Ljg5NiAxNDkwLjE0IDE1Ni44MzQgMTQ5MC4xNCAxNjQuNzM2VjE4NS45MjlDMTQ5MC4xNCAxODcuODk1IDE0ODguNjUgMTg5LjUzNCAxNDg2LjcyIDE4OS42MDdDMTQ4NS40MiAxODkuNjQzIDE0ODQuMjkgMTg5LjAyNCAxNDgzLjYgMTg3Ljk2OEMxNDU3LjIzIDE0Ny40NzYgMTQyMC4xNyAxMjcuODEyIDEzNzAuMzMgMTI3LjgxMkMxMjcxLjA5IDEyNy44MTIgMTIwMS43NCAyMDkuNTYxIDEyMDEuNzQgMzI2LjU5NUMxMjAxLjc0IDQ0My42MjkgMTI3MS4wOSA1MjUuMzc4IDEzNzAuMzMgNTI1LjM3OEMxNDIwLjE0IDUyNS4zNzggMTQ1Ny4xOSA1MDUuNzE1IDE0ODMuNiA0NjUuMjIzQzE0ODQuMjkgNDY0LjE2NyAxNDg1LjQyIDQ2My41MTEgMTQ4Ni43MiA0NjMuNTg0QzE0ODguNjUgNDYzLjY1NyAxNDkwLjE3IDQ2NS4yOTUgMTQ5MC4xNCA0NjcuMjYyVjQ4OC40NTVDMTQ5MC4xIDQ5Ni4zNTYgMTQ5MC4wNyA1MDQuMjk1IDE0OTAuMDcgNTE1LjI1NVY1MTcuMTEySDE1NzYuN1YzMjYuNjMyVjEzNi4xMTVIMTQ5MC4wN0wxNDkwLjE0IDEzNi4wNzhaTTE0OTEuNjMgMzI2LjU5NUMxNDkxLjYzIDMyNi44NSAxNDkxLjYzIDMyNy4wNjkgMTQ5MS42MyAzMjcuMzI0QzE0OTEuNjMgMzk4LjAwMyAxNDUwLjM2IDQ0NS40ODYgMTM4OC45MyA0NDUuNDg2QzEzMjcuNTEgNDQ1LjQ4NiAxMjg5LjIyIDM5Ni41ODMgMTI4OS4yMiAzMjYuNTk1QzEyODkuMjIgMjU2LjYwOCAxMzMwLjIzIDIwNy43MDQgMTM4OC45MyAyMDcuNzA0QzE0NDcuNjQgMjA3LjcwNCAxNDkxLjYzIDI1NS4xODggMTQ5MS42MyAzMjUuODY3QzE0OTEuNjMgMzI2LjEyMiAxNDkxLjYzIDMyNi4zNCAxNDkxLjYzIDMyNi41OTVaIiBmaWxsPSJ3aGl0ZSIvPgo8cGF0aCBkPSJNMjE0NC44OCAxMzYuMDc4VjEzNy45MzVDMjE0NC44OCAxNDguODk2IDIxNDQuODggMTU2LjgzNCAyMTQ0Ljg4IDE2NC43MzZWMTg1LjkyOUMyMTQ0Ljg4IDE4Ny44OTUgMjE0My4zOSAxODkuNTM0IDIxNDEuNDcgMTg5LjYwN0MyMTQwLjE2IDE4OS42NDMgMjEzOS4wMyAxODkuMDI0IDIxMzguMzQgMTg3Ljk2OEMyMTExLjk3IDE0Ny40NzYgMjA3NC45MiAxMjcuODEyIDIwMjUuMDggMTI3LjgxMkMxOTI1LjgzIDEyNy44MTIgMTg1Ni40OSAyMDkuNTYxIDE4NTYuNDkgMzI2LjU5NUMxODU2LjQ5IDQ0My42MjkgMTkyNS44MyA1MjUuMzc4IDIwMjUuMDggNTI1LjM3OEMyMDc0Ljg4IDUyNS4zNzggMjExMS45MyA1MDUuNzE1IDIxMzguMzQgNDY1LjIyM0MyMTM5LjAzIDQ2NC4xNjcgMjE0MC4xNiA0NjMuNTExIDIxNDEuNDcgNDYzLjU4NEMyMTQzLjM5IDQ2My42NTcgMjE0NC45MiA0NjUuMjk1IDIxNDQuODggNDY3LjI2MlY0ODguNDU1QzIxNDQuODUgNDk2LjM1NiAyMTQ0LjgxIDUwNC4yOTUgMjE0NC44MSA1MTUuMjU1VjUxNy4xMTJIMjIzMS40NVYzMjYuNjMyVjEzNi4xMTVIMjE0NC44MUwyMTQ0Ljg4IDEzNi4wNzhaTTIxNDYuMzQgMzI2LjU5NUMyMTQ2LjM0IDMyNi44NSAyMTQ2LjM0IDMyNy4wNjkgMjE0Ni4zNCAzMjcuMzI0QzIxNDYuMzQgMzk4LjAwMyAyMTA1LjA3IDQ0NS40ODYgMjA0My42NCA0NDUuNDg2QzE5ODIuMjEgNDQ1LjQ4NiAxOTQzLjkzIDM5Ni41ODMgMTk0My45MyAzMjYuNTk1QzE5NDMuOTMgMjU2LjYwOCAxOTg0Ljk0IDIwNy43MDQgMjA0My42NCAyMDcuNzA0QzIxMDIuMzQgMjA3LjcwNCAyMTQ2LjM0IDI1NS4xODggMjE0Ni4zNCAzMjUuODY3QzIxNDYuMzQgMzI2LjEyMiAyMTQ2LjM0IDMyNi4zNCAyMTQ2LjM0IDMyNi41OTVaIiBmaWxsPSJ3aGl0ZSIvPgo8L2c+CjxkZWZzPgo8Y2xpcFBhdGggaWQ9ImNsaXAwXzNfNjciPgo8cmVjdCB3aWR0aD0iNDA5NiIgaGVpZ2h0PSI1MjgiIGZpbGw9IndoaXRlIi8+CjwvY2xpcFBhdGg+CjwvZGVmcz4KPC9zdmc+Cg==" x="720"  y="309" width="80" height="10"/>
              <image href="data:image/svg+xml;base64,PHN2ZyB2ZXJzaW9uPSIxLjEiIGlkPSJMYXllcl8xIiB4bWxuczp4PSJuc19leHRlbmQ7IiB4bWxuczppPSJuc19haTsiIHhtbG5zOmdyYXBoPSJuc19ncmFwaHM7IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB4PSIwcHgiIHk9IjBweCIgdmlld0JveD0iMCAwIDMyNiA4OCIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzI2IDg4OyIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSI+CiA8c3R5bGU+CiAgLnN0MHtmaWxsOndoaXRlO30KIDwvc3R5bGU+CiA8bWV0YWRhdGE+CiAgPHNmdyB4bWxucz0ibnNfc2Z3OyI+CiAgIDxzbGljZXM+CiAgIDwvc2xpY2VzPgogICA8c2xpY2VTb3VyY2VCb3VuZHMgYm90dG9tTGVmdE9yaWdpbj0idHJ1ZSIgaGVpZ2h0PSI4OCIgd2lkdGg9IjMyNiIgeD0iLTE3Ny44IiB5PSIwIj4KICAgPC9zbGljZVNvdXJjZUJvdW5kcz4KICA8L3Nmdz4KIDwvbWV0YWRhdGE+CiA8Zz4KICA8cGF0aCBjbGFzcz0ic3QwIiBkPSJNMTMuNCwwSDYuN0gwdjEzLjVoMTMuNFYweiBNMzI1LjksNzQuNWgtNi43aC02LjdWODhoMTMuNFY3NC41eiI+CiAgPC9wYXRoPgogIDxwYXRoIGNsYXNzPSJzdDAiIGQ9Ik0xMy40LDY4LjJIMFYxOS44aDYuN2g2LjdWNjguMnogTTc1LDE4LjhjOS45LDAsMTUuOCw2LjksMTUuOCwxNy45djMxLjVINzcuNVYzOS40YzAtNS4yLTIuMy04LjYtNi45LTguNgoJCWMtMy41LDAtNi42LDIuMi03LjQsNi4zdjMxLjJINDkuN1YzOS40YzAtNS4yLTIuMi04LjYtNi44LTguNmMtMy41LDAtNi43LDIuMi03LjUsNi4zdjMxLjJIMjIuMVYxOS44aDEzLjR2NAoJCWMyLjQtMyw2LjgtNS4xLDEyLjEtNS4xYzUuNywwLDEwLjMsMi42LDEyLjksNi4yQzYzLjYsMjEuNCw2OC4yLDE4LjgsNzUsMTguOHogTTExMi44LDg4SDk5LjRWMTkuOGgxMy40djRjMi4yLTIuNiw2LjktNS4xLDEyLTUuMQoJCWMxNCwwLDIxLjksMTEuNywyMS45LDI1LjNzLTgsMjUuMi0yMS45LDI1LjJjLTUuMiwwLTkuOS0yLjUtMTItNS4xVjg4eiBNMTEyLjgsNTJjMS42LDMuMyw1LjIsNS42LDksNS42YzcuMiwwLDExLjUtNS45LDExLjUtMTMuNQoJCWMwLTcuOC00LjMtMTMuNi0xMS41LTEzLjZjLTQsMC03LjQsMi40LTksNS42VjUyeiBNMTY0LjYsNDcuMWMxLDcuOSw2LjgsMTEuMiwxMy44LDExLjJjNS4zLDAsOS0xLjIsMTMuNy00LjN2MTEuMQoJCWMtNCwyLjktOS4zLDQuMy0xNS44LDQuM2MtMTQuNiwwLTI0LjctOS42LTI0LjctMjQuOWMwLTE1LjIsOS41LTI1LjcsMjIuNi0yNS43YzE0LDAsMjEuMiw5LjgsMjEuMiwyNC4xdjQuNEwxNjQuNiw0Ny4xCgkJTDE2NC42LDQ3LjF6IE0xNjUuMSwzOC40aDE4LjJjLTAuMy01LjItMy4yLTguOS04LjUtOC45QzE3MC40LDI5LjUsMTY2LjYsMzIuMywxNjUuMSwzOC40eiBNMjMxLjksMzMuMWMtMS44LTEtNC4yLTEuNi02LjctMS42CgkJYy00LjUsMC04LjIsMi40LTkuMSw2Ljh2MjkuOWgtMTMuNFYxOS44aDEzLjR2NC43YzIuMS0zLjUsNi01LjksMTAuNy01LjljMi4zLDAsNC4zLDAuNSw1LjEsMC45VjMzLjF6IE0yNTIuNyw2OC4ybC0xOC4yLTQ4LjQKCQloMTMuOWwxMS4xLDMyLjFsMTAuOC0zMi4xaDEzLjVsLTE4LjMsNDguNEgyNTIuN3ogTTMxMi43LDM4YzAtNC42LTQtNy42LTEwLjctNy42Yy00LjgsMC05LjMsMS40LTEzLjEsMy45VjIyLjcKCQljMy41LTIuMiw5LjctNCwxNi00YzEzLjMsMCwyMS4yLDYuOCwyMS4yLDE4Ljd2MzAuOGgtMTMuNHYtMi42Yy0xLjYsMS42LTYuMywzLjUtMTEuNiwzLjVjLTkuNywwLTE3LjgtNS42LTE3LjgtMTUuNwoJCWMwLTkuMiw4LjEtMTUuNCwxOC42LTE1LjRjNC4yLDAsOC44LDEuNCwxMC43LDIuOFYzOHogTTMxMi43LDUxLjVjLTEuMi0yLjYtNC43LTQuMy04LjUtNC4zYy00LjIsMC04LjUsMS44LTguNSw2CgkJYzAsNC4zLDQuMyw2LDguNSw2YzMuOCwwLDcuMy0xLjYsOC41LTQuM1Y1MS41eiI+CiAgPC9wYXRoPgogPC9nPgo8L3N2Zz4="     x="815"  y="304" width="76" height="20"/>
              <image href="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAxMDkuMjEgMzYiPgogICAgICAgICAgPHBhdGggZD0iTTk4Ljk3LDIzLjY3Yy0zLjA1LDAtNS4yLTIuMzgtNS4yLTUuNTFzMi4xNS01LjUxLDUuMi01LjUxLDUuMTQsMi4zOCw1LjE0LDUuNTEtMi4xMiw1LjUxLTUuMTQsNS41MVptLS40OSwzLjI4YzIuNDYsMCw0LjU1LS45Niw1Ljg3LTIuOTcsLjI1LDEuOTUsMS42NiwyLjY2LDMuNDQsMi42NmgxLjQydi0zLjA5aC0uNjFjLTEuMDEsMC0xLjI2LS40OS0xLjI2LTEuNjRWOS42OWgtMy4yNnYyLjUxYy0xLjExLTEuNzYtMy4yLTIuODItNS42LTIuODItNC4yOCwwLTguMjEsMy41OS04LjIxLDguNzhzMy45NCw4Ljc4LDguMjEsOC43OFptLTE2Ljc5LTQuMjRjMCwyLjc4LDEuNzIsMy45MywzLjc4LDMuOTNoMy45N3YtMy4wOWgtMi44OWMtMS4yLDAtMS40NS0uNDYtMS40NS0xLjY0VjEyLjc4aDQuMzR2LTMuMDloLTQuMzRWNGgtMy40MVYyMi43MVptLTE1LjUzLDMuOTNoMy40MXYtNy4yN2gxLjE0bDUuODEsNy4yN2g0LjMxbC03LjQxLTkuMjIsNS42OS03LjczaC0zLjg0bC00LjY1LDYuNTNoLTEuMDVWNGgtMy40MVYyNi42NFptLTExLjA3LTE3LjI2Yy00Ljc3LDAtOC43LDMuNTktOC43LDguNzhzMy45NCw4Ljc4LDguNyw4Ljc4LDguNy0zLjU5LDguNy04Ljc4LTMuOTQtOC43OC04LjctOC43OFptMCwxNC4yOWMtMy4wNSwwLTUuMi0yLjM4LTUuMi01LjUxczIuMTUtNS41MSw1LjItNS41MSw1LjIsMi4zOCw1LjIsNS41MS0yLjE1LDUuNTEtNS4yLDUuNTFaIiBmaWxsPSJ3aGl0ZSI+PC9wYXRoPgogICAgICAgICAgPHBhdGggZD0iTTE5LjgsLjI2bC0uNzQsOS4xMmMtLjM1LS4wNC0uNy0uMDYtMS4wNi0uMDYtLjQ1LDAtLjg5LC4wMy0xLjMyLC4xbC0uNDItNC40MmMtLjAxLS4xNCwuMS0uMjYsLjI0LS4yNmguNzVsLS4zNi00LjQ3Yy0uMDEtLjE0LC4xLS4yNiwuMjMtLjI2aDIuNDVjLjE0LDAsLjI1LC4xMiwuMjMsLjI2aDBabS02LjE4LC40NWMtLjA0LS4xMy0uMTgtLjIxLS4zMS0uMTZsLTIuMywuODRjLS4xMywuMDUtLjE5LC4yLS4xMywuMzJsMS44Nyw0LjA4LS43MSwuMjZjLS4xMywuMDUtLjE5LC4yLS4xMywuMzJsMS45MSw0LjAxYy42OS0uMzgsMS40NC0uNjcsMi4yMy0uODVMMTMuNjMsLjcxWk03Ljk4LDMuMjVsNS4yOSw3LjQ2Yy0uNjcsLjQ0LTEuMjgsLjk2LTEuOCwxLjU2bC0zLjE3LTMuMTJjLS4xLS4xLS4wOS0uMjYsLjAxLS4zNWwuNTgtLjQ4LTMuMTUtMy4xOWMtLjEtLjEtLjA5LS4yNiwuMDItLjM1bDEuODctMS41N2MuMTEtLjA5LC4yNi0uMDcsLjM0LC4wNFpNMy41NCw3LjU3Yy0uMTEtLjA4LS4yNy0uMDQtLjM0LC4wOGwtMS4yMiwyLjEyYy0uMDcsLjEyLS4wMiwuMjcsLjEsLjMzbDQuMDYsMS45Mi0uMzgsLjY1Yy0uMDcsLjEyLS4wMiwuMjgsLjExLC4zM2w0LjA0LDEuODVjLjI5LS43NSwuNjgtMS40NSwxLjE2LTIuMDhMMy41NCw3LjU3Wk0uNTUsMTMuMzNjLjAyLS4xNCwuMTYtLjIyLC4yOS0uMTlsOC44NSwyLjMxYy0uMjMsLjc1LS4zNiwxLjU0LS4zOCwyLjM2bC00LjQzLS4zNmMtLjE0LS4wMS0uMjQtLjE0LS4yMS0uMjhsLjEzLS43NC00LjQ3LS40MmMtLjE0LS4wMS0uMjMtLjE0LS4yMS0uMjhsLjQyLTIuNDFoMFptLS4zMyw1Ljk4Yy0uMTQsLjAxLS4yMywuMTQtLjIxLC4yOGwuNDMsMi40MWMuMDIsLjE0LC4xNiwuMjIsLjI5LC4xOWw0LjM0LTEuMTMsLjEzLC43NGMuMDIsLjE0LC4xNiwuMjIsLjI5LC4xOWw0LjI4LTEuMThjLS4yNS0uNzQtLjQxLTEuNTMtLjQ1LTIuMzRMLjIxLDE5LjMxWm0xLjQyLDYuMzRjLS4wNy0uMTItLjAyLS4yNywuMS0uMzNsOC4yNi0zLjkyYy4zMSwuNzQsLjczLDEuNDMsMS4yMywyLjA1bC0zLjYyLDIuNThjLS4xMSwuMDgtLjI3LC4wNS0uMzQtLjA3bC0uMzgtLjY2LTMuNjksMi41NWMtLjExLC4wOC0uMjcsLjA0LS4zNC0uMDhsLTEuMjMtMi4xMlptMTAuMDEtMS43MmwtNi40Myw2LjUxYy0uMSwuMS0uMDksLjI2LC4wMiwuMzVsMS44OCwxLjU3Yy4xMSwuMDksLjI2LC4wNywuMzQtLjA0bDIuNi0zLjY2LC41OCwuNDljLjExLC4wOSwuMjcsLjA3LC4zNS0uMDVsMi41Mi0zLjY2Yy0uNjgtLjQyLTEuMzEtLjkzLTEuODUtMS41MVptLTEuMjcsMTAuNDVjLS4xMy0uMDUtLjE5LS4yLS4xMy0uMzJsMy44MS04LjMyYy43LC4zNiwxLjQ2LC42MywyLjI1LC43OGwtMS4xMiw0LjNjLS4wMywuMTMtLjE4LC4yMS0uMzEsLjE2bC0uNzEtLjI2LTEuMTksNC4zM2MtLjA0LC4xMy0uMTgsLjIxLS4zMSwuMTZsLTIuMy0uODRoMFptNi41Ni03Ljc1bC0uNzQsOS4xMmMtLjAxLC4xNCwuMSwuMjYsLjIzLC4yNmgyLjQ1Yy4xNCwwLC4yNS0uMTIsLjIzLS4yNmwtLjM2LTQuNDdoLjc1Yy4xNCwwLC4yNS0uMTIsLjI0LS4yNmwtLjQyLTQuNDJjLS40MywuMDctLjg3LC4xLTEuMzIsLjEtLjM2LDAtLjcxLS4wMi0xLjA2LS4wN2gwWk0yNS43NiwxLjk0Yy4wNi0uMTMsMC0uMjctLjEzLS4zMmwtMi4zLS44NGMtLjEzLS4wNS0uMjcsLjAzLS4zMSwuMTZsLTEuMTksNC4zMy0uNzEtLjI2Yy0uMTMtLjA1LS4yNywuMDMtLjMxLC4xNmwtMS4xMiw0LjNjLjgsLjE2LDEuNTUsLjQzLDIuMjUsLjc4TDI1Ljc2LDEuOTRoMFptNS4wMiwzLjYzbC02LjQzLDYuNTFjLS41NC0uNTgtMS4xNi0xLjA5LTEuODUtMS41MWwyLjUyLTMuNjZjLjA4LS4xMSwuMjQtLjE0LC4zNS0uMDVsLjU4LC40OSwyLjYtMy42NmMuMDgtLjExLC4yNC0uMTMsLjM0LS4wNGwxLjg4LDEuNTdjLjExLC4wOSwuMTEsLjI1LC4wMiwuMzVabTMuNDgsNS4xMmMuMTMtLjA2LC4xNy0uMjEsLjEtLjMzbC0xLjIzLTIuMTJjLS4wNy0uMTItLjIzLS4xNS0uMzQtLjA4bC0zLjY5LDIuNTUtLjM4LS42NWMtLjA3LS4xMi0uMjMtLjE2LS4zNC0uMDdsLTMuNjIsMi41OGMuNSwuNjIsLjkxLDEuMzEsMS4yMywyLjA1bDguMjYtMy45MlptMS4zLDMuMzJsLjQyLDIuNDFjLjAyLC4xNC0uMDcsLjI2LS4yMSwuMjhsLTkuMTEsLjg1Yy0uMDQtLjgyLS4yLTEuNi0uNDUtMi4zNGw0LjI4LTEuMThjLjEzLS4wNCwuMjcsLjA1LC4yOSwuMTlsLjEzLC43NCw0LjM0LTEuMTNjLjEzLS4wMywuMjcsLjA1LC4yOSwuMTloMFptLS40MSw4Ljg1Yy4xMywuMDMsLjI3LS4wNSwuMjktLjE5bC40Mi0yLjQxYy4wMi0uMTQtLjA3LS4yNi0uMjEtLjI4bC00LjQ3LS40MiwuMTMtLjc0Yy4wMi0uMTQtLjA3LS4yNi0uMjEtLjI4bC00LjQzLS4zNmMtLjAyLC44Mi0uMTUsMS42MS0uMzgsMi4zNmw4Ljg1LDIuMzFoMFptLTIuMzYsNS41Yy0uMDcsLjEyLS4yMywuMTUtLjM0LC4wOGwtNy41My01LjJjLjQ4LS42MywuODctMS4zMywxLjE2LTIuMDhsNC4wNCwxLjg1Yy4xMywuMDYsLjE4LC4yMSwuMTEsLjMzbC0uMzgsLjY1LDQuMDYsMS45MmMuMTIsLjA2LC4xNywuMjEsLjEsLjMzbC0xLjIyLDIuMTJoMFptLTEwLjA3LTMuMDdsNS4yOSw3LjQ2Yy4wOCwuMTEsLjI0LC4xMywuMzQsLjA0bDEuODctMS41N2MuMTEtLjA5LC4xMS0uMjUsLjAyLS4zNWwtMy4xNS0zLjE5LC41OC0uNDhjLjExLS4wOSwuMTEtLjI1LC4wMS0uMzVsLTMuMTctMy4xMmMtLjUzLC42LTEuMTMsMS4xMy0xLjgsMS41NmgwWm0tLjA1LDEwLjE2Yy0uMTMsLjA1LS4yNy0uMDMtLjMxLS4xNmwtMi40Mi04LjgyYy43OS0uMTgsMS41NC0uNDcsMi4yMy0uODVsMS45MSw0LjAxYy4wNiwuMTMsMCwuMjgtLjEzLC4zMmwtLjcxLC4yNiwxLjg3LDQuMDhjLjA2LC4xMywwLC4yNy0uMTMsLjMybC0yLjMsLjg0aDBaIiBmaWxsPSJ3aGl0ZSIgZmlsbC1ydWxlPSJldmVub2RkIj48L3BhdGg+CiAgICAgICAgPC9zdmc+"         x="910"  y="302" width="72" height="24"/>
              <image href="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+CjwhLS0gR2VuZXJhdG9yOiBBZG9iZSBJbGx1c3RyYXRvciAxOS4wLjAsIFNWRyBFeHBvcnQgUGx1Zy1JbiAuIFNWRyBWZXJzaW9uOiA2LjAwIEJ1aWxkIDApICAtLT4KCjxzdmcKICAgdmVyc2lvbj0iMS4xIgogICBpZD0ibGF5ZXIiCiAgIHg9IjBweCIKICAgeT0iMHB4IgogICB2aWV3Qm94PSItMTUzIC00NiAyMjM1LjQ0NjUgNzIwIgogICB4bWw6c3BhY2U9InByZXNlcnZlIgogICBzb2RpcG9kaTpkb2NuYW1lPSJhdXRoMC1pbmMtbG9nby12ZWN0b3Iuc3ZnIgogICB3aWR0aD0iMjIzNS40NDY1IgogICBoZWlnaHQ9IjcyMCIKICAgaW5rc2NhcGU6dmVyc2lvbj0iMS4xIChjNjhlMjJjMzg3LCAyMDIxLTA1LTIzKSIKICAgeG1sbnM6aW5rc2NhcGU9Imh0dHA6Ly93d3cuaW5rc2NhcGUub3JnL25hbWVzcGFjZXMvaW5rc2NhcGUiCiAgIHhtbG5zOnNvZGlwb2RpPSJodHRwOi8vc29kaXBvZGkuc291cmNlZm9yZ2UubmV0L0RURC9zb2RpcG9kaS0wLmR0ZCIKICAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogICB4bWxuczpzdmc9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZGVmcwogICBpZD0iZGVmczExIiAvPjxzb2RpcG9kaTpuYW1lZHZpZXcKICAgaWQ9Im5hbWVkdmlldzkiCiAgIHBhZ2Vjb2xvcj0iI2ZmZmZmZiIKICAgYm9yZGVyY29sb3I9IiM2NjY2NjYiCiAgIGJvcmRlcm9wYWNpdHk9IjEuMCIKICAgaW5rc2NhcGU6cGFnZXNoYWRvdz0iMiIKICAgaW5rc2NhcGU6cGFnZW9wYWNpdHk9IjAuMCIKICAgaW5rc2NhcGU6cGFnZWNoZWNrZXJib2FyZD0iMCIKICAgc2hvd2dyaWQ9ImZhbHNlIgogICBmaXQtbWFyZ2luLXRvcD0iMCIKICAgZml0LW1hcmdpbi1sZWZ0PSIwIgogICBmaXQtbWFyZ2luLXJpZ2h0PSIwIgogICBmaXQtbWFyZ2luLWJvdHRvbT0iMCIKICAgaW5rc2NhcGU6em9vbT0iMC4zMTkwMTg0MSIKICAgaW5rc2NhcGU6Y3g9IjczNS4wNjczMSIKICAgaW5rc2NhcGU6Y3k9IjM2Mi4wNDgwOCIKICAgaW5rc2NhcGU6d2luZG93LXdpZHRoPSIxOTIwIgogICBpbmtzY2FwZTp3aW5kb3ctaGVpZ2h0PSIxMDE3IgogICBpbmtzY2FwZTp3aW5kb3cteD0iMTkxMiIKICAgaW5rc2NhcGU6d2luZG93LXk9Ii04IgogICBpbmtzY2FwZTp3aW5kb3ctbWF4aW1pemVkPSIxIgogICBpbmtzY2FwZTpjdXJyZW50LWxheWVyPSJsYXllciIgLz4KPHN0eWxlPgoJLnN0MHtmaWxsOndoaXRlO30KPC9zdHlsZT4KPHBhdGgKICAgY2xhc3M9InN0MCIKICAgZD0iTSAzNjAuMzM0ODQsNTM2LjQ4NDQ3IDI4OC4wMzY3LDMxNCA0NzcuMzUzNDcsMTc2LjQ4NDQ3IGMgNDYuNTgzODYsMTQyLjczMjkyIDAsMjc1LjAzMTA2IC0xMTcuMDE4NjMsMzYwIHogbSAxMTcuMDE4NjMsLTM2MCBMIDQwNS4wNTUzNCwtNDYgSCAxNzEuMDE4MDcgbCA3MS45MjU0NywyMjIuNDg0NDcgYyAwLDAgMjM0LjQwOTkzLDAgMjM0LjQwOTkzLDAgeiBNIDE3MS4wMTgwNywtNDYgSCAtNjMuMDE5MjAyIEwgLTEzNC45NDQ2NiwxNzYuNDg0NDcgSCA5OS4wOTI1OTUgWiBtIC0zMDYuMzM1NCwyMjIuNDg0NDcgYyAtNDYuMjExMTgsMTQyLjczMjkyIDAsMjc1LjAzMTA2IDExNy4wMTg2MjUsMzYwIEwgNTMuNjI2NzYxLDMxNCBaIG0gMTE3LjAxODYyNSwzNjAgTCAxNzEuMDE4MDcsNjc0IDM2MC4zMzQ4NCw1MzYuNDg0NDcgMTcxLjAxODA3LDM5OC45Njg5NCBaIgogICBpZD0icGF0aDQiCiAgIHN0eWxlPSJzdHJva2Utd2lkdGg6My43MjY3MSIgLz4KPHBhdGgKICAgZD0ibSA4MjQuNjgyNjcsODguOTA2ODMgYyAtMzAuMTg2MzQsMCAtNTYuNjQ1OTcsMTkuNzUxNTYgLTY1LjIxNzM5LDQ4LjgxOTg4IEwgNjU1Ljg2Mjc5LDQ5NCBoIDY4LjE5ODc2IGwgMzAuNTU5LC0xMDMuMjI5ODEgYyAwLjM3MjY4LC0xLjExODAyIDEuMTE4MDIsLTEuODYzMzYgMi4yMzYwMywtMS44NjMzNiBoIDEzNi43NzAxOSBjIDEuMTE4MDEsMCAxLjg2MzM1LDAuNzQ1MzQgMi4yMzYwMiwxLjg2MzM2IEwgOTI1LjY3NjQ2LDQ5NCBoIDY3LjgyNjA5IEwgODg5LjUyNzM5LDEzNy43MjY3MSBDIDg4MS4zMjg2MywxMDguNjU4MzkgODU0Ljg2OSw4OC45MDY4MyA4MjQuNjgyNjcsODguOTA2ODMgWiBtIDU0LjQwOTkzLDI0OC41NzE0MyBjIC0wLjM3MjY3LDAuNzQ1MzQgLTEuMTE4MDEsMC43NDUzNCAtMS44NjMzNSwwLjc0NTM0IEggNzcyLjg4MTQyIGMgLTAuNzQ1MzQsMCAtMS40OTA2OCwtMC4zNzI2NyAtMS44NjMzNSwtMC43NDUzNCAtMC4zNzI2NywtMC43NDUzNCAtMC4zNzI2NywtMS40OTA2OCAwLC0yLjIzNjAyIGwgNTEuODAxMjQsLTE3OS42MjczMyBjIDAuMzcyNjcsLTEuMTE4MDIgMS4xMTgwMiwtMS44NjMzNiAyLjIzNjAzLC0xLjg2MzM2IDEuMTE4MDEsMC4zNzI2NyAxLjQ5MDY4LDEuMTE4MDIgMS44NjMzNSwxLjg2MzM2IGwgNTIuMTczOTEsMTc5LjYyNzMzIGMgMCwwLjc0NTM0IDAsMS40OTA2OCAwLDIuMjM2MDIgeiBtIDMxNi43NzAxLC05OC43NTc3NiBoIDY1LjU5MDEgdiAyNTUuNjUyMTcgaCAtNTEuNDI4NiBsIC03LjA4MDcsLTIxLjYxNDkxIGMgLTAuMzcyNywtMC43NDUzNCAtMC43NDU0LC0xLjQ5MDY4IC0xLjQ5MDcsLTEuODYzMzUgLTAuNzQ1MywtMC4zNzI2NyAtMS40OTA3LC0wLjM3MjY3IC0yLjIzNiwwIC0yNC4yMjM2LDE4LjI2MDg3IC01My4yOTE5LDI4LjMyMjk4IC04My40NzgzLDI4LjY5NTY1IC0zNC4yODU3LDAgLTY1LjU5LC0yMC40OTY4OSAtNzkuMDA2MiwtNTIuMTczOTEgLTQuNDcyLC0xMC40MzQ3OCAtNi43MDgxLC0yMS4yNDIyNCAtNi43MDgxLC0zMi40MjIzNiBWIDIzOC43MjA1IGggNjUuNTkwMSB2IDE3Mi41NDY1OCBjIDAsMjAuNDk2OSAxNy4xNDI5LDM3LjI2NzA4IDM3LjYzOTcsMzcuMjY3MDggMjEuMjQyMywtMS4xMTgwMSA0Mi4xMTE4LC02LjcwODA3IDYwLjc0NTQsLTE2Ljc3MDE4IDAuNzQ1MywtMC4zNzI2OCAxLjQ5MDcsLTEuMTE4MDIgMS4xMTgsLTEuODYzMzYgeiBtIDU1NS4yNzk1LDc5LjAwNjIxIHYgMTc2LjY0NTk2IGggLTY1LjIxNzMgViAzMjEuNDUzNDIgYyAwLC05LjY4OTQ0IC00LjA5OTQsLTE5LjM3ODg5IC0xMS4xODAyLC0yNi4wODY5NiAtNy4wODA3LC03LjA4MDc1IC0xNi4zOTc1LC0xMC44MDc0NSAtMjYuNDU5NiwtMTAuODA3NDUgLTIxLjI0MjIsMS4xMTgwMSAtNDIuMTExOCw2LjcwODA3IC02MS4xMTgsMTYuNzcwMTggLTAuNzQ1NCwwLjM3MjY3IC0xLjExOCwxLjExODAxIC0xLjExOCwyLjIzNjAzIFYgNDk0LjM3MjY3IEggMTUyMC40NTkgViA5NC40OTY4OSBoIDY1LjU5MDEgdiAxNjAuMjQ4NDUgYyAwLDAuNzQ1MzQgMC4zNzI2LDEuODYzMzYgMS4xMTgsMi4yMzYwMyAwLjc0NTMsMC4zNzI2NyAxLjg2MzMsMC4zNzI2NyAyLjYwODcsMCAyMi43MzI5LC0xNC45MDY4NCA0OS4xOTI1LC0yMy4xMDU1OSA3Ni4wMjQ4LC0yMy40NzgyNiA0Ni41ODM5LDAuMzcyNjcgODQuMjIzNiwzNy42Mzk3NSA4NC41OTYzLDg0LjIyMzYgeiBtIC0zMzMuOTEzLC03OS4wMDYyMSBoIDM5Ljg3NTggdiA1MC42ODMyMyBoIC0zOS44NzU4IGMgLTAuNzQ1MywwIC0xLjExOCwwLjM3MjY3IC0xLjg2MzQsMC43NDUzNCAtMC4zNzI2LDAuMzcyNjcgLTAuNzQ1MywxLjExODAxIC0wLjc0NTMsMS44NjMzNSB2IDEzNy4xNDI4NiBjIDAsMTAuODA3NDUgOC45NDQxLDE5Ljc1MTU1IDIwLjEyNDIsMTkuNzUxNTUgMCwwIDAsMCAwLDAgNS45NjI4LDAgMTQuNTM0MiwwIDIyLjM2MDMsLTEuMTE4MDEgViA0OTQgYyAtMTMuMDQzNSwzLjcyNjcxIC0yNi40NTk3LDUuOTYyNzMgLTM5Ljg3NTgsNS41OTAwNiAtMzcuMjY3MSwwIC02Ny40NTM0LC0yOS44MTM2NiAtNjcuODI2MSwtNjcuMDgwNzQgViAyOTEuNjM5NzUgYyAwLC0xLjQ5MDY4IC0xLjExOCwtMi4yMzYwMiAtMi42MDg3LC0yLjYwODY5IGggLTM5LjEzMDQgdiAtNTAuNjgzMjMgaCAzOS44NzU4IGMgMS40OTA2LDAgMi4yMzYsLTEuMTE4MDIgMi42MDg3LC0yLjYwODcgdiAtODQuMjIzNiBoIDY1LjU5IHYgODQuMjIzNiBjIC0wLjM3MjcsMS40OTA2OCAwLjM3MjcsMi42MDg3IDEuNDkwNywyLjk4MTM3IHogbSA2MjYuNDU5NiwtOTIuNzk1MDMgYyAtMjIuMzYwMiwtMzUuNDAzNzMgLTYxLjExOCwtNTYuNjQ1OTcgLTEwMi44NTcxLC01Ni42NDU5NyAtNDEuNzM5MSwwIC04MC40OTY5LDIxLjI0MjI0IC0xMDIuODU3Miw1Ni42NDU5NyAtMjQuOTY4OSwzNi41MjE3MyAtMzguMzg1MSw4Ny45NTAzMSAtMzguMzg1MSwxNDguNjk1NjUgLTIuMjM2LDUyLjU0NjU4IDExLjU1MjgsMTA0LjM0NzgyIDM4Ljc1NzgsMTQ5LjA2ODMyIDIyLjM2MDMsMzUuNDAzNzMgNjEuMTE4LDU2LjY0NTk2IDEwMi44NTcyLDU2LjY0NTk2IDQxLjczOTEsMCA4MC40OTY5LC0yMS4yNDIyMyAxMDIuODU3MSwtNTYuNjQ1OTYgMjUuMzQxNiwtMzYuODk0NDEgMzguMzg1MSwtODguMzIyOTggMzguMzg1MSwtMTQ4LjY5NTY1IDAsLTYwLjM3MjY3IC0xMy40MTYyLC0xMTIuNTQ2NTkgLTM4LjM4NTEsLTE0OS4wNjgzMiB6IG0gLTUzLjY2NDYsMjY4LjY5NTY1IGMgLTEyLjY3MDgsMjMuMTA1NTkgLTI4LjY5NTYsMzQuMjg1NzEgLTQ4LjgxOTgsMzQuMjg1NzEgLTE5Ljc1MTYsMCAtMzUuNzc2NCwtMTEuOTI1NDYgLTQ4LjgxOTksLTM0LjI4NTcxIC0xNy4xNDI5LC0zNy42Mzk3NSAtMjUuMzQxNiwtNzguNjMzNTQgLTIzLjQ3ODMsLTEyMCAtMS44NjMzLC00MS4zNjY0NiA2LjMzNTQsLTgyLjczMjkyIDIzLjQ3ODMsLTEyMC43NDUzNCAxMi42NzA4LC0yMy4xMDU1OSAyOC42OTU2LC0zNC4yODU3MiA0OC40NDcyLC0zNC4yODU3MiAxOS43NTE1LDAgMzYuMTQ5MSwxMS4xODAxMyA0OC44MTk5LDM0LjI4NTcyIDE3LjE0MjgsMzcuNjM5NzUgMjUuMzQxNiw3OC42MzM1NCAyMy40NzgyLDEyMCAyLjIzNiw0MS43MzkxMyAtNS41OSw4My4xMDU1OSAtMjMuMTA1NiwxMjAuNzQ1MzQgeiIKICAgaWQ9InBhdGg2IgogICBzdHlsZT0ic3Ryb2tlLXdpZHRoOjMuNzI2NzEiIC8+Cjwvc3ZnPgo="            x="1005" y="303" width="72" height="23"/>
              <image href="data:image/svg+xml;base64,PHN2ZyBhcmlhLWhpZGRlbj0idHJ1ZSIgZmlsbD0ibm9uZSIgaGVpZ2h0PSIyNCIgc3R5bGU9Im1hcmdpbi1ib3R0b206MHJlbSIgdmlld0JveD0iMCAwIDEyMyAyNCIgd2lkdGg9IjEyMyIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik05LjM0MzA0IDEzLjE0MjhIMC4yMDAxOTVDMC43NzU2OTEgMTkuMjM0MiA1LjkwNDUyIDI0IDEyLjE0NjUgMjRDMTMuNzY1MSAyNCAxNS4zMDg5IDIzLjY3OTUgMTYuNzE3OSAyMy4wOTg1QzEyLjY5MzUgMjEuNDM5MSA5Ljc2OTMgMTcuNjU0NiA5LjM0MzA0IDEzLjE0MjhaIiBmaWxsPSJ3aGl0ZSIgZmlsbC1ydWxlPSJldmVub2RkIj48L3BhdGg+PHBhdGggZD0iTTkuMzQzMDQgMTAuODU3MUM5Ljc2OTMgNi4zNDU0IDEyLjY5MzUgMi41NjA4NyAxNi43MTc5IDAuOTAxNDU5QzE1LjMwODkgMC4zMjA0ODQgMTMuNzY1MSAwIDEyLjE0NjUgMEM1LjkwNDUyIDAgMC43NzU2OTEgNC43NjU3OSAwLjIwMDE5NSAxMC44NTcxSDkuMzQzMDRaIiBmaWxsPSJ3aGl0ZSI+PC9wYXRoPjxwYXRoIGNsaXAtcnVsZT0iZXZlbm9kZCIgZD0iTTE0LjY2MTUgMTQuODU3MkMxMy43NDc0IDE4LjU5OTggMTEuMDc4IDIxLjY1NDIgNy41NzUyIDIzLjA5ODZDOC45ODQxNSAyMy42Nzk1IDEwLjUyOCAyNCAxMi4xNDY2IDI0QzE3Ljc4OTQgMjQgMjIuNTIyNiAyMC4xMDUyIDIzLjgwNDQgMTQuODU3MkgxNC42NjE1WiIgZmlsbD0id2hpdGUiIGZpbGwtcnVsZT0iZXZlbm9kZCI+PC9wYXRoPjxwYXRoIGQ9Ik0yMy43ODY4IDkuMTQyODZIMTQuNjQ0QzEzLjcyOTkgNS40MDAyNSAxMS4wNjA1IDIuMzQ1ODMgNy41NTc2MiAwLjkwMTQ1OUM4Ljk2NjU4IDAuMzIwNDgzIDEwLjUxMDQgMCAxMi4xMjkgMEMxNy43NzE5IDAgMjIuNTA1IDMuODk0ODQgMjMuNzg2OCA5LjE0Mjg2WiIgZmlsbD0id2hpdGUiPjwvcGF0aD48cGF0aCBkPSJNNDYuMDk2NCA5LjgwODc3QzQ1LjY5MTMgNi40NDk0IDQzLjE0NzQgNC41MTc1OCAzOS43NzkxIDQuNTE3NThDMzUuOTM0OCA0LjUxNzU4IDMzIDcuMjMwNjUgMzMgMTEuOTg5MkMzMyAxNi43MzM1IDM1Ljg4NSAxOS40NjA4IDM5Ljc3OTEgMTkuNDYwOEM0My41MDk4IDE5LjQ2MDggNDUuNzYyNCAxNi45ODIxIDQ2LjA5NjQgMTQuMzA0NUw0Mi45ODQgMTQuMjkwM0M0Mi42OTI2IDE1Ljg0NTcgNDEuNDcwNCAxNi43NDA2IDM5LjgyODkgMTYuNzQwNkMzNy42MTg5IDE2Ljc0MDYgMzYuMTE5NSAxNS4xIDM2LjExOTUgMTEuOTg5MkMzNi4xMTk1IDguOTYzNiAzNy41OTc2IDcuMjM3NzUgMzkuODUwMiA3LjIzNzc1QzQxLjUzNDMgNy4yMzc3NSA0Mi43NDk1IDguMjEwNzYgNDIuOTg0IDkuODA4NzdINDYuMDk2NFoiIGZpbGw9ImN1cnJlbnRDb2xvciI+PC9wYXRoPjxwYXRoIGQ9Ik01Mi4yMTAxIDE5LjQ3NUM1NC45MTA0IDE5LjQ3NSA1Ni43Mjk1IDE4LjE2MSA1Ny4xNTU5IDE2LjEzNjlMNTQuMzU2MSAxNS45NTIyQzU0LjA1MDYgMTYuNzgzMiA1My4yNjg5IDE3LjIxNjQgNTIuMjU5OSAxNy4yMTY0QzUwLjc0NjMgMTcuMjE2NCA0OS43ODcgMTYuMjE1IDQ5Ljc4NyAxNC41ODg2VjE0LjU4MTVINTcuMjE5OFYxMy43NTA1QzU3LjIxOTggMTAuMDQzMSA1NC45NzQzIDguMjEwNzYgNTIuMDg5MyA4LjIxMDc2QzQ4Ljg3NzQgOC4yMTA3NiA0Ni43OTUzIDEwLjQ5MDYgNDYuNzk1MyAxMy44NTcxQzQ2Ljc5NTMgMTcuMzE1OSA0OC44NDkgMTkuNDc1IDUyLjIxMDEgMTkuNDc1Wk00OS43ODcgMTIuNzA2NUM0OS44NTA5IDExLjQ2MzYgNTAuNzk2IDEwLjQ2OTMgNTIuMTM5IDEwLjQ2OTNDNTMuNDUzNyAxMC40NjkzIDU0LjM2MzIgMTEuNDA2OCA1NC4zNzAzIDEyLjcwNjVINDkuNzg3WiIgZmlsbD0iY3VycmVudENvbG9yIj48L3BhdGg+PHBhdGggZD0iTTY4LjUyMDMgMjMuMzUyOFY4LjM1MjgxSDY1LjUzNThWMTAuMTg1Mkg2NS40MDA4QzY0Ljk5NTcgOS4yOTc0MSA2NC4xMjE3IDguMjEwNzYgNjIuMjk1NSA4LjIxMDc2QzU5LjkwMDcgOC4yMTA3NiA1Ny44NzU1IDEwLjA3MTYgNTcuODc1NSAxMy44MjE2QzU3Ljg3NTUgMTcuNDcyMSA1OS44MTU1IDE5LjQzOTUgNjIuMzAyNiAxOS40Mzk1QzY0LjA2NDggMTkuNDM5NSA2NC45ODE1IDE4LjQyMzggNjUuNDAwOCAxNy41MTQ3SDY1LjQ5MzJWMjMuMzUyOEg2OC41MjAzWk02NS41NTcxIDEzLjgwNzRDNjUuNTU3MSAxNS43NTM0IDY0LjcxODYgMTcuMDMxOCA2My4yNjE5IDE3LjAzMThDNjEuNzc2NyAxNy4wMzE4IDYwLjk2NjYgMTUuNzEwOCA2MC45NjY2IDEzLjgwNzRDNjAuOTY2NiAxMS45MTgxIDYxLjc2MjUgMTAuNjE4NCA2My4yNjE5IDEwLjYxODRDNjQuNzMyOCAxMC42MTg0IDY1LjU1NzEgMTEuODYxMyA2NS41NTcxIDEzLjgwNzRaIiBmaWxsPSJjdXJyZW50Q29sb3IiPjwvcGF0aD48cGF0aCBkPSJNNzYuNTA0IDE0LjYxN0M3Ni41MTEyIDE2LjA4MDEgNzUuNTA5MiAxNi44NDcxIDc0LjQyMiAxNi44NDcxQzczLjI3NzkgMTYuODQ3MSA3Mi41Mzg5IDE2LjA0NDYgNzIuNTMxOCAxNC43NTkxVjguMzUyODFINjkuNTA0NlYxNS4yOTg4QzY5LjUxMTcgMTcuODQ4NSA3MS4wMDQgMTkuNDAzOSA3My4xOTk4IDE5LjQwMzlDNzQuODQxMiAxOS40MDM5IDc2LjAyMDggMTguNTU4OCA3Ni41MTEyIDE3LjI4MDRINzYuNjI0OVYxOS4yNjE5SDc5LjUzMTJWOC4zNTI4MUg3Ni41MDRWMTQuNjE3WiIgZmlsbD0iY3VycmVudENvbG9yIj48L3BhdGg+PHBhdGggZD0iTTg1LjYzMDkgMTkuNDc1Qzg4LjMzMTIgMTkuNDc1IDkwLjE1MDMgMTguMTYxIDkwLjU3NjcgMTYuMTM2OUw4Ny43NzY5IDE1Ljk1MjJDODcuNDcxMyAxNi43ODMyIDg2LjY4OTcgMTcuMjE2NCA4NS42ODA2IDE3LjIxNjRDODQuMTY3IDE3LjIxNjQgODMuMjA3NyAxNi4yMTUgODMuMjA3NyAxNC41ODg2VjE0LjU4MTVIOTAuNjQwNlYxMy43NTA1QzkwLjY0MDYgMTAuMDQzMSA4OC4zOTUxIDguMjEwNzYgODUuNTEwMSA4LjIxMDc2QzgyLjI5ODIgOC4yMTA3NiA4MC4yMTYxIDEwLjQ5MDYgODAuMjE2MSAxMy44NTcxQzgwLjIxNjEgMTcuMzE1OSA4Mi4yNjk3IDE5LjQ3NSA4NS42MzA5IDE5LjQ3NVpNODMuMjA3NyAxMi43MDY1QzgzLjI3MTcgMTEuNDYzNiA4NC4yMTY4IDEwLjQ2OTMgODUuNTU5OCAxMC40NjkzQzg2Ljg3NDQgMTAuNDY5MyA4Ny43ODQgMTEuNDA2OCA4Ny43OTExIDEyLjcwNjVIODMuMjA3N1oiIGZpbGw9ImN1cnJlbnRDb2xvciI+PC9wYXRoPjxwYXRoIGQ9Ik05NC40NDI2IDEyLjk1NTFDOTQuNDQ5NyAxMS41NDg4IDk1LjI4ODIgMTAuNzI1IDk2LjUxMDUgMTAuNzI1Qzk3LjcyNTYgMTAuNzI1IDk4LjQ1NzUgMTEuNTIwNCA5OC40NTA0IDEyLjg1NTZWMTkuMjYxOUgxMDEuNDc4VjEyLjMxNTlDMTAxLjQ3OCA5Ljc3MzI2IDk5Ljk4NTMgOC4yMTA3NiA5Ny43MTE0IDguMjEwNzZDOTYuMDkxMiA4LjIxMDc2IDk0LjkxODcgOS4wMDYyMSA5NC40Mjg0IDEwLjI3NzVIOTQuMzAwNVY4LjM1MjgxSDkxLjQxNTVWMTkuMjYxOUg5NC40NDI2VjEyLjk1NTFaIiBmaWxsPSJjdXJyZW50Q29sb3IiPjwvcGF0aD48cGF0aCBkPSJNMTA3LjQwNCAxOS40NzVDMTEwLjMxIDE5LjQ3NSAxMTIuMTM2IDE3Ljc3MDQgMTEyLjI3OSAxNS4yNjMzSDEwOS40MjJDMTA5LjI0NCAxNi40MjgxIDEwOC40NzcgMTcuMDgxNSAxMDcuNDM5IDE3LjA4MTVDMTA2LjAyNSAxNy4wODE1IDEwNS4xMDkgMTUuODk1NCAxMDUuMTA5IDEzLjgwNzRDMTA1LjEwOSAxMS43NDc3IDEwNi4wMzIgMTAuNTY4NyAxMDcuNDM5IDEwLjU2ODdDMTA4LjU0OCAxMC41Njg3IDEwOS4yNTggMTEuMzAwMiAxMDkuNDIyIDEyLjM4NjlIMTEyLjI3OUMxMTIuMTUxIDkuODY1NTkgMTEwLjIzOSA4LjIxMDc2IDEwNy4zOSA4LjIxMDc2QzEwNC4wNzggOC4yMTA3NiAxMDIuMDMyIDEwLjUwNDggMTAyLjAzMiAxMy44NUMxMDIuMDMyIDE3LjE2NjcgMTA0LjA0MyAxOS40NzUgMTA3LjQwNCAxOS40NzVaIiBmaWxsPSJjdXJyZW50Q29sb3IiPjwvcGF0aD48cGF0aCBkPSJNMTE3Ljk5IDE5LjQ3NUMxMjAuNjkxIDE5LjQ3NSAxMjIuNTEgMTguMTYxIDEyMi45MzYgMTYuMTM2OUwxMjAuMTM2IDE1Ljk1MjJDMTE5LjgzMSAxNi43ODMyIDExOS4wNDkgMTcuMjE2NCAxMTguMDQgMTcuMjE2NEMxMTYuNTI2IDE3LjIxNjQgMTE1LjU2NyAxNi4yMTUgMTE1LjU2NyAxNC41ODg2VjE0LjU4MTVIMTIzVjEzLjc1MDVDMTIzIDEwLjA0MzEgMTIwLjc1NCA4LjIxMDc2IDExNy44NjkgOC4yMTA3NkMxMTQuNjU4IDguMjEwNzYgMTEyLjU3NSAxMC40OTA2IDExMi41NzUgMTMuODU3MUMxMTIuNTc1IDE3LjMxNTkgMTE0LjYyOSAxOS40NzUgMTE3Ljk5IDE5LjQ3NVpNMTE1LjU2NyAxMi43MDY1QzExNS42MzEgMTEuNDYzNiAxMTYuNTc2IDEwLjQ2OTMgMTE3LjkxOSAxMC40NjkzQzExOS4yMzQgMTAuNDY5MyAxMjAuMTQzIDExLjQwNjggMTIwLjE1IDEyLjcwNjVIMTE1LjU2N1oiIGZpbGw9ImN1cnJlbnRDb2xvciI+PC9wYXRoPjxkZWZzPjxsaW5lYXJHcmFkaWVudCBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSIgaWQ9InBhaW50MF9saW5lYXIiIHgxPSI4LjQ5MjE5IiB4Mj0iOC40OTIxOSIgeTE9IjEzLjE0MjgiIHkyPSIyNCI+PHN0b3Agc3RvcC1jb2xvcj0iIzI5NzlGRiI+PC9zdG9wPjxzdG9wIG9mZnNldD0iMSIgc3RvcC1jb2xvcj0iIzQ0OEFGRiI+PC9zdG9wPjwvbGluZWFyR3JhZGllbnQ+PGxpbmVhckdyYWRpZW50IGdyYWRpZW50VW5pdHM9InVzZXJTcGFjZU9uVXNlIiBpZD0icGFpbnQxX2xpbmVhciIgeDE9IjE1LjY1MTciIHgyPSIxNS42NTE3IiB5MT0iMTQuODU3MiIgeTI9IjI0Ij48c3RvcCBzdG9wLWNvbG9yPSIjNDQ4QUZGIj48L3N0b3A+PHN0b3Agb2Zmc2V0PSIxIiBzdG9wLWNvbG9yPSIjMjk3OUZGIj48L3N0b3A+PC9saW5lYXJHcmFkaWVudD48L2RlZnM+PC9zdmc+"    x="1100" y="307" width="76" height="15"/>
              <animateTransform attributeName="transform" type="translate" from="0 0" to="-570 0" dur="22s" repeatCount="indefinite"/>
            </g>
          </g>

          <!-- Security → 3 destinations: straight vertical arrows from bar bottom -->
          <line class="kf2" x1="80"  y1="354" x2="80"  y2="420" stroke="rgba(255,255,255,0.55)" stroke-width="1.8" marker-end="url(#ah2)"/>
          <rect x="60"  y="375" width="40" height="18" rx="9" fill="rgba(201,60,9,0.95)"/>
          <text x="80"  y="388" text-anchor="middle" fill="white" font-size="10" font-family="Inter,sans-serif" font-weight="600" letter-spacing="0.8">KYA</text>

          <line class="kf3" x1="240" y1="354" x2="240" y2="420" stroke="rgba(255,255,255,0.55)" stroke-width="1.8" marker-end="url(#ah2)"/>
          <rect x="220" y="375" width="40" height="18" rx="9" fill="rgba(201,60,9,0.95)"/>
          <text x="240" y="388" text-anchor="middle" fill="white" font-size="10" font-family="Inter,sans-serif" font-weight="600" letter-spacing="0.8">KYA</text>

          <line class="kf4" x1="400" y1="354" x2="400" y2="420" stroke="rgba(255,255,255,0.55)" stroke-width="1.8" marker-end="url(#ah2)"/>
          <rect x="380" y="375" width="40" height="18" rx="9" fill="rgba(201,60,9,0.95)"/>
          <text x="400" y="388" text-anchor="middle" fill="white" font-size="10" font-family="Inter,sans-serif" font-weight="600" letter-spacing="0.8">KYA</text>

          <!-- Websites box (bottom-left) -->
          <rect class="dest-node" x="20" y="422" width="120" height="92" rx="14" fill="url(#dest-grad-2)" stroke="rgba(255,255,255,0.32)" stroke-width="1.8"/>
          <g transform="translate(67.000 469.000) scale(0.02708)"><path d="M324-111.5Q251-143 197-197t-85.5-127Q80-397 80-480t31.5-156Q143-709 197-763t127-85.5Q397-880 480-880t156 31.5Q709-817 763-763t85.5 127Q880-563 880-480t-31.5 156Q817-251 763-197t-127 85.5Q563-80 480-80t-156-31.5ZM440-162v-78q-33 0-56.5-23.5T360-320v-40L168-552q-3 18-5.5 36t-2.5 36q0 121 79.5 212T440-162Zm276-102q41-45 62.5-100.5T800-480q0-98-54.5-179T600-776v16q0 33-23.5 56.5T520-680h-80v80q0 17-11.5 28.5T400-560h-80v80h240q17 0 28.5 11.5T600-440v120h40q26 0 47 15.5t29 40.5Z" fill="rgba(255,255,255,0.92)"/></g>
          <text x="80" y="492" text-anchor="middle" fill="white" font-size="14" font-family="Geist,Inter,sans-serif" font-weight="500" letter-spacing="-0.3">Websites</text>

          <!-- APIs box (bottom-center) -->
          <rect class="dest-node" style="animation-delay:1.4s" x="180" y="422" width="120" height="92" rx="14" fill="url(#dest-grad-2)" stroke="rgba(255,255,255,0.32)" stroke-width="1.8"/>
          <g transform="translate(227.000 469.000) scale(0.02708)"><path d="M320-240 80-480l240-240 57 57-184 184 183 183-56 56Zm320 0-57-57 184-184-183-183 56-56 240 240-240 240Z" fill="rgba(255,255,255,0.92)"/></g>
          <text x="240" y="492" text-anchor="middle" fill="white" font-size="14" font-family="Geist,Inter,sans-serif" font-weight="500" letter-spacing="-0.3">APIs</text>

          <!-- Agent Protocols box (bottom-right) -->
          <rect class="dest-node" style="animation-delay:2.8s" x="340" y="422" width="120" height="92" rx="14" fill="url(#dest-grad-2)" stroke="rgba(255,255,255,0.32)" stroke-width="1.8"/>
          <g transform="translate(388.000 464.000) scale(0.02500)"><path d="M155-75q-35-35-35-85t35-85q35-35 85-35 14 0 26 3t23 8l57-71q-28-31-39-70t-5-78l-81-27q-17 25-43 40t-58 15q-50 0-85-35T0-580q0-50 35-85t85-35q50 0 85 35t35 85v8l81 28q20-36 53.5-61t75.5-32v-87q-39-11-64.5-42.5T360-840q0-50 35-85t85-35q50 0 85 35t35 85q0 42-26 73.5T510-724v87q42 7 75.5 32t53.5 61l81-28v-8q0-50 35-85t85-35q50 0 85 35t35 85q0 50-35 85t-85 35q-32 0-58.5-15T739-515l-81 27q6 39-5 77.5T614-340l57 70q11-5 23-7.5t26-2.5q50 0 85 35t35 85q0 50-35 85t-85 35q-50 0-85-35t-35-85q0-20 6.5-38.5T624-232l-57-71q-41 23-87.5 23T392-303l-56 71q11 15 17.5 33.5T360-160q0 50-35 85t-85 35q-50 0-85-35Zm-35-465q17 0 28.5-11.5T160-580q0-17-11.5-28.5T120-620q-17 0-28.5 11.5T80-580q0 17 11.5 28.5T120-540Zm148.5 408.5Q280-143 280-160t-11.5-28.5Q257-200 240-200t-28.5 11.5Q200-177 200-160t11.5 28.5Q223-120 240-120t28.5-11.5Zm240-680Q520-823 520-840t-11.5-28.5Q497-880 480-880t-28.5 11.5Q440-857 440-840t11.5 28.5Q463-800 480-800t28.5-11.5ZM480-360q42 0 71-29t29-71q0-42-29-71t-71-29q-42 0-71 29t-29 71q0 42 29 71t71 29Zm268.5 228.5Q760-143 760-160t-11.5-28.5Q737-200 720-200t-28.5 11.5Q680-177 680-160t11.5 28.5Q703-120 720-120t28.5-11.5Zm120-420Q880-563 880-580t-11.5-28.5Q857-620 840-620t-28.5 11.5Q800-597 800-580t11.5 28.5Q823-540 840-540t28.5-11.5ZM480-840ZM120-580Zm360 120Zm360-120ZM240-160Zm480 0Z" fill="rgba(255,255,255,0.92)"/></g>
          <text x="400" y="484" text-anchor="middle" fill="white" font-size="13" font-family="Geist,Inter,sans-serif" font-weight="500" letter-spacing="-0.3">Agent Protocols</text>
          <text x="400" y="502" text-anchor="middle" fill="rgba(255,255,255,0.6)" font-size="9" font-family="Inter,sans-serif" font-weight="400" letter-spacing="0.2">MCP, UCP, A2A…</text>
        </svg>
      </div>
    </div>
  </div>
</section>

<!-- ============ LIVE CHECKOUT DEMO ============ -->
<section class="demo-section" id="demo">
  <div class="wrap">
    <div class="demo-head reveal">
      <div class="eyebrow" style="margin-left:auto;margin-right:auto;">Live Walkthrough</div>
      <h2>Watch an agent complete checkout</h2>
      <p class="lede">
        Follow an agentic transaction powered by Skyfire: Token issuance, site access, login and checkout.
      </p>
    </div>

    <div class="demo-frame reveal">
      <div class="demo-bar">
        <div class="demo-dots"><span></span><span></span><span></span></div>
        <div class="demo-url">api.skyfire.xyz/api/v1/tokens</div>
        <div style="width: 36px;"></div>
      </div>

      <div class="demo-body">
        <div class="steps" id="steps">
          <div class="step" data-step="1">
            <div class="num">1</div>
            <div class="title">Token Request</div>
            <div class="desc">Agent requests a KYA token for this merchant URL.</div>
            <div class="badge">Pending</div>
          </div>
          <div class="step" data-step="2">
            <div class="num">2</div>
            <div class="title">Website Login</div>
            <div class="desc">Site access with KYA, then authenticated login linking agent and human identity.</div>
            <div class="badge">Pending</div>
          </div>
          <div class="step" data-step="3">
            <div class="num">3</div>
            <div class="title">Checkout</div>
            <div class="desc">User mandate for merchant, product, and amount. Agentic Wallet authorizes tokenized card for payment.</div>
            <div class="badge">Pending</div>
          </div>
          <div class="step" data-step="4">
            <div class="num">4</div>
            <div class="title">Live Transaction</div>
            <div class="desc">Checkout occurs the same as today without technical lift from the merchant.</div>
            <div class="badge">Pending</div>
          </div>
        </div>

        <aside class="demo-side">
          <div class="head">
            <span>Agent Activity</span>
            <span class="live-pulse">Live</span>
          </div>
          <div class="tx-list" id="tx-list">
            <div class="tx tx--wait" data-tx="0">
              <div class="tx-l">
                <div class="tx-merchant">Live Nation</div>
                <div class="tx-item">2 tickets, Concert hold</div>
              </div>
              <div class="tx-r tx-r--await">Awaiting</div>
            </div>
            <div class="tx tx--wait" data-tx="1">
              <div class="tx-l">
                <div class="tx-merchant">Bose</div>
                <div class="tx-item">QuietComfort 45 Headphones</div>
              </div>
              <div class="tx-r tx-r--await">Awaiting</div>
            </div>
            <div class="tx tx--wait" data-tx="2">
              <div class="tx-l">
                <div class="tx-merchant">Cotogna</div>
                <div class="tx-item">Reservation, party of 2 at 7:00 PM</div>
              </div>
              <div class="tx-r tx-r--await">Awaiting</div>
            </div>
            <div class="tx tx--wait" data-tx="3">
              <div class="tx-l">
                <div class="tx-merchant">Ninja</div>
                <div class="tx-item">Professional Plus Blender</div>
              </div>
              <div class="tx-r tx-r--await">Awaiting</div>
            </div>
            <div class="tx tx--wait" data-tx="4">
              <div class="tx-l">
                <div class="tx-merchant">Getty Images</div>
                <div class="tx-item">Editorial license, 1 asset</div>
              </div>
              <div class="tx-r tx-r--await">Awaiting</div>
            </div>
          </div>
        </aside>
      </div>
    </div>

    <div class="demo-cta reveal">
      <a class="btn btn--primary" href="https://skyfire.xyz/contact/">
        Contact us <span class="arr">→</span>
      </a>
    </div>
  </div>
</section>

<!-- ============ FOOTER ============ -->
<footer>
  <div class="wrap">
    <div class="foot-grid">
      <div class="foot-brand">
        <a href="#" class="logo" aria-label="Skyfire home">
          <img class="logo-img" src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTA4IiBoZWlnaHQ9IjI3IiB2aWV3Qm94PSIwIDAgMTA4IDI3IiBmaWxsPSJub25lIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgo8cGF0aCBkPSJNNzcuMjg5MyAyLjUyMTI0SDc0LjI5OTVDNzIuNzggMi41MjEyNCA3MS42NTU4IDIuODg2OTkgNzAuOTM5IDMuNjEzNThDNzAuMjIyMiA0LjM0MDE2IDY5Ljg2MTQgNS4zNzM1OSA2OS44NjE0IDYuNzEzODVWMjAuMDI4MUM2OS44NjE0IDIwLjM5MTQgNzAuMTUzNSAyMC42ODEgNzAuNTE0MyAyMC42ODFINzIuOTY5QzczLjMzMjMgMjAuNjgxIDczLjYyMiAyMC4zODg5IDczLjYyMiAyMC4wMjgxVjExLjU1Mkg3Ni42MjlDNzYuOTkyMiAxMS41NTIgNzcuMjgxOSAxMS4yNTk5IDc3LjI4MTkgMTAuODk5MVY5LjE4ODE3Qzc3LjI4MTkgOC44MjQ4OCA3Ni45ODk4IDguNTM1MjMgNzYuNjI5IDguNTM1MjNINzMuNjIyVjcuMTEzOTZDNzMuNjIyIDYuNTk2MDIgNzMuNzM5OCA2LjIxMzA5IDczLjk3MDUgNS45NTI4OUM3NC4yMDYyIDUuNjkwMjQgNzQuNTg0MiA1LjU2MjYgNzUuMTAyMSA1LjU2MjZINzYuNzIyMkM3Ny4wMDQ1IDUuNTYyNiA3Ny4yNTQ5IDUuMzgwOTUgNzcuMzQzMyA1LjExMzM5TDc3LjkxMjggMy4zODI4NEM3OC4wNTAyIDIuOTYwNjMgNzcuNzM4NSAyLjUyMzY5IDc3LjI5MTcgMi41MjM2OUw3Ny4yODkzIDIuNTIxMjRaTTczLjk4MDMgNS45NDA2MkM3My45ODAzIDUuOTQwNjIgNzMuOTc1NCA1Ljk0Nzk4IDczLjk3MyA1Ljk1MDQ0TDczLjk4MDMgNS45NDA2MlpNNjcuOTYxNSA3LjI0NjUxSDY1LjU1NTlDNjUuMjc4NSA3LjI0NjUxIDY1LjAzNTUgNy40MjA4IDY0LjkzOTcgNy42ODA5OUw2MS41MDA3IDE3LjIzOTVMNTcuOTkzIDcuNjgzNDVDNTcuODk3MiA3LjQyNTcxIDU3LjY1NDIgNy4yNTM4OCA1Ny4zNzkzIDcuMjUzODhINTAuNzMyQzUwLjUwMzcgNy4yNTM4OCA1MC4yOTAyIDcuMzc0MTYgNTAuMTcyMyA3LjU3MDUzTDQ2LjM0NzkgMTMuOTA4NUw1MC4xNzIzIDIwLjI0NjVDNTAuMjkwMiAyMC40NDI5IDUwLjUwMTMgMjAuNTYzMiA1MC43MzIgMjAuNTYzMkg1My40OTExQzU0LjAwMTYgMjAuNTYzMiA1NC4zMTU4IDIwLjAwNiA1NC4wNTA3IDE5LjU3MTVMNTAuNjM2MyAxMy45MDg1TDUzLjU1IDkuMDg1MDhDNTMuODM0NyA4LjYxMzc4IDU0LjUzNDMgOC42ODI1MSA1NC43MjMzIDkuMTk3OTlMNTguNzcxMSAyMC4yMTQ2QzU4Ljg0NzIgMjAuNDIwOCA1OS4wNDM2IDIwLjU1ODMgNTkuMjYyIDIwLjU1ODNINTkuNTc2MkM1OS45MzQ2IDIwLjU1ODMgNjAuMTkyNCAyMC45MTQyIDYwLjA3MjEgMjEuMjUwNUM1OS43Mjg0IDIyLjIxNzcgNTguODA1NSAyMi44NjgyIDU3Ljc4NjggMjIuODY4Mkg1NC44NDYxQzU0LjQ4MjggMjIuODY4MiA1NC4xOTMxIDIzLjE2MDMgNTQuMTkzMSAyMy41MjExVjI1Ljc4NjhDNTQuMTkzMSAyNi4xNTAxIDU0LjQ4NTIgMjYuNDM5NyA1NC44NDYxIDI2LjQzOTdINTcuNzg2OEM2MC4zMDUzIDI2LjQzOTcgNjIuNTYxMSAyNC44NDQyIDYzLjQyMDMgMjIuNDYwN0w2OC41NzUxIDguMTIwMzhDNjguNzI3MyA3LjY5MzI3IDY4LjQxMzEgNy4yNDY1MSA2Ny45NTkgNy4yNDY1MUg2Ny45NjE1Wk00NC43ODY3IDIuOTIzODFINDIuMzg4NUM0Mi4wMjUyIDIuOTIzODEgNDEuNzM1NiAzLjIxNTkyIDQxLjczNTYgMy41NzY3NlYxOS44OTA2QzQxLjczNTYgMjAuMjUzOSA0Mi4wMjc3IDIwLjU0MzYgNDIuMzg4NSAyMC41NDM2SDQ0Ljc4NjdDNDUuMTUgMjAuNTQzNiA0NS40Mzk3IDIwLjI1MTUgNDUuNDM5NyAxOS44OTA2VjMuNTc2NzZDNDUuNDM5NyAzLjIxMzQ2IDQ1LjE0NzYgMi45MjM4MSA0NC43ODY3IDIuOTIzODFaTTM3LjA2NDMgMTEuNDQ4OVYxMS40MzE4QzM2LjEyMTcgMTAuOTIxMiAzNC44MzA1IDEwLjUwMzkgMzMuMTkzMyAxMC4xNzVDMzIuMjQwOCA5Ljk3NjEzIDMxLjUwMiA5Ljc2NTAzIDMwLjk4MTYgOS41NTE0N0MzMC40NjEyIDkuMzM3OTEgMzAuMDkzIDkuMDg1MDggMjkuODcyMSA4Ljc5NTQyQzI5LjY0MzggOC41MTA2OCAyOS41NDMxIDguMTQ3MzkgMjkuNTQzMSA3LjcxMjkxQzI5LjU0MzEgNy4xMDY2IDI5Ljc4ODYgNi42MDA5MyAzMC4yNzQ2IDYuMjMwMjdDMzAuNzYwNyA1Ljg0MjQzIDMxLjQzMDggNS42NTU4OCAzMi4yODk5IDUuNjU1ODhDMzIuOTY1IDUuNjU1ODggMzMuNTQ2NyA1Ljc3NjE2IDM0LjAyMjkgNi4wMjY1NEMzNC40OTQyIDYuMjc2OTEgMzQuODgyMSA2LjYyNTQ4IDM1LjE1NDYgNy4wODQ1MUMzNS4zNDg1IDcuMzkzOCAzNS40ODM1IDcuNzQ0ODIgMzUuNTY2OSA4LjEzMjY2QzM1LjYzMzIgOC40NDY4NiAzNS45MjA0IDguNjY1MzIgMzYuMjM5NSA4LjY0ODE0TDM4LjY5NDIgOC41MTgwNEMzOS4wOTY4IDguNDk4NDEgMzkuMzc5MSA4LjEyMjg0IDM5LjMwMDUgNy43MzAwOUMzOS4xMzExIDYuODcwOTUgMzguODI5MiA2LjA5NTI3IDM4LjM4OTggNS40MDMwNEMzNy44MTU0IDQuNTAyMTcgMzcuMDI3NSAzLjgwNzUgMzYuMDI4NCAzLjI5NjkyQzM1LjAyOTQgMi43ODM4OSAzMy44MDQ1IDIuNTMxMDYgMzIuMzQ2NCAyLjUzMTA2QzMwLjk3NjcgMi41MzEwNiAyOS43OTYgMi43NDk1MyAyOC43OTY5IDMuMjA4NTVDMjcuODE1IDMuNjUwNCAyNy4wNDkyIDQuMjczODkgMjYuNTQxMSA1LjA3NDEyQzI2LjAyMDcgNS44NjIwNyAyNS43NjA1IDYuNzkyNCAyNS43NjA1IDcuODUyODJDMjUuNzYwNSA4Ljg0NDUyIDI1Ljk2NjcgOS42NjkyOSAyNi4zODQgMTAuMzI0N0MyNi43OTE0IDEwLjk3NzYgMjcuNDYxNiAxMS41MjUgMjguMzcyMiAxMS45NDk3QzI5LjI4MjkgMTIuMzc2OCAzMC40ODgyIDEyLjc2NDcgMzEuOTkwNSAxMy4xMjA2QzMzLjA3NTQgMTMuMzcxIDMzLjkwMDIgMTMuNjE2NCAzNC40NjIzIDEzLjg3NjZDMzUuMDE5NSAxNC4xMjcgMzUuNCAxNC40MTQyIDM1LjU5MzkgMTQuNzIxQzM1Ljc5MjggMTUuMDI3OSAzNS44OTEgMTUuMzgzOCAzNS44OTEgMTUuODAzNkMzNS44OTEgMTYuMjQ3OSAzNS43NzA3IDE2LjYyMzQgMzUuNTQ0OCAxNi45MzI3QzM1LjMxNjYgMTcuMjM5NSAzNC45ODAzIDE3LjQ3MDMgMzQuNTQ1OCAxNy42MTc2QzM0LjExMTMgMTcuNzY0OSAzMy41NzYyIDE3Ljg0NTkgMzIuOTU1MiAxNy44NDU5QzMyLjIwMTYgMTcuODQ1OSAzMS41NjMzIDE3LjcyNTYgMzEuMDQ1NCAxNy40NzUyQzMwLjUyNSAxNy4yMjQ4IDMwLjExNzUgMTYuODU5MSAyOS44MTA3IDE2LjM3MDZDMjkuNTgyNCAxNi4wMDczIDI5LjQxMDYgMTUuNTg3NSAyOS4yOTc3IDE1LjExMTNDMjkuMjI2NSAxNC44MDk0IDI4Ljk0NDIgMTQuNjA1NyAyOC42MzQ5IDE0LjYyMDRMMjYuMTE2NCAxNC43MzU4QzI1LjczMSAxNC43NTU0IDI1LjQzODkgMTUuMDk5MSAyNS40OTc4IDE1LjQ3OTVDMjUuNjUgMTYuNDM5MyAyNS45NjkxIDE3LjI5MzYgMjYuNDU1MSAxOC4wNDIyQzI3LjA2MTQgMTguOTY1MiAyNy45MTA4IDE5LjY5MTggMjguOTk4MiAyMC4xOTVDMzAuMDgzMiAyMC43MDggMzEuMzc5MiAyMC45NjA5IDMyLjkwMTEgMjAuOTYwOUMzNC4yODggMjAuOTYwOSAzNS40ODEgMjAuNzQ3MyAzNi40OTQ4IDIwLjMyMjZDMzcuNTExMSAxOS44OTU1IDM4LjI4OTIgMTkuMjgxOSAzOC44NDY0IDE4LjQ3NDNDMzkuMzk2MyAxNy42NjkxIDM5LjY3MzYgMTYuNzI0MSAzOS42NzM2IDE1LjYzNDJDMzkuNjczNiAxNC43MzMzIDM5LjQ3NDggMTMuOTQ3OCAzOS4wNzcxIDEzLjI1MzFDMzguNjg0NCAxMi41NTg1IDM4LjAwOTQgMTEuOTU5NSAzNy4wNjE4IDExLjQ1NjNMMzcuMDY0MyAxMS40NDg5Wk05My45MDc1IDcuMjA3MjRIOTIuOTAxMUM5MS45MzE1IDcuMjA3MjQgOTEuMTgwMyA3LjUxNDA4IDkwLjYyOCA4LjExNTQ3TDkwLjYxODIgOC4xMDU2NkM5MC4yMjU1IDguNTM3NjggODkuOTI2IDkuMTYzNjMgODkuNjk3NyA5Ljk3ODU4TDg5LjYzMTQgNy44MzMxOUM4OS42MTkyIDcuNDc5NzEgODkuMzMyIDcuMTk5ODggODguOTc4NSA3LjE5OTg4SDg2LjcxMjhDODYuMzQ5NSA3LjE5OTg4IDg2LjA1OTkgNy40OTE5OCA4Ni4wNTk5IDcuODUyODJWMjAuMDIzMkM4Ni4wNTk5IDIwLjM4NjUgODYuMzUyIDIwLjY3NjEgODYuNzEyOCAyMC42NzYxSDg5LjE2NzVDODkuNTMwOCAyMC42NzYxIDg5LjgyMDQgMjAuMzg0IDg5LjgyMDQgMjAuMDIzMlYxMy4xMTA4Qzg5LjgyMDQgMTIuNDI1OSA4OS45NDA3IDExLjg3ODUgOTAuMTU5MiAxMS40NzU5QzkwLjM3NzcgMTEuMDczNCA5MC43MjM4IDEwLjc4MTMgOTEuMTc1NCAxMC41OTk2QzkxLjYyOTYgMTAuNDE4IDkyLjE5NjYgMTAuMzIyMiA5Mi45MDg0IDEwLjMyMjJIOTMuOTE0OUM5NC4yNzgyIDEwLjMyMjIgOTQuNTY3OCAxMC4wMzAxIDk0LjU2NzggOS42NjkyOVY3Ljg2MDE5Qzk0LjU2NzggNy40OTY4OSA5NC4yNzU3IDcuMjA3MjQgOTMuOTE0OSA3LjIwNzI0TDkzLjkxIDcuMjAyMzNMOTMuOTA3NSA3LjIwNzI0Wk04Mi45NTIyIDIuNTMxMDZIODAuMzgyMkM4MC4wMTg5IDIuNTMxMDYgNzkuNzI5MiAyLjgyMzE3IDc5LjcyOTIgMy4xODQwMVY0Ljg5MDAxQzc5LjcyOTIgNS4yNTMzMSA4MC4wMjEzIDUuNTQyOTYgODAuMzgyMiA1LjU0Mjk2SDgyLjk1MjJDODMuMzE1NSA1LjU0Mjk2IDgzLjYwNTIgNS4yNTA4NSA4My42MDUyIDQuODkwMDFWMy4xODQwMUM4My42MDUyIDIuODIwNzEgODMuMzEzMSAyLjUzMTA2IDgyLjk1MjIgMi41MzEwNlpNODIuOTE1NCA3LjIwMjMzSDgwLjQ2MDdDODAuMDk3NCA3LjIwMjMzIDc5LjgwNzggNy40OTQ0NCA3OS44MDc4IDcuODU1MjhWMjAuMDI1NkM3OS44MDc4IDIwLjM4ODkgODAuMDk5OSAyMC42Nzg2IDgwLjQ2MDcgMjAuNjc4Nkg4Mi45MTU0QzgzLjI3ODcgMjAuNjc4NiA4My41Njg0IDIwLjM4NjUgODMuNTY4NCAyMC4wMjU2VjcuODU1MjhDODMuNTY4NCA3LjQ5MTk4IDgzLjI3NjIgNy4yMDIzMyA4Mi45MTU0IDcuMjAyMzNaTTEwNy4yIDEwLjI5NTJDMTA2LjY1NSA5LjIxMjcyIDEwNS44ODYgOC4zNjgzMSAxMDQuOTAyIDcuNzg2NTVDMTAzLjkyIDcuMjAyMzMgMTAyLjc5MyA2LjkxMDIyIDEwMS40MjYgNi45MTAyMkMxMDAuMDU5IDYuOTEwMjIgOTguODY4NCA3LjIwMjMzIDk3Ljg2OTQgNy43ODY1NUM5Ni44NzAzIDguMzcwNzYgOTYuMDgyNCA5LjE5MDYzIDk1LjUyNTEgMTAuMjMxNEM5NC45Njc5IDExLjI3MjIgOTQuNjgzMiAxMi41MTQzIDk0LjY4MzIgMTMuOTQwNEM5NC42ODMyIDE1LjM2NjYgOTQuOTYwNiAxNi42MDg3IDk1LjUyNTEgMTcuNjY0MkM5Ni4wODI0IDE4LjcyMjIgOTYuODcwMyAxOS41MzIyIDk3Ljg3NjcgMjAuMTA5MUM5OC44ODMyIDIwLjY4MzUgMTAwLjA3MSAyMC45NzU2IDEwMS40NTEgMjAuOTc1NkMxMDUuMjQ4IDIwLjk3NTYgMTA2Ljg4MyAxOC43MjQ2IDEwNy41MTQgMTcuNDA0QzEwNy43MjIgMTYuOTY5NSAxMDcuNDAzIDE2LjQ2ODggMTA2LjkyMiAxNi40Njg4SDEwNC40NjVDMTA0LjIxMiAxNi40Njg4IDEwMy45ODYgMTYuNjIxIDEwMy44NzEgMTYuODQ2OEMxMDMuNjg1IDE3LjIxMjUgMTAzLjQyOSAxNy40OTczIDEwMy4xMSAxNy43MDFDMTAyLjY4NSAxNy45Njg2IDEwMi4xNTMgMTguMTAzNiAxMDEuNTE5IDE4LjEwMzZDMTAwLjY0NiAxOC4xMDM2IDk5Ljk1NTggMTcuODQzNCA5OS40MjU2IDE3LjMyMDZDOTguOTA1MiAxNi44MDAyIDk4LjYxNTYgMTYuMDAyNCA5OC41NjE2IDE0LjkyNzJIMTA4LjAwMlYxNC4xNzEyTDEwOC4wMSAxNC4xODg0QzEwOC4wMSAxMi42ODM2IDEwNy43MzIgMTEuMzkyNSAxMDcuMiAxMC4yOTI4SDEwNy4xOTVMMTA3LjIgMTAuMjk1MlpNOTguNTczOSAxMi42NDE5Qzk4LjY3NyAxMS43MDE4IDk4Ljk4MTMgMTAuOTc1MiA5OS40OTQ0IDEwLjQ2NDZDMTAwLjAwNyA5Ljk1MTU4IDEwMC42NTEgOS42OTg3NSAxMDEuNDM2IDkuNjk4NzVDMTAyLjIyMiA5LjY5ODc1IDEwMi44NiA5Ljk0NDIyIDEwMy4zNTYgMTAuNDM1MkMxMDMuODUxIDEwLjkyNjEgMTA0LjExOSAxMS42NTc2IDEwNC4xNjYgMTIuNjQ0NEg5OC41NjlMOTguNTczOSAxMi42NDE5WiIgZmlsbD0iIzI4MTcxQiIvPgo8cGF0aCBkPSJNNi4zOTIxNyAxNC45NjkySDkuMjAyNzlDMTEuMDQzOCAxNC45NjkyIDEyLjUzNjMgMTMuNDc2NyAxMi41MzYzIDExLjYzNTdWOC44MzczN0MxMi41MzYzIDcuNDE4NTYgMTQuMjUyMSA2LjcwOTE1IDE1LjI1MzYgNy43MTA2NkwxNy42MTAxIDEwLjA2NzJDMTcuOTA5NiAxMC4zNjY2IDE4LjA3NjUgMTAuNzcxNyAxOC4wNzY1IDExLjE5MzlWMTguOTE2M0MxOC4wNzY1IDE5Ljc5NTEgMTcuMzY0NiAyMC41MDk0IDE2LjQ4MzQgMjAuNTA5NEg4Ljc1ODQ5QzguMzM2MjkgMjAuNTA5NCA3LjkzMzcyIDIwLjM0MjUgNy42MzQyNSAyMC4wNDU1TDUuMjY3OTMgMTcuNjg5QzQuMjYxNSAxNi42ODc1IDQuOTcwOTEgMTQuOTY5MiA2LjM5MjE3IDE0Ljk2OTJaIiBmaWxsPSIjMjgxNzFCIi8+CjxwYXRoIGQ9Ik0xMi4wMTczIDYuMTAyNzRIOS4yMDY3MUM3LjM2NTY5IDYuMTAyNzQgNS44NzMyNCA3LjU5NTE5IDUuODczMjQgOS40MzYyMVYxMi4yMzQ2QzUuODczMjQgMTMuNjUzNCA0LjE1NzQxIDE0LjM2MjggMy4xNTU5IDEzLjM2MTNMMC43OTkzOTkgMTAuOTk5OEMwLjQ5OTkyNyAxMC43MDA0IDAuMzMzMDA4IDEwLjI5NTMgMC4zMzMwMDggOS44NzMxNFYyLjE1MzE1QzAuMzMzMDA4IDEuMjcxOTIgMS4wNDQ4NyAwLjU2MDA1OSAxLjkyNjEgMC41NjAwNTlIOS42NTFDMTAuMDczMiAwLjU2MDA1OSAxMC40NzU4IDAuNzI2OTc3IDEwLjc3NTMgMS4wMjM5OUwxMy4xNDE2IDMuMzgwNDlDMTQuMTQ4IDQuMzgyMDEgMTMuNDM4NiA2LjEwMDI5IDEyLjAxNzMgNi4xMDAyOVY2LjEwMjc0WiIgZmlsbD0iIzI4MTcxQiIvPgo8L3N2Zz4K" alt="" width="108" height="27" decoding="async" />
        </a>
        <h4>The Agent Trust Stack.</h4>
        <p>Identity, access, and payment infrastructure purpose-built for the agentic era.</p>
      </div>
      <div class="foot-col">
        <h5>Products</h5>
        <ul>
          <li><a href="https://docs.skyfire.xyz/docs/kya-token" target="_blank" rel="noopener">Know Your Agent</a></li>
          <li><a href="https://skyfire.xyz/use-case/">Agentic Wallet</a></li>
          <li><a href="https://skyfire.xyz/use-case/">Buy for Me</a></li>
        </ul>
      </div>
      <div class="foot-col">
        <h5>Resources</h5>
        <ul>
          <li><a href="https://docs.skyfire.xyz/" target="_blank" rel="noopener">Documentation</a></li>
          <li><a href="https://skyfire.xyz/use-case/">Use Cases</a></li>
          <li><a href="https://kyapay.org" target="_blank" rel="noopener">KYA Pay</a></li>
        </ul>
      </div>
      <div class="foot-col">
        <h5>Company</h5>
        <ul>
          <li><a href="https://skyfire.xyz/contact/">Contact</a></li>
          <li><a href="https://skyfire.xyz/">About</a></li>
        </ul>
      </div>
    </div>
    <div class="foot-base">
      <span>© 2026 Skyfire Systems, Inc.</span>
      <span>Built for the agentic web</span>
    </div>
  </div>
</footer>

<script>

  // Reveal-on-scroll
  const io = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.classList.add('in');
        io.unobserve(e.target);
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -8% 0px' });
  document.querySelectorAll('.reveal').forEach(el => io.observe(el));

  // Demo: run pipeline steps 1→4, then light one ledger row and confirm it; repeat per merchant.
  (function demoCheckoutAnimation() {
    const steps = Array.from(document.querySelectorAll('#steps .step'));
    const txs = Array.from(document.querySelectorAll('#tx-list .tx'));
    const N = steps.length;
    const TICK_MS = 1500;

    let merchantIdx = 0;
    /** 0..N-1 = that step active; N = all steps verified, ledger row "live"; N+1 = ledger confirmed, advance merchant */
    let phase = 0;

    function resetPipelineUI() {
      steps.forEach((s) => {
        s.classList.remove('active', 'done');
        s.querySelector('.badge').textContent = 'Pending';
      });
    }

    function render() {
      steps.forEach((s, idx) => {
        s.classList.remove('active', 'done');
        const badge = s.querySelector('.badge');
        if (phase < N) {
          if (idx < phase) { s.classList.add('done'); badge.textContent = 'Verified'; }
          else if (idx === phase) { s.classList.add('active'); badge.textContent = 'Active'; }
          else { badge.textContent = 'Pending'; }
        } else {
          s.classList.add('done');
          badge.textContent = 'Verified';
        }
      });

      txs.forEach((row, i) => {
        const status = row.querySelector('.tx-r');
        row.classList.remove('tx--wait', 'tx--live', 'tx--settled');
        status.classList.remove('tx-r--await', 'tx-r--live', 'tx-r--ok');
        if (i < merchantIdx) {
          row.classList.add('tx--settled');
          status.classList.add('tx-r--ok');
          status.textContent = 'Confirmed';
        } else if (i > merchantIdx) {
          row.classList.add('tx--wait');
          status.classList.add('tx-r--await');
          status.textContent = 'Awaiting';
        } else {
          if (phase < N) {
            row.classList.add('tx--wait');
            status.classList.add('tx-r--await');
            status.textContent = 'Awaiting';
          } else if (phase === N) {
            row.classList.add('tx--live');
            status.classList.add('tx-r--live');
            status.textContent = 'Settling';
          } else {
            row.classList.add('tx--settled');
            status.classList.add('tx-r--ok');
            status.textContent = 'Confirmed';
          }
        }
      });
    }

    function tick() {
      phase += 1;
      if (phase > N + 1) {
        merchantIdx += 1;
        phase = 0;
        if (merchantIdx >= txs.length) {
          merchantIdx = 0;
          txs.forEach((row) => {
            row.classList.remove('tx--settled', 'tx--live');
            row.classList.add('tx--wait');
            const status = row.querySelector('.tx-r');
            status.className = 'tx-r tx-r--await';
            status.textContent = 'Awaiting';
          });
        }
        resetPipelineUI();
      }
      render();
    }

    const demoSection = document.querySelector('.demo-section');
    const demoIO = new IntersectionObserver((entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting) {
          phase = 0;
          merchantIdx = 0;
          resetPipelineUI();
          txs.forEach((row) => {
            row.classList.remove('tx--live', 'tx--settled');
            row.classList.add('tx--wait');
            const status = row.querySelector('.tx-r');
            status.className = 'tx-r tx-r--await';
            status.textContent = 'Awaiting';
          });
          render();
          if (!window._demoTimer) window._demoTimer = setInterval(tick, TICK_MS);
        } else {
          if (window._demoTimer) {
            clearInterval(window._demoTimer);
            window._demoTimer = null;
          }
        }
      });
    }, { threshold: 0.25 });
    if (demoSection) demoIO.observe(demoSection);
  })();
</script>

</body>
</html>
